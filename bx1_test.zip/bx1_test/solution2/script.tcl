############################################################
## This file is generated automatically by Vivado HLS.
## Please DO NOT edit it.
## Copyright (C) 1986-2020 Xilinx, Inc. All Rights Reserved.
############################################################
open_project bx1_test
set_top algo_top
add_files ../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top.cpp
add_files ../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top.h
add_files -tb ../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp
open_solution "solution2"
set_part {xcvu13p-flga2577-2-e}
create_clock -period 360MHz -name default
set_clock_uncertainty 30%
#source "./bx1_test/solution2/directives.tcl"
csim_design
csynth_design
cosim_design
export_design -format ip_catalog
