<project xmlns="com.autoesl.autopilot.project" name="bx1_test" top="algo_top">
    <includePaths/>
    <libraryPaths/>
    <Simulation>
        <SimFlow name="csim" csimMode="0" lastCsimMode="0"/>
    </Simulation>
    <files xmlns="">
        <file name="../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp" sc="0" tb="1" cflags=" -Wno-unknown-pragmas" csimflags=" -Wno-unknown-pragmas" blackbox="false"/>
        <file name="../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top.h" sc="0" tb="false" cflags="" csimflags="" blackbox="false"/>
        <file name="../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top.cpp" sc="0" tb="false" cflags="" csimflags="" blackbox="false"/>
    </files>
    <solutions xmlns="">
        <solution name="solution1" status="inactive"/>
        <solution name="solution2" status="inactive"/>
        <solution name="solution3" status="inactive"/>
        <solution name="solution4" status="inactive"/>
        <solution name="solution5" status="active"/>
    </solutions>
</project>

