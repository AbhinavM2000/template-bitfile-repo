<project xmlns="com.autoesl.autopilot.project" top="" name="test_sanity">
    <files>
        <file name="../AlgoSRC/IP1/RCT2x6/algo_top.cpp" sc="0" tb="false" cflags="" blackbox="false"/>
        <file name="../AlgoSRC/IP1/RCT2x6/algo_top.h" sc="0" tb="false" cflags="" blackbox="false"/>
        <file name="../../../AlgoSRC/IP1/RCT2x6/algo_top_tb.cpp" sc="0" tb="1" cflags=""/>
    </files>
    <includePaths/>
    <libraryPaths/>
    <Simulation>
        <SimFlow name="csim" csimMode="0" lastCsimMode="0"/>
    </Simulation>
    <solutions xmlns="">
        <solution name="solution1" status="inactive"/>
        <solution name="solution2" status="inactive"/>
        <solution name="solution3" status="active"/>
    </solutions>
</project>

