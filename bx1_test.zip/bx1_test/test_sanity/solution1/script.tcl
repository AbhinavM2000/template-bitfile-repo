############################################################
## This file is generated automatically by Vivado HLS.
## Please DO NOT edit it.
## Copyright (C) 1986-2020 Xilinx, Inc. All Rights Reserved.
############################################################
open_project test_sanity
add_files ../AlgoSRC/IP1/RCT2x6/algo_top.cpp
add_files ../AlgoSRC/IP1/RCT2x6/algo_top.h
add_files -tb ../AlgoSRC/IP1/RCT2x6/algo_top_tb.cpp
open_solution "solution1"
set_part {xcvu13p-flga2577-2-e}
create_clock -period 360MHz -name default
set_clock_uncertainty 30%
#source "./test_sanity/solution1/directives.tcl"
csim_design
csynth_design
cosim_design
export_design -format ip_catalog
