# This script segment is generated automatically by AutoPilot

# clear list
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_begin
    cg_default_interface_gen_bundle_begin
    AESL_LIB_XILADAPTER::native_axis_begin
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 24 \
    name RCTECALClusters_0_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_s \
    op interface \
    ports { RCTECALClusters_0_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 25 \
    name RCTECALClusters_1_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_s \
    op interface \
    ports { RCTECALClusters_1_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 26 \
    name RCTECALClusters_2_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_s \
    op interface \
    ports { RCTECALClusters_2_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 27 \
    name RCTECALClusters_3_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_s \
    op interface \
    ports { RCTECALClusters_3_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 28 \
    name RCTECALClusters_4_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_s \
    op interface \
    ports { RCTECALClusters_4_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 29 \
    name RCTECALClusters_5_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_s \
    op interface \
    ports { RCTECALClusters_5_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 30 \
    name RCTECALClusters_6_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_s \
    op interface \
    ports { RCTECALClusters_6_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 31 \
    name RCTECALClusters_7_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_s \
    op interface \
    ports { RCTECALClusters_7_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 32 \
    name RCTECALClusters_8_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_s \
    op interface \
    ports { RCTECALClusters_8_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 33 \
    name RCTECALClusters_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_e \
    op interface \
    ports { RCTECALClusters_0_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 34 \
    name RCTECALClusters_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_e \
    op interface \
    ports { RCTECALClusters_1_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 35 \
    name RCTECALClusters_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_e \
    op interface \
    ports { RCTECALClusters_2_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 36 \
    name RCTECALClusters_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_e \
    op interface \
    ports { RCTECALClusters_3_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 37 \
    name RCTECALClusters_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_e \
    op interface \
    ports { RCTECALClusters_4_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 38 \
    name RCTECALClusters_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_e \
    op interface \
    ports { RCTECALClusters_5_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 39 \
    name RCTECALClusters_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_e \
    op interface \
    ports { RCTECALClusters_6_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 40 \
    name RCTECALClusters_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_e \
    op interface \
    ports { RCTECALClusters_7_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 41 \
    name RCTECALClusters_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_e \
    op interface \
    ports { RCTECALClusters_8_e { I 12 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 42 \
    name RCTECALClusters_0_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_e_3 \
    op interface \
    ports { RCTECALClusters_0_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 43 \
    name RCTECALClusters_1_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_e_3 \
    op interface \
    ports { RCTECALClusters_1_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 44 \
    name RCTECALClusters_2_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_e_3 \
    op interface \
    ports { RCTECALClusters_2_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 45 \
    name RCTECALClusters_3_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_e_3 \
    op interface \
    ports { RCTECALClusters_3_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 46 \
    name RCTECALClusters_4_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_e_3 \
    op interface \
    ports { RCTECALClusters_4_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 47 \
    name RCTECALClusters_5_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_e_3 \
    op interface \
    ports { RCTECALClusters_5_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 48 \
    name RCTECALClusters_6_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_e_3 \
    op interface \
    ports { RCTECALClusters_6_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 49 \
    name RCTECALClusters_7_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_e_3 \
    op interface \
    ports { RCTECALClusters_7_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 50 \
    name RCTECALClusters_8_e_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_e_3 \
    op interface \
    ports { RCTECALClusters_8_e_3 { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 51 \
    name RCTECALClusters_0_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_p \
    op interface \
    ports { RCTECALClusters_0_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 52 \
    name RCTECALClusters_1_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_p \
    op interface \
    ports { RCTECALClusters_1_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 53 \
    name RCTECALClusters_2_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_p \
    op interface \
    ports { RCTECALClusters_2_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 54 \
    name RCTECALClusters_3_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_p \
    op interface \
    ports { RCTECALClusters_3_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 55 \
    name RCTECALClusters_4_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_p \
    op interface \
    ports { RCTECALClusters_4_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 56 \
    name RCTECALClusters_5_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_p \
    op interface \
    ports { RCTECALClusters_5_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 57 \
    name RCTECALClusters_6_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_p \
    op interface \
    ports { RCTECALClusters_6_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 58 \
    name RCTECALClusters_7_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_p \
    op interface \
    ports { RCTECALClusters_7_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 59 \
    name RCTECALClusters_8_p \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_p \
    op interface \
    ports { RCTECALClusters_8_p { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 60 \
    name RCTECALClusters_0_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_e_4 \
    op interface \
    ports { RCTECALClusters_0_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 61 \
    name RCTECALClusters_1_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_e_4 \
    op interface \
    ports { RCTECALClusters_1_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 62 \
    name RCTECALClusters_2_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_e_4 \
    op interface \
    ports { RCTECALClusters_2_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 63 \
    name RCTECALClusters_3_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_e_4 \
    op interface \
    ports { RCTECALClusters_3_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 64 \
    name RCTECALClusters_4_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_e_4 \
    op interface \
    ports { RCTECALClusters_4_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 65 \
    name RCTECALClusters_5_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_e_4 \
    op interface \
    ports { RCTECALClusters_5_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 66 \
    name RCTECALClusters_6_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_e_4 \
    op interface \
    ports { RCTECALClusters_6_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 67 \
    name RCTECALClusters_7_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_e_4 \
    op interface \
    ports { RCTECALClusters_7_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 68 \
    name RCTECALClusters_8_e_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_e_4 \
    op interface \
    ports { RCTECALClusters_8_e_4 { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 69 \
    name RCTECALClusters_0_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_w \
    op interface \
    ports { RCTECALClusters_0_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 70 \
    name RCTECALClusters_1_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_w \
    op interface \
    ports { RCTECALClusters_1_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 71 \
    name RCTECALClusters_2_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_w \
    op interface \
    ports { RCTECALClusters_2_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 72 \
    name RCTECALClusters_3_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_w \
    op interface \
    ports { RCTECALClusters_3_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 73 \
    name RCTECALClusters_4_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_w \
    op interface \
    ports { RCTECALClusters_4_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 74 \
    name RCTECALClusters_5_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_w \
    op interface \
    ports { RCTECALClusters_5_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 75 \
    name RCTECALClusters_6_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_w \
    op interface \
    ports { RCTECALClusters_6_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 76 \
    name RCTECALClusters_7_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_w \
    op interface \
    ports { RCTECALClusters_7_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 77 \
    name RCTECALClusters_8_w \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_w \
    op interface \
    ports { RCTECALClusters_8_w { I 7 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 78 \
    name RCTECALClusters_0_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_t \
    op interface \
    ports { RCTECALClusters_0_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 79 \
    name RCTECALClusters_1_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_t \
    op interface \
    ports { RCTECALClusters_1_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 80 \
    name RCTECALClusters_2_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_t \
    op interface \
    ports { RCTECALClusters_2_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 81 \
    name RCTECALClusters_3_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_t \
    op interface \
    ports { RCTECALClusters_3_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 82 \
    name RCTECALClusters_4_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_t \
    op interface \
    ports { RCTECALClusters_4_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 83 \
    name RCTECALClusters_5_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_t \
    op interface \
    ports { RCTECALClusters_5_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 84 \
    name RCTECALClusters_6_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_t \
    op interface \
    ports { RCTECALClusters_6_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 85 \
    name RCTECALClusters_7_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_t \
    op interface \
    ports { RCTECALClusters_7_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 86 \
    name RCTECALClusters_8_t \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_t \
    op interface \
    ports { RCTECALClusters_8_t { I 5 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 87 \
    name RCTECALClusters_0_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_s_3 \
    op interface \
    ports { RCTECALClusters_0_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 88 \
    name RCTECALClusters_1_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_s_3 \
    op interface \
    ports { RCTECALClusters_1_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 89 \
    name RCTECALClusters_2_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_s_3 \
    op interface \
    ports { RCTECALClusters_2_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 90 \
    name RCTECALClusters_3_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_s_3 \
    op interface \
    ports { RCTECALClusters_3_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 91 \
    name RCTECALClusters_4_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_s_3 \
    op interface \
    ports { RCTECALClusters_4_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 92 \
    name RCTECALClusters_5_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_s_3 \
    op interface \
    ports { RCTECALClusters_5_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 93 \
    name RCTECALClusters_6_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_s_3 \
    op interface \
    ports { RCTECALClusters_6_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 94 \
    name RCTECALClusters_7_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_s_3 \
    op interface \
    ports { RCTECALClusters_7_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 95 \
    name RCTECALClusters_8_s_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_s_3 \
    op interface \
    ports { RCTECALClusters_8_s_3 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 96 \
    name RCTECALClusters_0_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_s_4 \
    op interface \
    ports { RCTECALClusters_0_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 97 \
    name RCTECALClusters_1_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_s_4 \
    op interface \
    ports { RCTECALClusters_1_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 98 \
    name RCTECALClusters_2_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_s_4 \
    op interface \
    ports { RCTECALClusters_2_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 99 \
    name RCTECALClusters_3_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_s_4 \
    op interface \
    ports { RCTECALClusters_3_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 100 \
    name RCTECALClusters_4_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_s_4 \
    op interface \
    ports { RCTECALClusters_4_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 101 \
    name RCTECALClusters_5_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_s_4 \
    op interface \
    ports { RCTECALClusters_5_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 102 \
    name RCTECALClusters_6_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_s_4 \
    op interface \
    ports { RCTECALClusters_6_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 103 \
    name RCTECALClusters_7_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_s_4 \
    op interface \
    ports { RCTECALClusters_7_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 104 \
    name RCTECALClusters_8_s_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_s_4 \
    op interface \
    ports { RCTECALClusters_8_s_4 { I 1 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 105 \
    name RCTECALClusters_0_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_0_b \
    op interface \
    ports { RCTECALClusters_0_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 106 \
    name RCTECALClusters_1_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_1_b \
    op interface \
    ports { RCTECALClusters_1_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 107 \
    name RCTECALClusters_2_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_2_b \
    op interface \
    ports { RCTECALClusters_2_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 108 \
    name RCTECALClusters_3_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_3_b \
    op interface \
    ports { RCTECALClusters_3_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 109 \
    name RCTECALClusters_4_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_4_b \
    op interface \
    ports { RCTECALClusters_4_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 110 \
    name RCTECALClusters_5_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_5_b \
    op interface \
    ports { RCTECALClusters_5_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 111 \
    name RCTECALClusters_6_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_6_b \
    op interface \
    ports { RCTECALClusters_6_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 112 \
    name RCTECALClusters_7_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_7_b \
    op interface \
    ports { RCTECALClusters_7_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 113 \
    name RCTECALClusters_8_b \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTECALClusters_8_b \
    op interface \
    ports { RCTECALClusters_8_b { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 114 \
    name RCTTowersPHI_0_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_0_e \
    op interface \
    ports { RCTTowersPHI_0_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 115 \
    name RCTTowersPHI_0_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_1_e \
    op interface \
    ports { RCTTowersPHI_0_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 116 \
    name RCTTowersPHI_0_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_2_e \
    op interface \
    ports { RCTTowersPHI_0_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 117 \
    name RCTTowersPHI_0_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_3_e \
    op interface \
    ports { RCTTowersPHI_0_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 118 \
    name RCTTowersPHI_0_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_4_e \
    op interface \
    ports { RCTTowersPHI_0_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 119 \
    name RCTTowersPHI_0_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_5_e \
    op interface \
    ports { RCTTowersPHI_0_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 120 \
    name RCTTowersPHI_0_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_6_e \
    op interface \
    ports { RCTTowersPHI_0_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 121 \
    name RCTTowersPHI_0_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_7_e \
    op interface \
    ports { RCTTowersPHI_0_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 122 \
    name RCTTowersPHI_0_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_8_e \
    op interface \
    ports { RCTTowersPHI_0_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 123 \
    name RCTTowersPHI_0_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_9_e \
    op interface \
    ports { RCTTowersPHI_0_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 124 \
    name RCTTowersPHI_0_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_10_s \
    op interface \
    ports { RCTTowersPHI_0_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 125 \
    name RCTTowersPHI_0_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_11_s \
    op interface \
    ports { RCTTowersPHI_0_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 126 \
    name RCTTowersPHI_0_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_12_s \
    op interface \
    ports { RCTTowersPHI_0_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 127 \
    name RCTTowersPHI_0_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_13_s \
    op interface \
    ports { RCTTowersPHI_0_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 128 \
    name RCTTowersPHI_0_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_14_s \
    op interface \
    ports { RCTTowersPHI_0_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 129 \
    name RCTTowersPHI_0_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_15_s \
    op interface \
    ports { RCTTowersPHI_0_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 130 \
    name RCTTowersPHI_0_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_16_s \
    op interface \
    ports { RCTTowersPHI_0_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 131 \
    name RCTTowersPHI_1_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_0_e \
    op interface \
    ports { RCTTowersPHI_1_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 132 \
    name RCTTowersPHI_1_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_1_e \
    op interface \
    ports { RCTTowersPHI_1_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 133 \
    name RCTTowersPHI_1_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_2_e \
    op interface \
    ports { RCTTowersPHI_1_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 134 \
    name RCTTowersPHI_1_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_3_e \
    op interface \
    ports { RCTTowersPHI_1_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 135 \
    name RCTTowersPHI_1_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_4_e \
    op interface \
    ports { RCTTowersPHI_1_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 136 \
    name RCTTowersPHI_1_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_5_e \
    op interface \
    ports { RCTTowersPHI_1_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 137 \
    name RCTTowersPHI_1_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_6_e \
    op interface \
    ports { RCTTowersPHI_1_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 138 \
    name RCTTowersPHI_1_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_7_e \
    op interface \
    ports { RCTTowersPHI_1_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 139 \
    name RCTTowersPHI_1_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_8_e \
    op interface \
    ports { RCTTowersPHI_1_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 140 \
    name RCTTowersPHI_1_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_9_e \
    op interface \
    ports { RCTTowersPHI_1_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 141 \
    name RCTTowersPHI_1_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_10_s \
    op interface \
    ports { RCTTowersPHI_1_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 142 \
    name RCTTowersPHI_1_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_11_s \
    op interface \
    ports { RCTTowersPHI_1_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 143 \
    name RCTTowersPHI_1_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_12_s \
    op interface \
    ports { RCTTowersPHI_1_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 144 \
    name RCTTowersPHI_1_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_13_s \
    op interface \
    ports { RCTTowersPHI_1_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 145 \
    name RCTTowersPHI_1_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_14_s \
    op interface \
    ports { RCTTowersPHI_1_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 146 \
    name RCTTowersPHI_1_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_15_s \
    op interface \
    ports { RCTTowersPHI_1_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 147 \
    name RCTTowersPHI_1_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_16_s \
    op interface \
    ports { RCTTowersPHI_1_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 148 \
    name RCTTowersPHI_2_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_0_e \
    op interface \
    ports { RCTTowersPHI_2_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 149 \
    name RCTTowersPHI_2_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_1_e \
    op interface \
    ports { RCTTowersPHI_2_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 150 \
    name RCTTowersPHI_2_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_2_e \
    op interface \
    ports { RCTTowersPHI_2_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 151 \
    name RCTTowersPHI_2_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_3_e \
    op interface \
    ports { RCTTowersPHI_2_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 152 \
    name RCTTowersPHI_2_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_4_e \
    op interface \
    ports { RCTTowersPHI_2_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 153 \
    name RCTTowersPHI_2_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_5_e \
    op interface \
    ports { RCTTowersPHI_2_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 154 \
    name RCTTowersPHI_2_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_6_e \
    op interface \
    ports { RCTTowersPHI_2_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 155 \
    name RCTTowersPHI_2_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_7_e \
    op interface \
    ports { RCTTowersPHI_2_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 156 \
    name RCTTowersPHI_2_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_8_e \
    op interface \
    ports { RCTTowersPHI_2_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 157 \
    name RCTTowersPHI_2_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_9_e \
    op interface \
    ports { RCTTowersPHI_2_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 158 \
    name RCTTowersPHI_2_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_10_s \
    op interface \
    ports { RCTTowersPHI_2_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 159 \
    name RCTTowersPHI_2_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_11_s \
    op interface \
    ports { RCTTowersPHI_2_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 160 \
    name RCTTowersPHI_2_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_12_s \
    op interface \
    ports { RCTTowersPHI_2_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 161 \
    name RCTTowersPHI_2_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_13_s \
    op interface \
    ports { RCTTowersPHI_2_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 162 \
    name RCTTowersPHI_2_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_14_s \
    op interface \
    ports { RCTTowersPHI_2_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 163 \
    name RCTTowersPHI_2_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_15_s \
    op interface \
    ports { RCTTowersPHI_2_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 164 \
    name RCTTowersPHI_2_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_16_s \
    op interface \
    ports { RCTTowersPHI_2_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 165 \
    name RCTTowersPHI_3_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_0_e \
    op interface \
    ports { RCTTowersPHI_3_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 166 \
    name RCTTowersPHI_3_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_1_e \
    op interface \
    ports { RCTTowersPHI_3_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 167 \
    name RCTTowersPHI_3_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_2_e \
    op interface \
    ports { RCTTowersPHI_3_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 168 \
    name RCTTowersPHI_3_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_3_e \
    op interface \
    ports { RCTTowersPHI_3_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 169 \
    name RCTTowersPHI_3_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_4_e \
    op interface \
    ports { RCTTowersPHI_3_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 170 \
    name RCTTowersPHI_3_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_5_e \
    op interface \
    ports { RCTTowersPHI_3_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 171 \
    name RCTTowersPHI_3_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_6_e \
    op interface \
    ports { RCTTowersPHI_3_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 172 \
    name RCTTowersPHI_3_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_7_e \
    op interface \
    ports { RCTTowersPHI_3_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 173 \
    name RCTTowersPHI_3_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_8_e \
    op interface \
    ports { RCTTowersPHI_3_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 174 \
    name RCTTowersPHI_3_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_9_e \
    op interface \
    ports { RCTTowersPHI_3_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 175 \
    name RCTTowersPHI_3_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_10_s \
    op interface \
    ports { RCTTowersPHI_3_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 176 \
    name RCTTowersPHI_3_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_11_s \
    op interface \
    ports { RCTTowersPHI_3_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 177 \
    name RCTTowersPHI_3_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_12_s \
    op interface \
    ports { RCTTowersPHI_3_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 178 \
    name RCTTowersPHI_3_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_13_s \
    op interface \
    ports { RCTTowersPHI_3_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 179 \
    name RCTTowersPHI_3_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_14_s \
    op interface \
    ports { RCTTowersPHI_3_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 180 \
    name RCTTowersPHI_3_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_15_s \
    op interface \
    ports { RCTTowersPHI_3_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 181 \
    name RCTTowersPHI_3_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_16_s \
    op interface \
    ports { RCTTowersPHI_3_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 182 \
    name RCTTowersPHI_4_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_0_e \
    op interface \
    ports { RCTTowersPHI_4_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 183 \
    name RCTTowersPHI_4_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_1_e \
    op interface \
    ports { RCTTowersPHI_4_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 184 \
    name RCTTowersPHI_4_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_2_e \
    op interface \
    ports { RCTTowersPHI_4_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 185 \
    name RCTTowersPHI_4_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_3_e \
    op interface \
    ports { RCTTowersPHI_4_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 186 \
    name RCTTowersPHI_4_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_4_e \
    op interface \
    ports { RCTTowersPHI_4_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 187 \
    name RCTTowersPHI_4_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_5_e \
    op interface \
    ports { RCTTowersPHI_4_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 188 \
    name RCTTowersPHI_4_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_6_e \
    op interface \
    ports { RCTTowersPHI_4_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 189 \
    name RCTTowersPHI_4_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_7_e \
    op interface \
    ports { RCTTowersPHI_4_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 190 \
    name RCTTowersPHI_4_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_8_e \
    op interface \
    ports { RCTTowersPHI_4_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 191 \
    name RCTTowersPHI_4_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_9_e \
    op interface \
    ports { RCTTowersPHI_4_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 192 \
    name RCTTowersPHI_4_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_10_s \
    op interface \
    ports { RCTTowersPHI_4_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 193 \
    name RCTTowersPHI_4_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_11_s \
    op interface \
    ports { RCTTowersPHI_4_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 194 \
    name RCTTowersPHI_4_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_12_s \
    op interface \
    ports { RCTTowersPHI_4_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 195 \
    name RCTTowersPHI_4_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_13_s \
    op interface \
    ports { RCTTowersPHI_4_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 196 \
    name RCTTowersPHI_4_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_14_s \
    op interface \
    ports { RCTTowersPHI_4_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 197 \
    name RCTTowersPHI_4_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_15_s \
    op interface \
    ports { RCTTowersPHI_4_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 198 \
    name RCTTowersPHI_4_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_16_s \
    op interface \
    ports { RCTTowersPHI_4_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 199 \
    name RCTTowersPHI_5_0_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_0_e \
    op interface \
    ports { RCTTowersPHI_5_0_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 200 \
    name RCTTowersPHI_5_1_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_1_e \
    op interface \
    ports { RCTTowersPHI_5_1_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 201 \
    name RCTTowersPHI_5_2_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_2_e \
    op interface \
    ports { RCTTowersPHI_5_2_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 202 \
    name RCTTowersPHI_5_3_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_3_e \
    op interface \
    ports { RCTTowersPHI_5_3_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 203 \
    name RCTTowersPHI_5_4_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_4_e \
    op interface \
    ports { RCTTowersPHI_5_4_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 204 \
    name RCTTowersPHI_5_5_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_5_e \
    op interface \
    ports { RCTTowersPHI_5_5_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 205 \
    name RCTTowersPHI_5_6_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_6_e \
    op interface \
    ports { RCTTowersPHI_5_6_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 206 \
    name RCTTowersPHI_5_7_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_7_e \
    op interface \
    ports { RCTTowersPHI_5_7_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 207 \
    name RCTTowersPHI_5_8_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_8_e \
    op interface \
    ports { RCTTowersPHI_5_8_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 208 \
    name RCTTowersPHI_5_9_e \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_9_e \
    op interface \
    ports { RCTTowersPHI_5_9_e { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 209 \
    name RCTTowersPHI_5_10_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_10_s \
    op interface \
    ports { RCTTowersPHI_5_10_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 210 \
    name RCTTowersPHI_5_11_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_11_s \
    op interface \
    ports { RCTTowersPHI_5_11_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 211 \
    name RCTTowersPHI_5_12_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_12_s \
    op interface \
    ports { RCTTowersPHI_5_12_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 212 \
    name RCTTowersPHI_5_13_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_13_s \
    op interface \
    ports { RCTTowersPHI_5_13_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 213 \
    name RCTTowersPHI_5_14_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_14_s \
    op interface \
    ports { RCTTowersPHI_5_14_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 214 \
    name RCTTowersPHI_5_15_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_15_s \
    op interface \
    ports { RCTTowersPHI_5_15_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 215 \
    name RCTTowersPHI_5_16_s \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_16_s \
    op interface \
    ports { RCTTowersPHI_5_16_s { I 10 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 216 \
    name RCTTowersPHI_0_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_0_h \
    op interface \
    ports { RCTTowersPHI_0_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 217 \
    name RCTTowersPHI_0_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_1_h \
    op interface \
    ports { RCTTowersPHI_0_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 218 \
    name RCTTowersPHI_0_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_2_h \
    op interface \
    ports { RCTTowersPHI_0_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 219 \
    name RCTTowersPHI_0_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_3_h \
    op interface \
    ports { RCTTowersPHI_0_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 220 \
    name RCTTowersPHI_0_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_4_h \
    op interface \
    ports { RCTTowersPHI_0_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 221 \
    name RCTTowersPHI_0_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_5_h \
    op interface \
    ports { RCTTowersPHI_0_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 222 \
    name RCTTowersPHI_0_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_6_h \
    op interface \
    ports { RCTTowersPHI_0_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 223 \
    name RCTTowersPHI_0_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_7_h \
    op interface \
    ports { RCTTowersPHI_0_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 224 \
    name RCTTowersPHI_0_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_8_h \
    op interface \
    ports { RCTTowersPHI_0_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 225 \
    name RCTTowersPHI_0_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_9_h \
    op interface \
    ports { RCTTowersPHI_0_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 226 \
    name RCTTowersPHI_0_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_10_3 \
    op interface \
    ports { RCTTowersPHI_0_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 227 \
    name RCTTowersPHI_0_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_11_3 \
    op interface \
    ports { RCTTowersPHI_0_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 228 \
    name RCTTowersPHI_0_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_12_3 \
    op interface \
    ports { RCTTowersPHI_0_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 229 \
    name RCTTowersPHI_0_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_13_3 \
    op interface \
    ports { RCTTowersPHI_0_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 230 \
    name RCTTowersPHI_0_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_14_3 \
    op interface \
    ports { RCTTowersPHI_0_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 231 \
    name RCTTowersPHI_0_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_15_3 \
    op interface \
    ports { RCTTowersPHI_0_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 232 \
    name RCTTowersPHI_1_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_0_h \
    op interface \
    ports { RCTTowersPHI_1_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 233 \
    name RCTTowersPHI_1_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_1_h \
    op interface \
    ports { RCTTowersPHI_1_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 234 \
    name RCTTowersPHI_1_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_2_h \
    op interface \
    ports { RCTTowersPHI_1_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 235 \
    name RCTTowersPHI_1_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_3_h \
    op interface \
    ports { RCTTowersPHI_1_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 236 \
    name RCTTowersPHI_1_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_4_h \
    op interface \
    ports { RCTTowersPHI_1_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 237 \
    name RCTTowersPHI_1_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_5_h \
    op interface \
    ports { RCTTowersPHI_1_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 238 \
    name RCTTowersPHI_1_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_6_h \
    op interface \
    ports { RCTTowersPHI_1_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 239 \
    name RCTTowersPHI_1_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_7_h \
    op interface \
    ports { RCTTowersPHI_1_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 240 \
    name RCTTowersPHI_1_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_8_h \
    op interface \
    ports { RCTTowersPHI_1_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 241 \
    name RCTTowersPHI_1_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_9_h \
    op interface \
    ports { RCTTowersPHI_1_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 242 \
    name RCTTowersPHI_1_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_10_3 \
    op interface \
    ports { RCTTowersPHI_1_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 243 \
    name RCTTowersPHI_1_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_11_3 \
    op interface \
    ports { RCTTowersPHI_1_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 244 \
    name RCTTowersPHI_1_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_12_3 \
    op interface \
    ports { RCTTowersPHI_1_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 245 \
    name RCTTowersPHI_1_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_13_3 \
    op interface \
    ports { RCTTowersPHI_1_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 246 \
    name RCTTowersPHI_1_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_14_3 \
    op interface \
    ports { RCTTowersPHI_1_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 247 \
    name RCTTowersPHI_1_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_15_3 \
    op interface \
    ports { RCTTowersPHI_1_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 248 \
    name RCTTowersPHI_2_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_0_h \
    op interface \
    ports { RCTTowersPHI_2_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 249 \
    name RCTTowersPHI_2_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_1_h \
    op interface \
    ports { RCTTowersPHI_2_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 250 \
    name RCTTowersPHI_2_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_2_h \
    op interface \
    ports { RCTTowersPHI_2_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 251 \
    name RCTTowersPHI_2_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_3_h \
    op interface \
    ports { RCTTowersPHI_2_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 252 \
    name RCTTowersPHI_2_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_4_h \
    op interface \
    ports { RCTTowersPHI_2_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 253 \
    name RCTTowersPHI_2_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_5_h \
    op interface \
    ports { RCTTowersPHI_2_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 254 \
    name RCTTowersPHI_2_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_6_h \
    op interface \
    ports { RCTTowersPHI_2_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 255 \
    name RCTTowersPHI_2_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_7_h \
    op interface \
    ports { RCTTowersPHI_2_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 256 \
    name RCTTowersPHI_2_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_8_h \
    op interface \
    ports { RCTTowersPHI_2_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 257 \
    name RCTTowersPHI_2_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_9_h \
    op interface \
    ports { RCTTowersPHI_2_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 258 \
    name RCTTowersPHI_2_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_10_3 \
    op interface \
    ports { RCTTowersPHI_2_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 259 \
    name RCTTowersPHI_2_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_11_3 \
    op interface \
    ports { RCTTowersPHI_2_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 260 \
    name RCTTowersPHI_2_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_12_3 \
    op interface \
    ports { RCTTowersPHI_2_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 261 \
    name RCTTowersPHI_2_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_13_3 \
    op interface \
    ports { RCTTowersPHI_2_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 262 \
    name RCTTowersPHI_2_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_14_3 \
    op interface \
    ports { RCTTowersPHI_2_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 263 \
    name RCTTowersPHI_2_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_15_3 \
    op interface \
    ports { RCTTowersPHI_2_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 264 \
    name RCTTowersPHI_3_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_0_h \
    op interface \
    ports { RCTTowersPHI_3_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 265 \
    name RCTTowersPHI_3_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_1_h \
    op interface \
    ports { RCTTowersPHI_3_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 266 \
    name RCTTowersPHI_3_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_2_h \
    op interface \
    ports { RCTTowersPHI_3_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 267 \
    name RCTTowersPHI_3_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_3_h \
    op interface \
    ports { RCTTowersPHI_3_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 268 \
    name RCTTowersPHI_3_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_4_h \
    op interface \
    ports { RCTTowersPHI_3_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 269 \
    name RCTTowersPHI_3_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_5_h \
    op interface \
    ports { RCTTowersPHI_3_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 270 \
    name RCTTowersPHI_3_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_6_h \
    op interface \
    ports { RCTTowersPHI_3_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 271 \
    name RCTTowersPHI_3_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_7_h \
    op interface \
    ports { RCTTowersPHI_3_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 272 \
    name RCTTowersPHI_3_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_8_h \
    op interface \
    ports { RCTTowersPHI_3_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 273 \
    name RCTTowersPHI_3_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_9_h \
    op interface \
    ports { RCTTowersPHI_3_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 274 \
    name RCTTowersPHI_3_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_10_3 \
    op interface \
    ports { RCTTowersPHI_3_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 275 \
    name RCTTowersPHI_3_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_11_3 \
    op interface \
    ports { RCTTowersPHI_3_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 276 \
    name RCTTowersPHI_3_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_12_3 \
    op interface \
    ports { RCTTowersPHI_3_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 277 \
    name RCTTowersPHI_3_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_13_3 \
    op interface \
    ports { RCTTowersPHI_3_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 278 \
    name RCTTowersPHI_3_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_14_3 \
    op interface \
    ports { RCTTowersPHI_3_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 279 \
    name RCTTowersPHI_3_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_15_3 \
    op interface \
    ports { RCTTowersPHI_3_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 280 \
    name RCTTowersPHI_4_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_0_h \
    op interface \
    ports { RCTTowersPHI_4_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 281 \
    name RCTTowersPHI_4_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_1_h \
    op interface \
    ports { RCTTowersPHI_4_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 282 \
    name RCTTowersPHI_4_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_2_h \
    op interface \
    ports { RCTTowersPHI_4_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 283 \
    name RCTTowersPHI_4_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_3_h \
    op interface \
    ports { RCTTowersPHI_4_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 284 \
    name RCTTowersPHI_4_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_4_h \
    op interface \
    ports { RCTTowersPHI_4_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 285 \
    name RCTTowersPHI_4_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_5_h \
    op interface \
    ports { RCTTowersPHI_4_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 286 \
    name RCTTowersPHI_4_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_6_h \
    op interface \
    ports { RCTTowersPHI_4_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 287 \
    name RCTTowersPHI_4_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_7_h \
    op interface \
    ports { RCTTowersPHI_4_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 288 \
    name RCTTowersPHI_4_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_8_h \
    op interface \
    ports { RCTTowersPHI_4_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 289 \
    name RCTTowersPHI_4_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_9_h \
    op interface \
    ports { RCTTowersPHI_4_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 290 \
    name RCTTowersPHI_4_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_10_3 \
    op interface \
    ports { RCTTowersPHI_4_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 291 \
    name RCTTowersPHI_4_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_11_3 \
    op interface \
    ports { RCTTowersPHI_4_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 292 \
    name RCTTowersPHI_4_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_12_3 \
    op interface \
    ports { RCTTowersPHI_4_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 293 \
    name RCTTowersPHI_4_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_13_3 \
    op interface \
    ports { RCTTowersPHI_4_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 294 \
    name RCTTowersPHI_4_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_14_3 \
    op interface \
    ports { RCTTowersPHI_4_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 295 \
    name RCTTowersPHI_4_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_15_3 \
    op interface \
    ports { RCTTowersPHI_4_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 296 \
    name RCTTowersPHI_5_0_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_0_h \
    op interface \
    ports { RCTTowersPHI_5_0_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 297 \
    name RCTTowersPHI_5_1_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_1_h \
    op interface \
    ports { RCTTowersPHI_5_1_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 298 \
    name RCTTowersPHI_5_2_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_2_h \
    op interface \
    ports { RCTTowersPHI_5_2_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 299 \
    name RCTTowersPHI_5_3_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_3_h \
    op interface \
    ports { RCTTowersPHI_5_3_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 300 \
    name RCTTowersPHI_5_4_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_4_h \
    op interface \
    ports { RCTTowersPHI_5_4_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 301 \
    name RCTTowersPHI_5_5_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_5_h \
    op interface \
    ports { RCTTowersPHI_5_5_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 302 \
    name RCTTowersPHI_5_6_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_6_h \
    op interface \
    ports { RCTTowersPHI_5_6_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 303 \
    name RCTTowersPHI_5_7_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_7_h \
    op interface \
    ports { RCTTowersPHI_5_7_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 304 \
    name RCTTowersPHI_5_8_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_8_h \
    op interface \
    ports { RCTTowersPHI_5_8_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 305 \
    name RCTTowersPHI_5_9_h \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_9_h \
    op interface \
    ports { RCTTowersPHI_5_9_h { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 306 \
    name RCTTowersPHI_5_10_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_10_3 \
    op interface \
    ports { RCTTowersPHI_5_10_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 307 \
    name RCTTowersPHI_5_11_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_11_3 \
    op interface \
    ports { RCTTowersPHI_5_11_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 308 \
    name RCTTowersPHI_5_12_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_12_3 \
    op interface \
    ports { RCTTowersPHI_5_12_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 309 \
    name RCTTowersPHI_5_13_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_13_3 \
    op interface \
    ports { RCTTowersPHI_5_13_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 310 \
    name RCTTowersPHI_5_14_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_14_3 \
    op interface \
    ports { RCTTowersPHI_5_14_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 311 \
    name RCTTowersPHI_5_15_3 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_15_3 \
    op interface \
    ports { RCTTowersPHI_5_15_3 { I 4 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 312 \
    name RCTTowersPHI_0_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_0_f \
    op interface \
    ports { RCTTowersPHI_0_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 313 \
    name RCTTowersPHI_0_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_1_f \
    op interface \
    ports { RCTTowersPHI_0_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 314 \
    name RCTTowersPHI_0_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_2_f \
    op interface \
    ports { RCTTowersPHI_0_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 315 \
    name RCTTowersPHI_0_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_3_f \
    op interface \
    ports { RCTTowersPHI_0_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 316 \
    name RCTTowersPHI_0_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_4_f \
    op interface \
    ports { RCTTowersPHI_0_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 317 \
    name RCTTowersPHI_0_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_5_f \
    op interface \
    ports { RCTTowersPHI_0_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 318 \
    name RCTTowersPHI_0_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_6_f \
    op interface \
    ports { RCTTowersPHI_0_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 319 \
    name RCTTowersPHI_0_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_7_f \
    op interface \
    ports { RCTTowersPHI_0_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 320 \
    name RCTTowersPHI_0_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_8_f \
    op interface \
    ports { RCTTowersPHI_0_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 321 \
    name RCTTowersPHI_0_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_9_f \
    op interface \
    ports { RCTTowersPHI_0_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 322 \
    name RCTTowersPHI_0_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_10_4 \
    op interface \
    ports { RCTTowersPHI_0_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 323 \
    name RCTTowersPHI_0_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_11_4 \
    op interface \
    ports { RCTTowersPHI_0_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 324 \
    name RCTTowersPHI_0_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_12_4 \
    op interface \
    ports { RCTTowersPHI_0_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 325 \
    name RCTTowersPHI_0_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_13_4 \
    op interface \
    ports { RCTTowersPHI_0_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 326 \
    name RCTTowersPHI_0_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_14_4 \
    op interface \
    ports { RCTTowersPHI_0_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 327 \
    name RCTTowersPHI_0_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_15_4 \
    op interface \
    ports { RCTTowersPHI_0_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 328 \
    name RCTTowersPHI_0_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_0_16_2 \
    op interface \
    ports { RCTTowersPHI_0_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 329 \
    name RCTTowersPHI_1_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_0_f \
    op interface \
    ports { RCTTowersPHI_1_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 330 \
    name RCTTowersPHI_1_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_1_f \
    op interface \
    ports { RCTTowersPHI_1_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 331 \
    name RCTTowersPHI_1_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_2_f \
    op interface \
    ports { RCTTowersPHI_1_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 332 \
    name RCTTowersPHI_1_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_3_f \
    op interface \
    ports { RCTTowersPHI_1_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 333 \
    name RCTTowersPHI_1_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_4_f \
    op interface \
    ports { RCTTowersPHI_1_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 334 \
    name RCTTowersPHI_1_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_5_f \
    op interface \
    ports { RCTTowersPHI_1_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 335 \
    name RCTTowersPHI_1_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_6_f \
    op interface \
    ports { RCTTowersPHI_1_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 336 \
    name RCTTowersPHI_1_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_7_f \
    op interface \
    ports { RCTTowersPHI_1_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 337 \
    name RCTTowersPHI_1_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_8_f \
    op interface \
    ports { RCTTowersPHI_1_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 338 \
    name RCTTowersPHI_1_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_9_f \
    op interface \
    ports { RCTTowersPHI_1_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 339 \
    name RCTTowersPHI_1_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_10_4 \
    op interface \
    ports { RCTTowersPHI_1_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 340 \
    name RCTTowersPHI_1_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_11_4 \
    op interface \
    ports { RCTTowersPHI_1_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 341 \
    name RCTTowersPHI_1_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_12_4 \
    op interface \
    ports { RCTTowersPHI_1_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 342 \
    name RCTTowersPHI_1_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_13_4 \
    op interface \
    ports { RCTTowersPHI_1_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 343 \
    name RCTTowersPHI_1_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_14_4 \
    op interface \
    ports { RCTTowersPHI_1_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 344 \
    name RCTTowersPHI_1_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_15_4 \
    op interface \
    ports { RCTTowersPHI_1_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 345 \
    name RCTTowersPHI_1_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_1_16_2 \
    op interface \
    ports { RCTTowersPHI_1_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 346 \
    name RCTTowersPHI_2_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_0_f \
    op interface \
    ports { RCTTowersPHI_2_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 347 \
    name RCTTowersPHI_2_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_1_f \
    op interface \
    ports { RCTTowersPHI_2_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 348 \
    name RCTTowersPHI_2_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_2_f \
    op interface \
    ports { RCTTowersPHI_2_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 349 \
    name RCTTowersPHI_2_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_3_f \
    op interface \
    ports { RCTTowersPHI_2_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 350 \
    name RCTTowersPHI_2_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_4_f \
    op interface \
    ports { RCTTowersPHI_2_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 351 \
    name RCTTowersPHI_2_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_5_f \
    op interface \
    ports { RCTTowersPHI_2_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 352 \
    name RCTTowersPHI_2_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_6_f \
    op interface \
    ports { RCTTowersPHI_2_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 353 \
    name RCTTowersPHI_2_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_7_f \
    op interface \
    ports { RCTTowersPHI_2_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 354 \
    name RCTTowersPHI_2_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_8_f \
    op interface \
    ports { RCTTowersPHI_2_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 355 \
    name RCTTowersPHI_2_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_9_f \
    op interface \
    ports { RCTTowersPHI_2_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 356 \
    name RCTTowersPHI_2_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_10_4 \
    op interface \
    ports { RCTTowersPHI_2_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 357 \
    name RCTTowersPHI_2_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_11_4 \
    op interface \
    ports { RCTTowersPHI_2_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 358 \
    name RCTTowersPHI_2_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_12_4 \
    op interface \
    ports { RCTTowersPHI_2_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 359 \
    name RCTTowersPHI_2_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_13_4 \
    op interface \
    ports { RCTTowersPHI_2_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 360 \
    name RCTTowersPHI_2_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_14_4 \
    op interface \
    ports { RCTTowersPHI_2_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 361 \
    name RCTTowersPHI_2_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_15_4 \
    op interface \
    ports { RCTTowersPHI_2_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 362 \
    name RCTTowersPHI_2_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_2_16_2 \
    op interface \
    ports { RCTTowersPHI_2_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 363 \
    name RCTTowersPHI_3_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_0_f \
    op interface \
    ports { RCTTowersPHI_3_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 364 \
    name RCTTowersPHI_3_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_1_f \
    op interface \
    ports { RCTTowersPHI_3_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 365 \
    name RCTTowersPHI_3_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_2_f \
    op interface \
    ports { RCTTowersPHI_3_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 366 \
    name RCTTowersPHI_3_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_3_f \
    op interface \
    ports { RCTTowersPHI_3_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 367 \
    name RCTTowersPHI_3_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_4_f \
    op interface \
    ports { RCTTowersPHI_3_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 368 \
    name RCTTowersPHI_3_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_5_f \
    op interface \
    ports { RCTTowersPHI_3_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 369 \
    name RCTTowersPHI_3_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_6_f \
    op interface \
    ports { RCTTowersPHI_3_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 370 \
    name RCTTowersPHI_3_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_7_f \
    op interface \
    ports { RCTTowersPHI_3_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 371 \
    name RCTTowersPHI_3_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_8_f \
    op interface \
    ports { RCTTowersPHI_3_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 372 \
    name RCTTowersPHI_3_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_9_f \
    op interface \
    ports { RCTTowersPHI_3_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 373 \
    name RCTTowersPHI_3_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_10_4 \
    op interface \
    ports { RCTTowersPHI_3_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 374 \
    name RCTTowersPHI_3_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_11_4 \
    op interface \
    ports { RCTTowersPHI_3_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 375 \
    name RCTTowersPHI_3_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_12_4 \
    op interface \
    ports { RCTTowersPHI_3_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 376 \
    name RCTTowersPHI_3_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_13_4 \
    op interface \
    ports { RCTTowersPHI_3_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 377 \
    name RCTTowersPHI_3_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_14_4 \
    op interface \
    ports { RCTTowersPHI_3_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 378 \
    name RCTTowersPHI_3_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_15_4 \
    op interface \
    ports { RCTTowersPHI_3_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 379 \
    name RCTTowersPHI_3_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_3_16_2 \
    op interface \
    ports { RCTTowersPHI_3_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 380 \
    name RCTTowersPHI_4_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_0_f \
    op interface \
    ports { RCTTowersPHI_4_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 381 \
    name RCTTowersPHI_4_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_1_f \
    op interface \
    ports { RCTTowersPHI_4_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 382 \
    name RCTTowersPHI_4_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_2_f \
    op interface \
    ports { RCTTowersPHI_4_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 383 \
    name RCTTowersPHI_4_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_3_f \
    op interface \
    ports { RCTTowersPHI_4_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 384 \
    name RCTTowersPHI_4_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_4_f \
    op interface \
    ports { RCTTowersPHI_4_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 385 \
    name RCTTowersPHI_4_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_5_f \
    op interface \
    ports { RCTTowersPHI_4_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 386 \
    name RCTTowersPHI_4_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_6_f \
    op interface \
    ports { RCTTowersPHI_4_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 387 \
    name RCTTowersPHI_4_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_7_f \
    op interface \
    ports { RCTTowersPHI_4_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 388 \
    name RCTTowersPHI_4_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_8_f \
    op interface \
    ports { RCTTowersPHI_4_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 389 \
    name RCTTowersPHI_4_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_9_f \
    op interface \
    ports { RCTTowersPHI_4_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 390 \
    name RCTTowersPHI_4_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_10_4 \
    op interface \
    ports { RCTTowersPHI_4_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 391 \
    name RCTTowersPHI_4_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_11_4 \
    op interface \
    ports { RCTTowersPHI_4_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 392 \
    name RCTTowersPHI_4_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_12_4 \
    op interface \
    ports { RCTTowersPHI_4_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 393 \
    name RCTTowersPHI_4_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_13_4 \
    op interface \
    ports { RCTTowersPHI_4_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 394 \
    name RCTTowersPHI_4_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_14_4 \
    op interface \
    ports { RCTTowersPHI_4_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 395 \
    name RCTTowersPHI_4_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_15_4 \
    op interface \
    ports { RCTTowersPHI_4_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 396 \
    name RCTTowersPHI_4_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_4_16_2 \
    op interface \
    ports { RCTTowersPHI_4_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 397 \
    name RCTTowersPHI_5_0_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_0_f \
    op interface \
    ports { RCTTowersPHI_5_0_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 398 \
    name RCTTowersPHI_5_1_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_1_f \
    op interface \
    ports { RCTTowersPHI_5_1_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 399 \
    name RCTTowersPHI_5_2_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_2_f \
    op interface \
    ports { RCTTowersPHI_5_2_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 400 \
    name RCTTowersPHI_5_3_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_3_f \
    op interface \
    ports { RCTTowersPHI_5_3_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 401 \
    name RCTTowersPHI_5_4_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_4_f \
    op interface \
    ports { RCTTowersPHI_5_4_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 402 \
    name RCTTowersPHI_5_5_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_5_f \
    op interface \
    ports { RCTTowersPHI_5_5_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 403 \
    name RCTTowersPHI_5_6_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_6_f \
    op interface \
    ports { RCTTowersPHI_5_6_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 404 \
    name RCTTowersPHI_5_7_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_7_f \
    op interface \
    ports { RCTTowersPHI_5_7_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 405 \
    name RCTTowersPHI_5_8_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_8_f \
    op interface \
    ports { RCTTowersPHI_5_8_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 406 \
    name RCTTowersPHI_5_9_f \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_9_f \
    op interface \
    ports { RCTTowersPHI_5_9_f { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 407 \
    name RCTTowersPHI_5_10_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_10_4 \
    op interface \
    ports { RCTTowersPHI_5_10_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 408 \
    name RCTTowersPHI_5_11_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_11_4 \
    op interface \
    ports { RCTTowersPHI_5_11_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 409 \
    name RCTTowersPHI_5_12_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_12_4 \
    op interface \
    ports { RCTTowersPHI_5_12_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 410 \
    name RCTTowersPHI_5_13_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_13_4 \
    op interface \
    ports { RCTTowersPHI_5_13_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 411 \
    name RCTTowersPHI_5_14_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_14_4 \
    op interface \
    ports { RCTTowersPHI_5_14_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 412 \
    name RCTTowersPHI_5_15_4 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_15_4 \
    op interface \
    ports { RCTTowersPHI_5_15_4 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id 413 \
    name RCTTowersPHI_5_16_2 \
    type other \
    dir I \
    reset_level 1 \
    sync_rst true \
    corename dc_RCTTowersPHI_5_16_2 \
    op interface \
    ports { RCTTowersPHI_5_16_2 { I 2 vector } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id -1 \
    name ap_ctrl \
    type ap_ctrl \
    reset_level 1 \
    sync_rst true \
    corename ap_ctrl \
    op interface \
    ports { ap_start { I 1 bit } ap_ready { O 1 bit } ap_done { O 1 bit } ap_idle { O 1 bit } } \
} "
}

# Direct connection:
if {${::AESL::PGuard_autoexp_gen}} {
eval "cg_default_interface_gen_dc { \
    id -2 \
    name ap_return \
    type ap_return \
    reset_level 1 \
    sync_rst true \
    corename ap_return \
    op interface \
    ports { ap_return { O 1 vector } } \
} "
}


# Adapter definition:
set PortName ap_clk
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_clock] == "cg_default_interface_gen_clock"} {
eval "cg_default_interface_gen_clock { \
    id -3 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_clk \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-113\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}


# Adapter definition:
set PortName ap_rst
set DataWd 1 
if {${::AESL::PGuard_autoexp_gen}} {
if {[info proc cg_default_interface_gen_reset] == "cg_default_interface_gen_reset"} {
eval "cg_default_interface_gen_reset { \
    id -4 \
    name ${PortName} \
    reset_level 1 \
    sync_rst true \
    corename apif_ap_rst \
    data_wd ${DataWd} \
    op interface \
}"
} else {
puts "@W \[IMPL-114\] Cannot find bus interface model in the library. Ignored generation of bus interface for '${PortName}'"
}
}



# merge
if {${::AESL::PGuard_autoexp_gen}} {
    cg_default_interface_gen_dc_end
    cg_default_interface_gen_bundle_end
    AESL_LIB_XILADAPTER::native_axis_end
}


