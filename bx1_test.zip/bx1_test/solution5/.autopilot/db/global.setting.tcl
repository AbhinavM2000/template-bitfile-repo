
set TopModule "algo_top"
set ClockPeriod 2.778
set ClockList ap_clk
set HasVivadoClockPeriod 0
set CombLogicFlag 0
set PipelineFlag 1
set DataflowTaskPipelineFlag 1
set TrivialPipelineFlag 0
set noPortSwitchingFlag 0
set FloatingPointFlag 0
set FftOrFirFlag 0
set NbRWValue 0
set intNbAccess 0
set NewDSPMapping 1
set HasDSPModule 0
set ResetLevelFlag 1
set ResetStyle control
set ResetSyncFlag 1
set ResetRegisterFlag 0
set ResetVariableFlag 0
set FsmEncStyle onehot
set MaxFanout 0
set RtlPrefix {}
set ExtraCCFlags {}
set ExtraCLdFlags {}
set SynCheckOptions {}
set PresynOptions {}
set PreprocOptions {}
set SchedOptions {}
set BindOptions {}
set RtlGenOptions {}
set RtlWriterOptions {}
set CbcGenFlag {}
set CasGenFlag {}
set CasMonitorFlag {}
set AutoSimOptions {}
set ExportMCPathFlag 0
set SCTraceFileName mytrace
set SCTraceFileFormat vcd
set SCTraceOption all
set TargetInfo xcvu13p:-flga2577:-2-e
set SourceFiles {sc {} c ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top.cpp}
set SourceFlags {sc {} c {{}}}
set DirectiveFile /scratch/abnv/rct_fork/debugging_new/hls_test/bx1/bx1_test/solution5/solution5.directive
set TBFiles {verilog ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp bc ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp vhdl ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp sc ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp cas ../../../../rct-17-x-6-abnv/targets/xF13P/AlgoSRC/IP3/algo_top_tb.cpp c {}}
set SpecLanguage C
set TVInFiles {bc {} c {} sc {} cas {} vhdl {} verilog {}}
set TVOutFiles {bc {} c {} sc {} cas {} vhdl {} verilog {}}
set TBTops {verilog {} bc {} vhdl {} sc {} cas {} c {}}
set TBInstNames {verilog {} bc {} vhdl {} sc {} cas {} c {}}
set XDCFiles {}
set ExtraGlobalOptions {"area_timing" 1 "clock_gate" 1 "impl_flow" map "power_gate" 0}
set TBTVFileNotFound {}
set AppFile ../vivado_hls.app
set ApsFile solution5.aps
set AvePath ../..
set DefaultPlatform DefaultPlatform
set multiClockList {}
set SCPortClockMap {}
set intNbAccess 0
set PlatformFiles {{DefaultPlatform {xilinx/virtexuplus/virtexuplus xilinx/virtexuplus/virtexuplus_fpv7}}}
set HPFPO 0
