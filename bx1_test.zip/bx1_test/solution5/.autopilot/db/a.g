#!/bin/sh
lli=${LLVMINTERP-lli}
exec $lli \
    /scratch/abnv/rct_fork/debugging_new/hls_test/bx1/bx1_test/solution5/.autopilot/db/a.g.bc ${1+"$@"}
