set moduleName uploadHCAL
set isTopModule 0
set isTaskLevelControl 1
set isCombinational 0
set isDatapathOnly 1
set isFreeRunPipelineModule 0
set isPipelined 1
set pipeline_type function
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set C_modelName {uploadHCAL}
set C_modelType { int 16 }
set C_modelArgList {
	{ rcttower_energy_V_read int 10 regular  }
	{ rcttower_flags_V_read_2 int 2 regular  }
	{ rcttower_flags_V_read int 2 regular  }
	{ hcaltower_energy_V_read int 10 regular  }
	{ hcaltower_fb_V_read int 6 regular  }
}
set C_modelArgMapList {[ 
	{ "Name" : "rcttower_energy_V_read", "interface" : "wire", "bitwidth" : 10, "direction" : "READONLY"} , 
 	{ "Name" : "rcttower_flags_V_read_2", "interface" : "wire", "bitwidth" : 2, "direction" : "READONLY"} , 
 	{ "Name" : "rcttower_flags_V_read", "interface" : "wire", "bitwidth" : 2, "direction" : "READONLY"} , 
 	{ "Name" : "hcaltower_energy_V_read", "interface" : "wire", "bitwidth" : 10, "direction" : "READONLY"} , 
 	{ "Name" : "hcaltower_fb_V_read", "interface" : "wire", "bitwidth" : 6, "direction" : "READONLY"} , 
 	{ "Name" : "ap_return", "interface" : "wire", "bitwidth" : 16} ]}
# RTL Port declarations: 
set portNum 11
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ rcttower_energy_V_read sc_in sc_lv 10 signal 0 } 
	{ rcttower_flags_V_read_2 sc_in sc_lv 2 signal 1 } 
	{ rcttower_flags_V_read sc_in sc_lv 2 signal 2 } 
	{ hcaltower_energy_V_read sc_in sc_lv 10 signal 3 } 
	{ hcaltower_fb_V_read sc_in sc_lv 6 signal 4 } 
	{ ap_return_0 sc_out sc_lv 10 signal -1 } 
	{ ap_return_1 sc_out sc_lv 4 signal -1 } 
	{ ap_return_2 sc_out sc_lv 2 signal -1 } 
	{ ap_ce sc_in sc_logic 1 ce -1 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "rcttower_energy_V_read", "direction": "in", "datatype": "sc_lv", "bitwidth":10, "type": "signal", "bundle":{"name": "rcttower_energy_V_read", "role": "default" }} , 
 	{ "name": "rcttower_flags_V_read_2", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "rcttower_flags_V_read_2", "role": "default" }} , 
 	{ "name": "rcttower_flags_V_read", "direction": "in", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "rcttower_flags_V_read", "role": "default" }} , 
 	{ "name": "hcaltower_energy_V_read", "direction": "in", "datatype": "sc_lv", "bitwidth":10, "type": "signal", "bundle":{"name": "hcaltower_energy_V_read", "role": "default" }} , 
 	{ "name": "hcaltower_fb_V_read", "direction": "in", "datatype": "sc_lv", "bitwidth":6, "type": "signal", "bundle":{"name": "hcaltower_fb_V_read", "role": "default" }} , 
 	{ "name": "ap_return_0", "direction": "out", "datatype": "sc_lv", "bitwidth":10, "type": "signal", "bundle":{"name": "ap_return_0", "role": "default" }} , 
 	{ "name": "ap_return_1", "direction": "out", "datatype": "sc_lv", "bitwidth":4, "type": "signal", "bundle":{"name": "ap_return_1", "role": "default" }} , 
 	{ "name": "ap_return_2", "direction": "out", "datatype": "sc_lv", "bitwidth":2, "type": "signal", "bundle":{"name": "ap_return_2", "role": "default" }} , 
 	{ "name": "ap_ce", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "ce", "bundle":{"name": "ap_ce", "role": "default" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]}]}


set ArgLastReadFirstWriteLatency {
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "1", "Max" : "1"}
	, {"Name" : "Interval", "Min" : "1", "Max" : "1"}
]}

set PipelineEnableSignalInfo {[
]}

set Spec2ImplPortList { 
	rcttower_energy_V_read { ap_none {  { rcttower_energy_V_read in_data 0 10 } } }
	rcttower_flags_V_read_2 { ap_none {  { rcttower_flags_V_read_2 in_data 0 2 } } }
	rcttower_flags_V_read { ap_none {  { rcttower_flags_V_read in_data 0 2 } } }
	hcaltower_energy_V_read { ap_none {  { hcaltower_energy_V_read in_data 0 10 } } }
	hcaltower_fb_V_read { ap_none {  { hcaltower_fb_V_read in_data 0 6 } } }
}
