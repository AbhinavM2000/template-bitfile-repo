set moduleName algo_top
set isTopModule 1
set isTaskLevelControl 1
set isCombinational 0
set isDatapathOnly 0
set isFreeRunPipelineModule 0
set isPipelined 1
set pipeline_type function
set FunctionProtocol ap_ctrl_hs
set isOneStateSeq 0
set ProfileFlag 0
set StallSigGenFlag 0
set isEnableWaveformDebug 1
set C_modelName {algo_top}
set C_modelType { void 0 }
set C_modelArgList {
	{ link_in_0_V int 576 regular {pointer 0}  }
	{ link_in_1_V int 576 regular {pointer 0}  }
	{ link_in_2_V int 576 regular {pointer 0}  }
	{ link_in_3_V int 576 regular {pointer 0}  }
	{ link_in_4_V int 576 regular {pointer 0}  }
	{ link_in_5_V int 576 regular {pointer 0}  }
	{ link_in_6_V int 576 regular {pointer 0}  }
	{ link_in_7_V int 576 regular {pointer 0}  }
	{ link_in_8_V int 576 regular {pointer 0}  }
	{ link_out_0_V int 576 regular {pointer 1}  }
	{ link_out_1_V int 576 regular {pointer 1}  }
	{ link_out_2_V int 576 regular {pointer 1}  }
	{ link_out_3_V int 576 regular {pointer 1}  }
}
set C_modelArgMapList {[ 
	{ "Name" : "link_in_0_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 0,"up" : 0,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_1_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 1,"up" : 1,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_2_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 2,"up" : 2,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_3_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 3,"up" : 3,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_4_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 4,"up" : 4,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_5_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 5,"up" : 5,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_6_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 6,"up" : 6,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_7_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 7,"up" : 7,"step" : 2}]}]}]} , 
 	{ "Name" : "link_in_8_V", "interface" : "wire", "bitwidth" : 576, "direction" : "READONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_in.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 8,"up" : 8,"step" : 2}]}]}]} , 
 	{ "Name" : "link_out_0_V", "interface" : "wire", "bitwidth" : 576, "direction" : "WRITEONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_out.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 0,"up" : 0,"step" : 2}]}]}]} , 
 	{ "Name" : "link_out_1_V", "interface" : "wire", "bitwidth" : 576, "direction" : "WRITEONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_out.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 1,"up" : 1,"step" : 2}]}]}]} , 
 	{ "Name" : "link_out_2_V", "interface" : "wire", "bitwidth" : 576, "direction" : "WRITEONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_out.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 2,"up" : 2,"step" : 2}]}]}]} , 
 	{ "Name" : "link_out_3_V", "interface" : "wire", "bitwidth" : 576, "direction" : "WRITEONLY", "bitSlice":[{"low":0,"up":575,"cElement": [{"cName": "link_out.V","cData": "uint576","bit_use": { "low": 0,"up": 575},"cArray": [{"low" : 3,"up" : 3,"step" : 2}]}]}]} ]}
# RTL Port declarations: 
set portNum 23
set portList { 
	{ ap_clk sc_in sc_logic 1 clock -1 } 
	{ ap_rst sc_in sc_logic 1 reset -1 active_high_sync } 
	{ ap_start sc_in sc_logic 1 start -1 } 
	{ ap_done sc_out sc_logic 1 predone -1 } 
	{ ap_idle sc_out sc_logic 1 done -1 } 
	{ ap_ready sc_out sc_logic 1 ready -1 } 
	{ link_in_0_V sc_in sc_lv 576 signal 0 } 
	{ link_in_1_V sc_in sc_lv 576 signal 1 } 
	{ link_in_2_V sc_in sc_lv 576 signal 2 } 
	{ link_in_3_V sc_in sc_lv 576 signal 3 } 
	{ link_in_4_V sc_in sc_lv 576 signal 4 } 
	{ link_in_5_V sc_in sc_lv 576 signal 5 } 
	{ link_in_6_V sc_in sc_lv 576 signal 6 } 
	{ link_in_7_V sc_in sc_lv 576 signal 7 } 
	{ link_in_8_V sc_in sc_lv 576 signal 8 } 
	{ link_out_0_V sc_out sc_lv 576 signal 9 } 
	{ link_out_0_V_ap_vld sc_out sc_logic 1 outvld 9 } 
	{ link_out_1_V sc_out sc_lv 576 signal 10 } 
	{ link_out_1_V_ap_vld sc_out sc_logic 1 outvld 10 } 
	{ link_out_2_V sc_out sc_lv 576 signal 11 } 
	{ link_out_2_V_ap_vld sc_out sc_logic 1 outvld 11 } 
	{ link_out_3_V sc_out sc_lv 576 signal 12 } 
	{ link_out_3_V_ap_vld sc_out sc_logic 1 outvld 12 } 
}
set NewPortList {[ 
	{ "name": "ap_clk", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "clock", "bundle":{"name": "ap_clk", "role": "default" }} , 
 	{ "name": "ap_rst", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "reset", "bundle":{"name": "ap_rst", "role": "default" }} , 
 	{ "name": "ap_start", "direction": "in", "datatype": "sc_logic", "bitwidth":1, "type": "start", "bundle":{"name": "ap_start", "role": "default" }} , 
 	{ "name": "ap_done", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "predone", "bundle":{"name": "ap_done", "role": "default" }} , 
 	{ "name": "ap_idle", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "done", "bundle":{"name": "ap_idle", "role": "default" }} , 
 	{ "name": "ap_ready", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "ready", "bundle":{"name": "ap_ready", "role": "default" }} , 
 	{ "name": "link_in_0_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_0_V", "role": "default" }} , 
 	{ "name": "link_in_1_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_1_V", "role": "default" }} , 
 	{ "name": "link_in_2_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_2_V", "role": "default" }} , 
 	{ "name": "link_in_3_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_3_V", "role": "default" }} , 
 	{ "name": "link_in_4_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_4_V", "role": "default" }} , 
 	{ "name": "link_in_5_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_5_V", "role": "default" }} , 
 	{ "name": "link_in_6_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_6_V", "role": "default" }} , 
 	{ "name": "link_in_7_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_7_V", "role": "default" }} , 
 	{ "name": "link_in_8_V", "direction": "in", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_in_8_V", "role": "default" }} , 
 	{ "name": "link_out_0_V", "direction": "out", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_out_0_V", "role": "default" }} , 
 	{ "name": "link_out_0_V_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "link_out_0_V", "role": "ap_vld" }} , 
 	{ "name": "link_out_1_V", "direction": "out", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_out_1_V", "role": "default" }} , 
 	{ "name": "link_out_1_V_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "link_out_1_V", "role": "ap_vld" }} , 
 	{ "name": "link_out_2_V", "direction": "out", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_out_2_V", "role": "default" }} , 
 	{ "name": "link_out_2_V_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "link_out_2_V", "role": "ap_vld" }} , 
 	{ "name": "link_out_3_V", "direction": "out", "datatype": "sc_lv", "bitwidth":576, "type": "signal", "bundle":{"name": "link_out_3_V", "role": "default" }} , 
 	{ "name": "link_out_3_V_ap_vld", "direction": "out", "datatype": "sc_logic", "bitwidth":1, "type": "outvld", "bundle":{"name": "link_out_3_V", "role": "ap_vld" }}  ]}

set RtlHierarchyInfo {[
	{"ID" : "0", "Level" : "0", "Path" : "`AUTOTB_DUT_INST", "Parent" : "", "Child" : ["1", "54"],
		"CDFG" : "algo_top",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "9",
		"VariableLatency" : "0", "ExactLatency" : "27", "EstimateLatencyMin" : "27", "EstimateLatencyMax" : "27",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "link_in_0_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_1_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_2_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_3_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_4_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_5_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_6_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_7_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_8_V", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_out_0_V", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "link_out_1_V", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "link_out_2_V", "Type" : "Vld", "Direction" : "O"},
			{"Name" : "link_out_3_V", "Type" : "Vld", "Direction" : "O"}]},
	{"ID" : "1", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136", "Parent" : "0", "Child" : ["2", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53"],
		"CDFG" : "processInputLinks",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "9",
		"VariableLatency" : "0", "ExactLatency" : "18", "EstimateLatencyMin" : "18", "EstimateLatencyMax" : "18",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "link_in_0_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_1_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_2_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_3_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_4_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_5_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_6_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_7_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_8_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "2", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218", "Parent" : "1", "Child" : ["3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"],
		"CDFG" : "getECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "9",
		"VariableLatency" : "0", "ExactLatency" : "8", "EstimateLatencyMin" : "8", "EstimateLatencyMax" : "8",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "link_in_1_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_2_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_3_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "link_in_4_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "3", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_156", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "4", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_161", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "5", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_166", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "6", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_171", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "7", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_176", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "8", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_181", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "9", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_186", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "10", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_191", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "11", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_196", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "12", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_201", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "13", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_206", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "14", "Level" : "3", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_getECAL_fu_218.grp_fillecaltower_fu_211", "Parent" : "2",
		"CDFG" : "fillecaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "15", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_230", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "16", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_239", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "17", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_248", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "18", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_257", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "19", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_266", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "20", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_275", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "21", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_284", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "22", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_293", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "23", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_302", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "24", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_311", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "25", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadHCAL_fu_320", "Parent" : "1",
		"CDFG" : "uploadHCAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "0", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "1", "EstimateLatencyMin" : "1", "EstimateLatencyMax" : "1",
		"Combinational" : "0",
		"Datapath" : "1",
		"ClockEnable" : "1",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "rcttower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "rcttower_flags_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "hcaltower_fb_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "26", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_329", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "27", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_335", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "28", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_341", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "29", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_347", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "30", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_353", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "31", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_359", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "32", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_365", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "33", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_371", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "34", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_377", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "35", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_383", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "36", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_389", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "37", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_uploadECAL_fu_395", "Parent" : "1",
		"CDFG" : "uploadECAL",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "ecaltower_energy_V_read", "Type" : "None", "Direction" : "I"},
			{"Name" : "ecaltower_timing_V_read", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "38", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillrctecalcluster_fu_401", "Parent" : "1",
		"CDFG" : "fillrctecalcluster",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "39", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_406", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "40", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_411", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "41", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_416", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "42", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_421", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "43", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_426", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "44", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_431", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "45", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_436", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "46", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_441", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "47", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_446", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "48", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_451", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "49", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_456", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "50", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_461", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "51", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_466", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "52", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_471", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "53", "Level" : "2", "Path" : "`AUTOTB_DUT_INST.grp_processInputLinks_fu_136.grp_fillhcaltower_fu_476", "Parent" : "1",
		"CDFG" : "fillhcaltower",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "0", "ap_start" : "0", "ap_ready" : "1", "ap_done" : "0", "ap_continue" : "0", "ap_idle" : "0",
		"Pipeline" : "None", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "1",
		"VariableLatency" : "0", "ExactLatency" : "0", "EstimateLatencyMin" : "0", "EstimateLatencyMax" : "0",
		"Combinational" : "1",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "i_V", "Type" : "None", "Direction" : "I"}]},
	{"ID" : "54", "Level" : "1", "Path" : "`AUTOTB_DUT_INST.grp_processOutLinks_fu_158", "Parent" : "0",
		"CDFG" : "processOutLinks",
		"Protocol" : "ap_ctrl_hs",
		"ControlExist" : "1", "ap_start" : "1", "ap_ready" : "1", "ap_done" : "1", "ap_continue" : "0", "ap_idle" : "1",
		"Pipeline" : "Aligned", "UnalignedPipeline" : "0", "RewindPipeline" : "0", "ProcessNetwork" : "0",
		"II" : "9",
		"VariableLatency" : "0", "ExactLatency" : "9", "EstimateLatencyMin" : "9", "EstimateLatencyMax" : "9",
		"Combinational" : "0",
		"Datapath" : "0",
		"ClockEnable" : "0",
		"HasSubDataflow" : "0",
		"InDataflowNetwork" : "0",
		"HasNonBlockingOperation" : "0",
		"Port" : [
			{"Name" : "RCTECALClusters_0_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_e_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_p", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_e_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_w", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_t", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_s_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_s_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_0_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_1_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_2_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_3_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_4_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_5_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_6_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_7_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTECALClusters_8_b", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_0_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_1_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_2_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_3_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_4_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_5_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_6_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_7_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_8_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_9_e", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_10_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_11_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_12_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_13_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_14_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_15_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_16_s", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_0_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_1_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_2_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_3_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_4_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_5_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_6_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_7_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_8_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_9_h", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_10_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_11_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_12_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_13_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_14_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_15_3", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_0_16_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_1_16_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_2_16_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_3_16_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_4_16_2", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_0_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_1_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_2_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_3_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_4_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_5_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_6_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_7_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_8_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_9_f", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_10_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_11_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_12_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_13_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_14_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_15_4", "Type" : "None", "Direction" : "I"},
			{"Name" : "RCTTowersPHI_5_16_2", "Type" : "None", "Direction" : "I"}]}]}


set ArgLastReadFirstWriteLatency {
	algo_top {
		link_in_0_V {Type I LastRead 0 FirstWrite -1}
		link_in_1_V {Type I LastRead 0 FirstWrite -1}
		link_in_2_V {Type I LastRead 0 FirstWrite -1}
		link_in_3_V {Type I LastRead 0 FirstWrite -1}
		link_in_4_V {Type I LastRead 0 FirstWrite -1}
		link_in_5_V {Type I LastRead 0 FirstWrite -1}
		link_in_6_V {Type I LastRead 0 FirstWrite -1}
		link_in_7_V {Type I LastRead 0 FirstWrite -1}
		link_in_8_V {Type I LastRead 0 FirstWrite -1}
		link_out_0_V {Type O LastRead -1 FirstWrite 27}
		link_out_1_V {Type O LastRead -1 FirstWrite 27}
		link_out_2_V {Type O LastRead -1 FirstWrite 27}
		link_out_3_V {Type O LastRead -1 FirstWrite 27}}
	processInputLinks {
		link_in_0_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_1_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_2_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_3_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_4_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_5_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_6_V_read {Type I LastRead 2 FirstWrite -1}
		link_in_7_V_read {Type I LastRead 4 FirstWrite -1}
		link_in_8_V_read {Type I LastRead 5 FirstWrite -1}}
	getECAL {
		link_in_1_V_read {Type I LastRead 0 FirstWrite -1}
		link_in_2_V_read {Type I LastRead 2 FirstWrite -1}
		link_in_3_V_read {Type I LastRead 5 FirstWrite -1}
		link_in_4_V_read {Type I LastRead 7 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillecaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadHCAL {
		rcttower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read_2 {Type I LastRead 0 FirstWrite -1}
		rcttower_flags_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		hcaltower_fb_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	uploadECAL {
		ecaltower_energy_V_read {Type I LastRead 0 FirstWrite -1}
		ecaltower_timing_V_read {Type I LastRead 0 FirstWrite -1}}
	fillrctecalcluster {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	fillhcaltower {
		i_V {Type I LastRead 0 FirstWrite -1}}
	processOutLinks {
		RCTECALClusters_0_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_s {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_e {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_e_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_p {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_e_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_w {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_t {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_s_3 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_s_4 {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_0_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_1_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_2_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_3_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_4_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_5_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_6_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_7_b {Type I LastRead 8 FirstWrite -1}
		RCTECALClusters_8_b {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_0_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_1_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_2_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_3_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_4_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_5_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_6_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_7_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_8_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_9_e {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_10_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_11_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_12_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_13_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_14_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_15_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_16_s {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_0_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_1_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_2_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_3_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_4_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_5_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_6_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_7_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_8_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_9_h {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_10_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_11_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_12_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_13_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_14_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_15_3 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_0_16_2 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_1_16_2 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_2_16_2 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_3_16_2 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_4_16_2 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_0_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_1_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_2_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_3_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_4_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_5_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_6_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_7_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_8_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_9_f {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_10_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_11_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_12_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_13_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_14_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_15_4 {Type I LastRead 8 FirstWrite -1}
		RCTTowersPHI_5_16_2 {Type I LastRead 8 FirstWrite -1}}}

set hasDtUnsupportedChannel 0

set PerformanceInfo {[
	{"Name" : "Latency", "Min" : "27", "Max" : "27"}
	, {"Name" : "Interval", "Min" : "9", "Max" : "9"}
]}

set PipelineEnableSignalInfo {[
	{"Pipeline" : "0", "EnableSignal" : "ap_enable_pp0"}
]}

set Spec2ImplPortList { 
	link_in_0_V { ap_none {  { link_in_0_V in_data 0 576 } } }
	link_in_1_V { ap_none {  { link_in_1_V in_data 0 576 } } }
	link_in_2_V { ap_none {  { link_in_2_V in_data 0 576 } } }
	link_in_3_V { ap_none {  { link_in_3_V in_data 0 576 } } }
	link_in_4_V { ap_none {  { link_in_4_V in_data 0 576 } } }
	link_in_5_V { ap_none {  { link_in_5_V in_data 0 576 } } }
	link_in_6_V { ap_none {  { link_in_6_V in_data 0 576 } } }
	link_in_7_V { ap_none {  { link_in_7_V in_data 0 576 } } }
	link_in_8_V { ap_none {  { link_in_8_V in_data 0 576 } } }
	link_out_0_V { ap_vld {  { link_out_0_V out_data 1 576 }  { link_out_0_V_ap_vld out_vld 1 1 } } }
	link_out_1_V { ap_vld {  { link_out_1_V out_data 1 576 }  { link_out_1_V_ap_vld out_vld 1 1 } } }
	link_out_2_V { ap_vld {  { link_out_2_V out_data 1 576 }  { link_out_2_V_ap_vld out_vld 1 1 } } }
	link_out_3_V { ap_vld {  { link_out_3_V out_data 1 576 }  { link_out_3_V_ap_vld out_vld 1 1 } } }
}

set busDeadlockParameterList { 
}

# RTL port scheduling information:
set fifoSchedulingInfoList { 
}

# RTL bus port read request latency information:
set busReadReqLatencyList { 
}

# RTL bus port write response latency information:
set busWriteResLatencyList { 
}

# RTL array port load latency information:
set memoryLoadLatencyList { 
}
