set depth_list {
{link_in_0_V 1}
{link_in_1_V 1}
{link_in_2_V 1}
{link_in_3_V 1}
{link_in_4_V 1}
{link_in_5_V 1}
{link_in_6_V 1}
{link_in_7_V 1}
{link_in_8_V 1}
{link_out_0_V 1}
{link_out_1_V 1}
{link_out_2_V 1}
{link_out_3_V 1}
}
set trans_num 1
