set clock_constraint { \
    name clk \
    module algo_top \
    port ap_clk \
    period 2.778 \
    uncertainty 0.833 \
}

set all_path {}

set false_path {}

