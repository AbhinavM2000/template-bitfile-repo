#include "processInputLinks.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void processInputLinks::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[0];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[1];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage2() {
    ap_CS_fsm_pp0_stage2 = ap_CS_fsm.read()[2];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage3() {
    ap_CS_fsm_pp0_stage3 = ap_CS_fsm.read()[3];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage4() {
    ap_CS_fsm_pp0_stage4 = ap_CS_fsm.read()[4];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage5() {
    ap_CS_fsm_pp0_stage5 = ap_CS_fsm.read()[5];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage6() {
    ap_CS_fsm_pp0_stage6 = ap_CS_fsm.read()[6];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage7() {
    ap_CS_fsm_pp0_stage7 = ap_CS_fsm.read()[7];
}

void processInputLinks::thread_ap_CS_fsm_pp0_stage8() {
    ap_CS_fsm_pp0_stage8 = ap_CS_fsm.read()[8];
}

void processInputLinks::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp870() {
    ap_block_pp0_stage0_11001_ignoreCallOp870 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp871() {
    ap_block_pp0_stage0_11001_ignoreCallOp871 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp872() {
    ap_block_pp0_stage0_11001_ignoreCallOp872 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp873() {
    ap_block_pp0_stage0_11001_ignoreCallOp873 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp874() {
    ap_block_pp0_stage0_11001_ignoreCallOp874 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp875() {
    ap_block_pp0_stage0_11001_ignoreCallOp875 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp876() {
    ap_block_pp0_stage0_11001_ignoreCallOp876 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp877() {
    ap_block_pp0_stage0_11001_ignoreCallOp877 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp878() {
    ap_block_pp0_stage0_11001_ignoreCallOp878 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp879() {
    ap_block_pp0_stage0_11001_ignoreCallOp879 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_11001_ignoreCallOp880() {
    ap_block_pp0_stage0_11001_ignoreCallOp880 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void processInputLinks::thread_ap_block_pp0_stage1() {
    ap_block_pp0_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001() {
    ap_block_pp0_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp917() {
    ap_block_pp0_stage1_11001_ignoreCallOp917 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp921() {
    ap_block_pp0_stage1_11001_ignoreCallOp921 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp925() {
    ap_block_pp0_stage1_11001_ignoreCallOp925 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp929() {
    ap_block_pp0_stage1_11001_ignoreCallOp929 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp933() {
    ap_block_pp0_stage1_11001_ignoreCallOp933 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp937() {
    ap_block_pp0_stage1_11001_ignoreCallOp937 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp941() {
    ap_block_pp0_stage1_11001_ignoreCallOp941 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp945() {
    ap_block_pp0_stage1_11001_ignoreCallOp945 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp949() {
    ap_block_pp0_stage1_11001_ignoreCallOp949 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp953() {
    ap_block_pp0_stage1_11001_ignoreCallOp953 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_11001_ignoreCallOp957() {
    ap_block_pp0_stage1_11001_ignoreCallOp957 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage1_subdone() {
    ap_block_pp0_stage1_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2() {
    ap_block_pp0_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001() {
    ap_block_pp0_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1012() {
    ap_block_pp0_stage2_11001_ignoreCallOp1012 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1016() {
    ap_block_pp0_stage2_11001_ignoreCallOp1016 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1020() {
    ap_block_pp0_stage2_11001_ignoreCallOp1020 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1024() {
    ap_block_pp0_stage2_11001_ignoreCallOp1024 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1028() {
    ap_block_pp0_stage2_11001_ignoreCallOp1028 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1032() {
    ap_block_pp0_stage2_11001_ignoreCallOp1032 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1036() {
    ap_block_pp0_stage2_11001_ignoreCallOp1036 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1040() {
    ap_block_pp0_stage2_11001_ignoreCallOp1040 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1044() {
    ap_block_pp0_stage2_11001_ignoreCallOp1044 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1050() {
    ap_block_pp0_stage2_11001_ignoreCallOp1050 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_11001_ignoreCallOp1054() {
    ap_block_pp0_stage2_11001_ignoreCallOp1054 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage2_subdone() {
    ap_block_pp0_stage2_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3() {
    ap_block_pp0_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001() {
    ap_block_pp0_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1099() {
    ap_block_pp0_stage3_11001_ignoreCallOp1099 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1103() {
    ap_block_pp0_stage3_11001_ignoreCallOp1103 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1107() {
    ap_block_pp0_stage3_11001_ignoreCallOp1107 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1111() {
    ap_block_pp0_stage3_11001_ignoreCallOp1111 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1123() {
    ap_block_pp0_stage3_11001_ignoreCallOp1123 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1127() {
    ap_block_pp0_stage3_11001_ignoreCallOp1127 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1134() {
    ap_block_pp0_stage3_11001_ignoreCallOp1134 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1138() {
    ap_block_pp0_stage3_11001_ignoreCallOp1138 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1142() {
    ap_block_pp0_stage3_11001_ignoreCallOp1142 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1146() {
    ap_block_pp0_stage3_11001_ignoreCallOp1146 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_11001_ignoreCallOp1150() {
    ap_block_pp0_stage3_11001_ignoreCallOp1150 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage3_subdone() {
    ap_block_pp0_stage3_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4() {
    ap_block_pp0_stage4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001() {
    ap_block_pp0_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1190() {
    ap_block_pp0_stage4_11001_ignoreCallOp1190 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1194() {
    ap_block_pp0_stage4_11001_ignoreCallOp1194 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1198() {
    ap_block_pp0_stage4_11001_ignoreCallOp1198 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1202() {
    ap_block_pp0_stage4_11001_ignoreCallOp1202 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1206() {
    ap_block_pp0_stage4_11001_ignoreCallOp1206 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1210() {
    ap_block_pp0_stage4_11001_ignoreCallOp1210 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1214() {
    ap_block_pp0_stage4_11001_ignoreCallOp1214 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1218() {
    ap_block_pp0_stage4_11001_ignoreCallOp1218 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1222() {
    ap_block_pp0_stage4_11001_ignoreCallOp1222 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1226() {
    ap_block_pp0_stage4_11001_ignoreCallOp1226 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_11001_ignoreCallOp1230() {
    ap_block_pp0_stage4_11001_ignoreCallOp1230 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage4_subdone() {
    ap_block_pp0_stage4_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5() {
    ap_block_pp0_stage5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001() {
    ap_block_pp0_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1291() {
    ap_block_pp0_stage5_11001_ignoreCallOp1291 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1296() {
    ap_block_pp0_stage5_11001_ignoreCallOp1296 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1300() {
    ap_block_pp0_stage5_11001_ignoreCallOp1300 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1304() {
    ap_block_pp0_stage5_11001_ignoreCallOp1304 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1308() {
    ap_block_pp0_stage5_11001_ignoreCallOp1308 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1312() {
    ap_block_pp0_stage5_11001_ignoreCallOp1312 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1316() {
    ap_block_pp0_stage5_11001_ignoreCallOp1316 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1320() {
    ap_block_pp0_stage5_11001_ignoreCallOp1320 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1324() {
    ap_block_pp0_stage5_11001_ignoreCallOp1324 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1328() {
    ap_block_pp0_stage5_11001_ignoreCallOp1328 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_11001_ignoreCallOp1332() {
    ap_block_pp0_stage5_11001_ignoreCallOp1332 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage5_subdone() {
    ap_block_pp0_stage5_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6() {
    ap_block_pp0_stage6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001() {
    ap_block_pp0_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1372() {
    ap_block_pp0_stage6_11001_ignoreCallOp1372 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1376() {
    ap_block_pp0_stage6_11001_ignoreCallOp1376 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1380() {
    ap_block_pp0_stage6_11001_ignoreCallOp1380 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1384() {
    ap_block_pp0_stage6_11001_ignoreCallOp1384 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1388() {
    ap_block_pp0_stage6_11001_ignoreCallOp1388 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1392() {
    ap_block_pp0_stage6_11001_ignoreCallOp1392 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1396() {
    ap_block_pp0_stage6_11001_ignoreCallOp1396 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1400() {
    ap_block_pp0_stage6_11001_ignoreCallOp1400 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1404() {
    ap_block_pp0_stage6_11001_ignoreCallOp1404 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1408() {
    ap_block_pp0_stage6_11001_ignoreCallOp1408 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_11001_ignoreCallOp1412() {
    ap_block_pp0_stage6_11001_ignoreCallOp1412 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage6_subdone() {
    ap_block_pp0_stage6_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7() {
    ap_block_pp0_stage7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001() {
    ap_block_pp0_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1447() {
    ap_block_pp0_stage7_11001_ignoreCallOp1447 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1451() {
    ap_block_pp0_stage7_11001_ignoreCallOp1451 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1455() {
    ap_block_pp0_stage7_11001_ignoreCallOp1455 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1459() {
    ap_block_pp0_stage7_11001_ignoreCallOp1459 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1464() {
    ap_block_pp0_stage7_11001_ignoreCallOp1464 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1468() {
    ap_block_pp0_stage7_11001_ignoreCallOp1468 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1472() {
    ap_block_pp0_stage7_11001_ignoreCallOp1472 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1476() {
    ap_block_pp0_stage7_11001_ignoreCallOp1476 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1480() {
    ap_block_pp0_stage7_11001_ignoreCallOp1480 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1485() {
    ap_block_pp0_stage7_11001_ignoreCallOp1485 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_11001_ignoreCallOp1489() {
    ap_block_pp0_stage7_11001_ignoreCallOp1489 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage7_subdone() {
    ap_block_pp0_stage7_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8() {
    ap_block_pp0_stage8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001() {
    ap_block_pp0_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1500() {
    ap_block_pp0_stage8_11001_ignoreCallOp1500 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1504() {
    ap_block_pp0_stage8_11001_ignoreCallOp1504 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1508() {
    ap_block_pp0_stage8_11001_ignoreCallOp1508 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1512() {
    ap_block_pp0_stage8_11001_ignoreCallOp1512 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1516() {
    ap_block_pp0_stage8_11001_ignoreCallOp1516 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1520() {
    ap_block_pp0_stage8_11001_ignoreCallOp1520 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1524() {
    ap_block_pp0_stage8_11001_ignoreCallOp1524 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1528() {
    ap_block_pp0_stage8_11001_ignoreCallOp1528 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1532() {
    ap_block_pp0_stage8_11001_ignoreCallOp1532 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1536() {
    ap_block_pp0_stage8_11001_ignoreCallOp1536 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_11001_ignoreCallOp1540() {
    ap_block_pp0_stage8_11001_ignoreCallOp1540 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_pp0_stage8_subdone() {
    ap_block_pp0_stage8_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1() {
    ap_block_state10_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1076() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1076 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1080() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1080 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1084() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1084 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1088() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1088 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1092() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1092 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1108() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1108 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1112() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1112 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1116() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1116 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1120() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1120 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1124() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1124 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state10_pp0_stage0_iter1_ignore_call1140() {
    ap_block_state10_pp0_stage0_iter1_ignore_call1140 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1() {
    ap_block_state11_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1076() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1076 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1080() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1080 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1084() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1084 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1088() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1088 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1092() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1092 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1108() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1108 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1112() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1112 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1116() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1116 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1120() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1120 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1124() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1124 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state11_pp0_stage1_iter1_ignore_call1140() {
    ap_block_state11_pp0_stage1_iter1_ignore_call1140 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1() {
    ap_block_state12_pp0_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1144() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1144 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1148() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1148 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1152() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1152 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1156() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1156 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1172() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1172 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1176() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1176 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1180() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1180 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1184() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1184 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1188() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1188 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1332() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1332 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state12_pp0_stage2_iter1_ignore_call1336() {
    ap_block_state12_pp0_stage2_iter1_ignore_call1336 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1() {
    ap_block_state13_pp0_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1096() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1096 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1100() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1100 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1104() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1104 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1128() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1128 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1204() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1204 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1208() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1208 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1340() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1340 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1344() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1344 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1348() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1348 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1364() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1364 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state13_pp0_stage3_iter1_ignore_call1368() {
    ap_block_state13_pp0_stage3_iter1_ignore_call1368 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1() {
    ap_block_state14_pp0_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1132() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1132 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1136() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1136 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1160() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1160 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1164() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1164 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1168() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1168 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1192() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1192 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1196() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1196 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1200() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1200 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1236() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1236 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1240() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1240 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state14_pp0_stage4_iter1_ignore_call1268() {
    ap_block_state14_pp0_stage4_iter1_ignore_call1268 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1() {
    ap_block_state15_pp0_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1272() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1272 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1300() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1300 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1304() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1304 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1352() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1352 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1356() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1356 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1360() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1360 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1372() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1372 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1376() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1376 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1380() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1380 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1384() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1384 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state15_pp0_stage5_iter1_ignore_call1388() {
    ap_block_state15_pp0_stage5_iter1_ignore_call1388 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1() {
    ap_block_state16_pp0_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1212() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1212 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1216() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1216 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1220() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1220 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1224() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1224 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1228() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1228 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1244() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1244 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1248() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1248 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1252() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1252 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1256() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1256 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1260() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1260 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state16_pp0_stage6_iter1_ignore_call1276() {
    ap_block_state16_pp0_stage6_iter1_ignore_call1276 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1() {
    ap_block_state17_pp0_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1280() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1280 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1284() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1284 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1288() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1288 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1292() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1292 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1308() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1308 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1312() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1312 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1316() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1316 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1320() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1320 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1324() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1324 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1392() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1392 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state17_pp0_stage7_iter1_ignore_call1396() {
    ap_block_state17_pp0_stage7_iter1_ignore_call1396 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1() {
    ap_block_state18_pp0_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1232() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1232 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1264() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1264 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1296() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1296 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1328() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1328 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1400() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1400 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1404() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1404 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1408() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1408 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1412() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1412 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1416() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1416 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1420() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1420 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state18_pp0_stage8_iter1_ignore_call1424() {
    ap_block_state18_pp0_stage8_iter1_ignore_call1424 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2() {
    ap_block_state19_pp0_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1076() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1076 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1080() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1080 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1084() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1084 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1088() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1088 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1092() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1092 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1108() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1108 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1112() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1112 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1116() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1116 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1120() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1120 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1124() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1124 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state19_pp0_stage0_iter2_ignore_call1140() {
    ap_block_state19_pp0_stage0_iter2_ignore_call1140 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0() {
    ap_block_state1_pp0_stage0_iter0 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1076() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1076 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1080() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1080 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1084() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1084 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1088() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1088 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1092() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1092 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1108() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1108 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1112() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1112 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1116() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1116 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1120() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1120 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1124() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1124 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state1_pp0_stage0_iter0_ignore_call1140() {
    ap_block_state1_pp0_stage0_iter0_ignore_call1140 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0() {
    ap_block_state2_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1076() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1076 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1080() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1080 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1084() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1084 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1088() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1088 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1092() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1092 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1108() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1108 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1112() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1112 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1116() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1116 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1120() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1120 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1124() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1124 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state2_pp0_stage1_iter0_ignore_call1140() {
    ap_block_state2_pp0_stage1_iter0_ignore_call1140 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0() {
    ap_block_state3_pp0_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1144() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1144 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1148() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1148 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1152() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1152 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1156() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1156 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1172() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1172 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1176() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1176 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1180() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1180 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1184() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1184 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1188() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1188 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1332() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1332 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state3_pp0_stage2_iter0_ignore_call1336() {
    ap_block_state3_pp0_stage2_iter0_ignore_call1336 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0() {
    ap_block_state4_pp0_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1096() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1096 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1100() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1100 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1104() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1104 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1128() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1128 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1204() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1204 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1208() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1208 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1340() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1340 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1344() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1344 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1348() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1348 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1364() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1364 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state4_pp0_stage3_iter0_ignore_call1368() {
    ap_block_state4_pp0_stage3_iter0_ignore_call1368 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0() {
    ap_block_state5_pp0_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1132() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1132 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1136() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1136 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1160() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1160 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1164() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1164 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1168() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1168 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1192() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1192 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1196() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1196 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1200() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1200 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1236() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1236 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1240() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1240 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state5_pp0_stage4_iter0_ignore_call1268() {
    ap_block_state5_pp0_stage4_iter0_ignore_call1268 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0() {
    ap_block_state6_pp0_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1272() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1272 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1300() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1300 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1304() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1304 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1352() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1352 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1356() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1356 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1360() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1360 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1372() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1372 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1376() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1376 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1380() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1380 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1384() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1384 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state6_pp0_stage5_iter0_ignore_call1388() {
    ap_block_state6_pp0_stage5_iter0_ignore_call1388 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0() {
    ap_block_state7_pp0_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1212() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1212 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1216() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1216 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1220() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1220 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1224() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1224 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1228() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1228 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1244() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1244 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1248() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1248 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1252() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1252 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1256() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1256 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1260() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1260 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state7_pp0_stage6_iter0_ignore_call1276() {
    ap_block_state7_pp0_stage6_iter0_ignore_call1276 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0() {
    ap_block_state8_pp0_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1280() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1280 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1284() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1284 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1288() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1288 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1292() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1292 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1308() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1308 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1312() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1312 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1316() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1316 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1320() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1320 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1324() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1324 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1392() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1392 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state8_pp0_stage7_iter0_ignore_call1396() {
    ap_block_state8_pp0_stage7_iter0_ignore_call1396 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0() {
    ap_block_state9_pp0_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1232() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1232 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1264() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1264 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1296() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1296 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1328() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1328 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1400() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1400 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1404() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1404 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1408() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1408 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1412() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1412 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1416() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1416 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1420() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1420 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_block_state9_pp0_stage8_iter0_ignore_call1424() {
    ap_block_state9_pp0_stage8_iter0_ignore_call1424 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void processInputLinks::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void processInputLinks::thread_ap_enable_reg_pp0_iter0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read())) {
        ap_enable_reg_pp0_iter0 = ap_start.read();
    } else {
        ap_enable_reg_pp0_iter0 = ap_enable_reg_pp0_iter0_reg.read();
    }
}

void processInputLinks::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_idle_pp0_0to1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0_0to1 = ap_const_logic_1;
    } else {
        ap_idle_pp0_0to1 = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_idle_pp0_1to2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()))) {
        ap_idle_pp0_1to2 = ap_const_logic_1;
    } else {
        ap_idle_pp0_1to2 = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to1.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void processInputLinks::thread_ap_return_0() {
    ap_return_0 = RCTECALClusters_0_s_reg_5446_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_1() {
    ap_return_1 = RCTECALClusters_1_s_reg_5771_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_10() {
    ap_return_10 = RCTECALClusters_1_e_reg_5776_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_100() {
    ap_return_100 = RCTTowersPHI_energy_129_reg_9043.read();
}

void processInputLinks::thread_ap_return_101() {
    ap_return_101 = RCTTowersPHI_energy_130_reg_9058.read();
}

void processInputLinks::thread_ap_return_102() {
    ap_return_102 = RCTTowersPHI_energy_131_reg_9073.read();
}

void processInputLinks::thread_ap_return_103() {
    ap_return_103 = RCTTowersPHI_energy_132_reg_9088.read();
}

void processInputLinks::thread_ap_return_104() {
    ap_return_104 = RCTTowersPHI_energy_133_reg_9103.read();
}

void processInputLinks::thread_ap_return_105() {
    ap_return_105 = RCTTowersPHI_energy_134_reg_9403.read();
}

void processInputLinks::thread_ap_return_106() {
    ap_return_106 = RCTTowersPHI_energy_103_reg_8271.read();
}

void processInputLinks::thread_ap_return_107() {
    ap_return_107 = RCTTowersPHI_energy_104_reg_8286.read();
}

void processInputLinks::thread_ap_return_108() {
    ap_return_108 = RCTTowersPHI_energy_105_reg_8301.read();
}

void processInputLinks::thread_ap_return_109() {
    ap_return_109 = RCTTowersPHI_energy_106_reg_8316.read();
}

void processInputLinks::thread_ap_return_11() {
    ap_return_11 = RCTECALClusters_2_e_reg_5976_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_110() {
    ap_return_110 = RCTTowersPHI_energy_107_reg_8331.read();
}

void processInputLinks::thread_ap_return_111() {
    ap_return_111 = RCTTowersPHI_energy_108_reg_8571.read();
}

void processInputLinks::thread_ap_return_112() {
    ap_return_112 = RCTTowersPHI_energy_109_reg_8691.read();
}

void processInputLinks::thread_ap_return_113() {
    ap_return_113 = RCTTowersPHI_energy_110_reg_8706.read();
}

void processInputLinks::thread_ap_return_114() {
    ap_return_114 = RCTTowersPHI_energy_135_reg_8811.read();
}

void processInputLinks::thread_ap_return_115() {
    ap_return_115 = RCTTowersPHI_energy_136_reg_8826.read();
}

void processInputLinks::thread_ap_return_116() {
    ap_return_116 = RCTTowersPHI_energy_137_reg_9118.read();
}

void processInputLinks::thread_ap_return_117() {
    ap_return_117 = RCTTowersPHI_energy_138_reg_9133.read();
}

void processInputLinks::thread_ap_return_118() {
    ap_return_118 = RCTTowersPHI_energy_139_reg_9148.read();
}

void processInputLinks::thread_ap_return_119() {
    ap_return_119 = RCTTowersPHI_energy_140_reg_9163.read();
}

void processInputLinks::thread_ap_return_12() {
    ap_return_12 = RCTECALClusters_3_e_reg_6271_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_120() {
    ap_return_120 = RCTTowersPHI_energy_141_reg_9178.read();
}

void processInputLinks::thread_ap_return_121() {
    ap_return_121 = RCTTowersPHI_energy_142_reg_9418.read();
}

void processInputLinks::thread_ap_return_122() {
    ap_return_122 = RCTTowersPHI_energy_111_reg_8346.read();
}

void processInputLinks::thread_ap_return_123() {
    ap_return_123 = RCTTowersPHI_energy_112_reg_8361.read();
}

void processInputLinks::thread_ap_return_124() {
    ap_return_124 = RCTTowersPHI_energy_113_reg_8376.read();
}

void processInputLinks::thread_ap_return_125() {
    ap_return_125 = RCTTowersPHI_energy_114_reg_8391.read();
}

void processInputLinks::thread_ap_return_126() {
    ap_return_126 = RCTTowersPHI_energy_115_reg_8406.read();
}

void processInputLinks::thread_ap_return_127() {
    ap_return_127 = RCTTowersPHI_energy_116_reg_8721.read();
}

void processInputLinks::thread_ap_return_128() {
    ap_return_128 = RCTTowersPHI_energy_117_reg_8736.read();
}

void processInputLinks::thread_ap_return_129() {
    ap_return_129 = RCTTowersPHI_energy_118_reg_8751.read();
}

void processInputLinks::thread_ap_return_13() {
    ap_return_13 = RCTECALClusters_4_e_reg_6471_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_130() {
    ap_return_130 = RCTTowersPHI_energy_143_reg_8841.read();
}

void processInputLinks::thread_ap_return_131() {
    ap_return_131 = RCTTowersPHI_energy_144_reg_8867.read();
}

void processInputLinks::thread_ap_return_132() {
    ap_return_132 = RCTTowersPHI_energy_145_reg_9193.read();
}

void processInputLinks::thread_ap_return_133() {
    ap_return_133 = RCTTowersPHI_energy_146_reg_9238.read();
}

void processInputLinks::thread_ap_return_134() {
    ap_return_134 = RCTTowersPHI_energy_147_reg_9253.read();
}

void processInputLinks::thread_ap_return_135() {
    ap_return_135 = RCTTowersPHI_energy_148_reg_9268.read();
}

void processInputLinks::thread_ap_return_136() {
    ap_return_136 = RCTTowersPHI_energy_149_reg_9283.read();
}

void processInputLinks::thread_ap_return_137() {
    ap_return_137 = RCTTowersPHI_energy_150_reg_9433.read();
}

void processInputLinks::thread_ap_return_138() {
    ap_return_138 = RCTTowersPHI_energy_119_reg_8421.read();
}

void processInputLinks::thread_ap_return_139() {
    ap_return_139 = RCTTowersPHI_energy_120_reg_8436.read();
}

void processInputLinks::thread_ap_return_14() {
    ap_return_14 = RCTECALClusters_5_e_reg_6776_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_140() {
    ap_return_140 = RCTTowersPHI_energy_121_reg_8451.read();
}

void processInputLinks::thread_ap_return_141() {
    ap_return_141 = RCTTowersPHI_energy_122_reg_8466.read();
}

void processInputLinks::thread_ap_return_142() {
    ap_return_142 = RCTTowersPHI_energy_123_reg_8481.read();
}

void processInputLinks::thread_ap_return_143() {
    ap_return_143 = RCTTowersPHI_energy_124_reg_8766.read();
}

void processInputLinks::thread_ap_return_144() {
    ap_return_144 = RCTTowersPHI_energy_125_reg_8781.read();
}

void processInputLinks::thread_ap_return_145() {
    ap_return_145 = RCTTowersPHI_energy_126_reg_8796.read();
}

void processInputLinks::thread_ap_return_146() {
    ap_return_146 = RCTTowersPHI_energy_151_reg_8882.read();
}

void processInputLinks::thread_ap_return_147() {
    ap_return_147 = RCTTowersPHI_energy_152_reg_8897.read();
}

void processInputLinks::thread_ap_return_148() {
    ap_return_148 = RCTTowersPHI_energy_153_reg_9298.read();
}

void processInputLinks::thread_ap_return_149() {
    ap_return_149 = RCTTowersPHI_energy_154_reg_9313.read();
}

void processInputLinks::thread_ap_return_15() {
    ap_return_15 = RCTECALClusters_6_e_reg_7086_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_150() {
    ap_return_150 = RCTTowersPHI_energy_155_reg_9328.read();
}

void processInputLinks::thread_ap_return_151() {
    ap_return_151 = RCTTowersPHI_energy_156_reg_9343.read();
}

void processInputLinks::thread_ap_return_152() {
    ap_return_152 = RCTTowersPHI_energy_157_reg_9358.read();
}

void processInputLinks::thread_ap_return_153() {
    ap_return_153 = RCTTowersPHI_energy_158_reg_9448.read();
}

void processInputLinks::thread_ap_return_154() {
    ap_return_154 = RCTTowersPHI_energy_159_reg_8496.read();
}

void processInputLinks::thread_ap_return_155() {
    ap_return_155 = RCTTowersPHI_energy_160_reg_8511.read();
}

void processInputLinks::thread_ap_return_156() {
    ap_return_156 = RCTTowersPHI_energy_161_reg_8616.read();
}

void processInputLinks::thread_ap_return_157() {
    ap_return_157 = RCTTowersPHI_energy_162_reg_8631.read();
}

void processInputLinks::thread_ap_return_158() {
    ap_return_158 = RCTTowersPHI_energy_163_reg_8646.read();
}

void processInputLinks::thread_ap_return_159() {
    ap_return_159 = RCTTowersPHI_energy_164_reg_8912.read();
}

void processInputLinks::thread_ap_return_16() {
    ap_return_16 = RCTECALClusters_7_e_reg_7196_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_160() {
    ap_return_160 = RCTTowersPHI_energy_165_reg_8927.read();
}

void processInputLinks::thread_ap_return_161() {
    ap_return_161 = RCTTowersPHI_energy_166_reg_8942.read();
}

void processInputLinks::thread_ap_return_162() {
    ap_return_162 = RCTTowersPHI_energy_175_reg_9388.read();
}

void processInputLinks::thread_ap_return_163() {
    ap_return_163 = RCTTowersPHI_energy_176_reg_9463.read();
}

void processInputLinks::thread_ap_return_164() {
    ap_return_164 = RCTTowersPHI_energy_177_reg_9478.read();
}

void processInputLinks::thread_ap_return_165() {
    ap_return_165 = RCTTowersPHI_energy_178_reg_9493.read();
}

void processInputLinks::thread_ap_return_166() {
    ap_return_166 = RCTTowersPHI_energy_179_reg_9508.read();
}

void processInputLinks::thread_ap_return_167() {
    ap_return_167 = RCTTowersPHI_energy_180_reg_9523.read();
}

void processInputLinks::thread_ap_return_168() {
    ap_return_168 = RCTTowersPHI_energy_181_reg_9538.read();
}

void processInputLinks::thread_ap_return_169() {
    ap_return_169 = RCTTowersPHI_energy_182_reg_9553.read();
}

void processInputLinks::thread_ap_return_17() {
    ap_return_17 = RCTECALClusters_8_e_reg_7246_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_170() {
    ap_return_170 = RCTTowersPHI_energy_167_reg_8661.read();
}

void processInputLinks::thread_ap_return_171() {
    ap_return_171 = RCTTowersPHI_energy_168_reg_8676.read();
}

void processInputLinks::thread_ap_return_172() {
    ap_return_172 = RCTTowersPHI_energy_169_reg_8957.read();
}

void processInputLinks::thread_ap_return_173() {
    ap_return_173 = RCTTowersPHI_energy_170_reg_8972.read();
}

void processInputLinks::thread_ap_return_174() {
    ap_return_174 = RCTTowersPHI_energy_171_reg_8987.read();
}

void processInputLinks::thread_ap_return_175() {
    ap_return_175 = RCTTowersPHI_energy_172_reg_9002.read();
}

void processInputLinks::thread_ap_return_176() {
    ap_return_176 = RCTTowersPHI_energy_173_reg_9017.read();
}

void processInputLinks::thread_ap_return_177() {
    ap_return_177 = RCTTowersPHI_energy_174_reg_9373.read();
}

void processInputLinks::thread_ap_return_178() {
    ap_return_178 = grp_uploadHCAL_fu_230_ap_return_0.read();
}

void processInputLinks::thread_ap_return_179() {
    ap_return_179 = grp_uploadHCAL_fu_239_ap_return_0.read();
}

void processInputLinks::thread_ap_return_18() {
    ap_return_18 = RCTECALClusters_0_e_5_reg_5456_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_180() {
    ap_return_180 = grp_uploadHCAL_fu_248_ap_return_0.read();
}

void processInputLinks::thread_ap_return_181() {
    ap_return_181 = grp_uploadHCAL_fu_257_ap_return_0.read();
}

void processInputLinks::thread_ap_return_182() {
    ap_return_182 = grp_uploadHCAL_fu_266_ap_return_0.read();
}

void processInputLinks::thread_ap_return_183() {
    ap_return_183 = grp_uploadHCAL_fu_275_ap_return_0.read();
}

void processInputLinks::thread_ap_return_184() {
    ap_return_184 = grp_uploadHCAL_fu_284_ap_return_0.read();
}

void processInputLinks::thread_ap_return_185() {
    ap_return_185 = grp_uploadHCAL_fu_293_ap_return_0.read();
}

void processInputLinks::thread_ap_return_186() {
    ap_return_186 = RCTTowersPHI_0_0_h_reg_8191.read();
}

void processInputLinks::thread_ap_return_187() {
    ap_return_187 = RCTTowersPHI_0_1_h_reg_8206.read();
}

void processInputLinks::thread_ap_return_188() {
    ap_return_188 = RCTTowersPHI_0_2_h_reg_8221.read();
}

void processInputLinks::thread_ap_return_189() {
    ap_return_189 = RCTTowersPHI_0_3_h_reg_8236.read();
}

void processInputLinks::thread_ap_return_19() {
    ap_return_19 = RCTECALClusters_1_e_5_reg_5781_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_190() {
    ap_return_190 = RCTTowersPHI_0_4_h_reg_8251.read();
}

void processInputLinks::thread_ap_return_191() {
    ap_return_191 = RCTTowersPHI_0_5_h_reg_8521.read();
}

void processInputLinks::thread_ap_return_192() {
    ap_return_192 = RCTTowersPHI_0_6_h_reg_8536.read();
}

void processInputLinks::thread_ap_return_193() {
    ap_return_193 = RCTTowersPHI_0_7_h_reg_8551.read();
}

void processInputLinks::thread_ap_return_194() {
    ap_return_194 = RCTTowersPHI_0_8_h_reg_8581.read();
}

void processInputLinks::thread_ap_return_195() {
    ap_return_195 = RCTTowersPHI_0_9_h_reg_8596.read();
}

void processInputLinks::thread_ap_return_196() {
    ap_return_196 = RCTTowersPHI_0_10_s_reg_9038.read();
}

void processInputLinks::thread_ap_return_197() {
    ap_return_197 = RCTTowersPHI_0_11_s_reg_9053.read();
}

void processInputLinks::thread_ap_return_198() {
    ap_return_198 = RCTTowersPHI_0_12_s_reg_9068.read();
}

void processInputLinks::thread_ap_return_199() {
    ap_return_199 = RCTTowersPHI_0_13_s_reg_9083.read();
}

void processInputLinks::thread_ap_return_2() {
    ap_return_2 = RCTECALClusters_2_s_reg_5971_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_20() {
    ap_return_20 = RCTECALClusters_2_e_5_reg_5981_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_200() {
    ap_return_200 = RCTTowersPHI_0_14_s_reg_9098.read();
}

void processInputLinks::thread_ap_return_201() {
    ap_return_201 = RCTTowersPHI_0_15_s_reg_9398.read();
}

void processInputLinks::thread_ap_return_202() {
    ap_return_202 = RCTTowersPHI_1_0_h_reg_8266.read();
}

void processInputLinks::thread_ap_return_203() {
    ap_return_203 = RCTTowersPHI_1_1_h_reg_8281.read();
}

void processInputLinks::thread_ap_return_204() {
    ap_return_204 = RCTTowersPHI_1_2_h_reg_8296.read();
}

void processInputLinks::thread_ap_return_205() {
    ap_return_205 = RCTTowersPHI_1_3_h_reg_8311.read();
}

void processInputLinks::thread_ap_return_206() {
    ap_return_206 = RCTTowersPHI_1_4_h_reg_8326.read();
}

void processInputLinks::thread_ap_return_207() {
    ap_return_207 = RCTTowersPHI_1_5_h_reg_8566.read();
}

void processInputLinks::thread_ap_return_208() {
    ap_return_208 = RCTTowersPHI_1_6_h_reg_8686.read();
}

void processInputLinks::thread_ap_return_209() {
    ap_return_209 = RCTTowersPHI_1_7_h_reg_8701.read();
}

void processInputLinks::thread_ap_return_21() {
    ap_return_21 = RCTECALClusters_3_e_5_reg_6276_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_210() {
    ap_return_210 = RCTTowersPHI_1_8_h_reg_8806.read();
}

void processInputLinks::thread_ap_return_211() {
    ap_return_211 = RCTTowersPHI_1_9_h_reg_8821.read();
}

void processInputLinks::thread_ap_return_212() {
    ap_return_212 = RCTTowersPHI_1_10_s_reg_9113.read();
}

void processInputLinks::thread_ap_return_213() {
    ap_return_213 = RCTTowersPHI_1_11_s_reg_9128.read();
}

void processInputLinks::thread_ap_return_214() {
    ap_return_214 = RCTTowersPHI_1_12_s_reg_9143.read();
}

void processInputLinks::thread_ap_return_215() {
    ap_return_215 = RCTTowersPHI_1_13_s_reg_9158.read();
}

void processInputLinks::thread_ap_return_216() {
    ap_return_216 = RCTTowersPHI_1_14_s_reg_9173.read();
}

void processInputLinks::thread_ap_return_217() {
    ap_return_217 = RCTTowersPHI_1_15_s_reg_9413.read();
}

void processInputLinks::thread_ap_return_218() {
    ap_return_218 = RCTTowersPHI_2_0_h_reg_8341.read();
}

void processInputLinks::thread_ap_return_219() {
    ap_return_219 = RCTTowersPHI_2_1_h_reg_8356.read();
}

void processInputLinks::thread_ap_return_22() {
    ap_return_22 = RCTECALClusters_4_e_5_reg_6476_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_220() {
    ap_return_220 = RCTTowersPHI_2_2_h_reg_8371.read();
}

void processInputLinks::thread_ap_return_221() {
    ap_return_221 = RCTTowersPHI_2_3_h_reg_8386.read();
}

void processInputLinks::thread_ap_return_222() {
    ap_return_222 = RCTTowersPHI_2_4_h_reg_8401.read();
}

void processInputLinks::thread_ap_return_223() {
    ap_return_223 = RCTTowersPHI_2_5_h_reg_8716.read();
}

void processInputLinks::thread_ap_return_224() {
    ap_return_224 = RCTTowersPHI_2_6_h_reg_8731.read();
}

void processInputLinks::thread_ap_return_225() {
    ap_return_225 = RCTTowersPHI_2_7_h_reg_8746.read();
}

void processInputLinks::thread_ap_return_226() {
    ap_return_226 = RCTTowersPHI_2_8_h_reg_8836.read();
}

void processInputLinks::thread_ap_return_227() {
    ap_return_227 = RCTTowersPHI_2_9_h_reg_8862.read();
}

void processInputLinks::thread_ap_return_228() {
    ap_return_228 = RCTTowersPHI_2_10_s_reg_9188.read();
}

void processInputLinks::thread_ap_return_229() {
    ap_return_229 = RCTTowersPHI_2_11_s_reg_9233.read();
}

void processInputLinks::thread_ap_return_23() {
    ap_return_23 = RCTECALClusters_5_e_5_reg_6781_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_230() {
    ap_return_230 = RCTTowersPHI_2_12_s_reg_9248.read();
}

void processInputLinks::thread_ap_return_231() {
    ap_return_231 = RCTTowersPHI_2_13_s_reg_9263.read();
}

void processInputLinks::thread_ap_return_232() {
    ap_return_232 = RCTTowersPHI_2_14_s_reg_9278.read();
}

void processInputLinks::thread_ap_return_233() {
    ap_return_233 = RCTTowersPHI_2_15_s_reg_9428.read();
}

void processInputLinks::thread_ap_return_234() {
    ap_return_234 = RCTTowersPHI_3_0_h_reg_8416.read();
}

void processInputLinks::thread_ap_return_235() {
    ap_return_235 = RCTTowersPHI_3_1_h_reg_8431.read();
}

void processInputLinks::thread_ap_return_236() {
    ap_return_236 = RCTTowersPHI_3_2_h_reg_8446.read();
}

void processInputLinks::thread_ap_return_237() {
    ap_return_237 = RCTTowersPHI_3_3_h_reg_8461.read();
}

void processInputLinks::thread_ap_return_238() {
    ap_return_238 = RCTTowersPHI_3_4_h_reg_8476.read();
}

void processInputLinks::thread_ap_return_239() {
    ap_return_239 = RCTTowersPHI_3_5_h_reg_8761.read();
}

void processInputLinks::thread_ap_return_24() {
    ap_return_24 = RCTECALClusters_6_e_5_reg_7091_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_240() {
    ap_return_240 = RCTTowersPHI_3_6_h_reg_8776.read();
}

void processInputLinks::thread_ap_return_241() {
    ap_return_241 = RCTTowersPHI_3_7_h_reg_8791.read();
}

void processInputLinks::thread_ap_return_242() {
    ap_return_242 = RCTTowersPHI_3_8_h_reg_8877.read();
}

void processInputLinks::thread_ap_return_243() {
    ap_return_243 = RCTTowersPHI_3_9_h_reg_8892.read();
}

void processInputLinks::thread_ap_return_244() {
    ap_return_244 = RCTTowersPHI_3_10_s_reg_9293.read();
}

void processInputLinks::thread_ap_return_245() {
    ap_return_245 = RCTTowersPHI_3_11_s_reg_9308.read();
}

void processInputLinks::thread_ap_return_246() {
    ap_return_246 = RCTTowersPHI_3_12_s_reg_9323.read();
}

void processInputLinks::thread_ap_return_247() {
    ap_return_247 = RCTTowersPHI_3_13_s_reg_9338.read();
}

void processInputLinks::thread_ap_return_248() {
    ap_return_248 = RCTTowersPHI_3_14_s_reg_9353.read();
}

void processInputLinks::thread_ap_return_249() {
    ap_return_249 = RCTTowersPHI_3_15_s_reg_9443.read();
}

void processInputLinks::thread_ap_return_25() {
    ap_return_25 = RCTECALClusters_7_e_5_reg_7201_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_250() {
    ap_return_250 = RCTTowersPHI_4_0_h_reg_8491.read();
}

void processInputLinks::thread_ap_return_251() {
    ap_return_251 = RCTTowersPHI_4_1_h_reg_8506.read();
}

void processInputLinks::thread_ap_return_252() {
    ap_return_252 = RCTTowersPHI_4_2_h_reg_8611.read();
}

void processInputLinks::thread_ap_return_253() {
    ap_return_253 = RCTTowersPHI_4_3_h_reg_8626.read();
}

void processInputLinks::thread_ap_return_254() {
    ap_return_254 = RCTTowersPHI_4_4_h_reg_8641.read();
}

void processInputLinks::thread_ap_return_255() {
    ap_return_255 = RCTTowersPHI_4_5_h_reg_8907.read();
}

void processInputLinks::thread_ap_return_256() {
    ap_return_256 = RCTTowersPHI_4_6_h_reg_8922.read();
}

void processInputLinks::thread_ap_return_257() {
    ap_return_257 = RCTTowersPHI_4_7_h_reg_8937.read();
}

void processInputLinks::thread_ap_return_258() {
    ap_return_258 = RCTTowersPHI_4_8_h_reg_9383.read();
}

void processInputLinks::thread_ap_return_259() {
    ap_return_259 = RCTTowersPHI_4_9_h_reg_9458.read();
}

void processInputLinks::thread_ap_return_26() {
    ap_return_26 = RCTECALClusters_8_e_5_reg_7251_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_260() {
    ap_return_260 = RCTTowersPHI_4_10_s_reg_9473.read();
}

void processInputLinks::thread_ap_return_261() {
    ap_return_261 = RCTTowersPHI_4_11_s_reg_9488.read();
}

void processInputLinks::thread_ap_return_262() {
    ap_return_262 = RCTTowersPHI_4_12_s_reg_9503.read();
}

void processInputLinks::thread_ap_return_263() {
    ap_return_263 = RCTTowersPHI_4_13_s_reg_9518.read();
}

void processInputLinks::thread_ap_return_264() {
    ap_return_264 = RCTTowersPHI_4_14_s_reg_9533.read();
}

void processInputLinks::thread_ap_return_265() {
    ap_return_265 = RCTTowersPHI_4_15_s_reg_9548.read();
}

void processInputLinks::thread_ap_return_266() {
    ap_return_266 = RCTTowersPHI_5_0_h_reg_8656.read();
}

void processInputLinks::thread_ap_return_267() {
    ap_return_267 = RCTTowersPHI_5_1_h_reg_8671.read();
}

void processInputLinks::thread_ap_return_268() {
    ap_return_268 = RCTTowersPHI_5_2_h_reg_8952.read();
}

void processInputLinks::thread_ap_return_269() {
    ap_return_269 = RCTTowersPHI_5_3_h_reg_8967.read();
}

void processInputLinks::thread_ap_return_27() {
    ap_return_27 = RCTECALClusters_0_p_reg_5461_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_270() {
    ap_return_270 = RCTTowersPHI_5_4_h_reg_8982.read();
}

void processInputLinks::thread_ap_return_271() {
    ap_return_271 = RCTTowersPHI_5_5_h_reg_8997.read();
}

void processInputLinks::thread_ap_return_272() {
    ap_return_272 = RCTTowersPHI_5_6_h_reg_9012.read();
}

void processInputLinks::thread_ap_return_273() {
    ap_return_273 = RCTTowersPHI_5_7_h_reg_9368.read();
}

void processInputLinks::thread_ap_return_274() {
    ap_return_274 = grp_uploadHCAL_fu_230_ap_return_1.read();
}

void processInputLinks::thread_ap_return_275() {
    ap_return_275 = grp_uploadHCAL_fu_239_ap_return_1.read();
}

void processInputLinks::thread_ap_return_276() {
    ap_return_276 = grp_uploadHCAL_fu_248_ap_return_1.read();
}

void processInputLinks::thread_ap_return_277() {
    ap_return_277 = grp_uploadHCAL_fu_257_ap_return_1.read();
}

void processInputLinks::thread_ap_return_278() {
    ap_return_278 = grp_uploadHCAL_fu_266_ap_return_1.read();
}

void processInputLinks::thread_ap_return_279() {
    ap_return_279 = grp_uploadHCAL_fu_275_ap_return_1.read();
}

void processInputLinks::thread_ap_return_28() {
    ap_return_28 = RCTECALClusters_1_p_reg_5786_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_280() {
    ap_return_280 = grp_uploadHCAL_fu_284_ap_return_1.read();
}

void processInputLinks::thread_ap_return_281() {
    ap_return_281 = grp_uploadHCAL_fu_293_ap_return_1.read();
}

void processInputLinks::thread_ap_return_282() {
    ap_return_282 = RCTTowersPHI_flags_V_reg_8201.read();
}

void processInputLinks::thread_ap_return_283() {
    ap_return_283 = RCTTowersPHI_flags_V_96_reg_8216.read();
}

void processInputLinks::thread_ap_return_284() {
    ap_return_284 = RCTTowersPHI_flags_V_97_reg_8231.read();
}

void processInputLinks::thread_ap_return_285() {
    ap_return_285 = RCTTowersPHI_flags_V_98_reg_8246.read();
}

void processInputLinks::thread_ap_return_286() {
    ap_return_286 = RCTTowersPHI_flags_V_99_reg_8261.read();
}

void processInputLinks::thread_ap_return_287() {
    ap_return_287 = RCTTowersPHI_flags_V_100_reg_8531.read();
}

void processInputLinks::thread_ap_return_288() {
    ap_return_288 = RCTTowersPHI_flags_V_101_reg_8546.read();
}

void processInputLinks::thread_ap_return_289() {
    ap_return_289 = RCTTowersPHI_flags_V_102_reg_8561.read();
}

void processInputLinks::thread_ap_return_29() {
    ap_return_29 = RCTECALClusters_2_p_reg_5986_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_290() {
    ap_return_290 = RCTTowersPHI_flags_V_127_reg_8591.read();
}

void processInputLinks::thread_ap_return_291() {
    ap_return_291 = RCTTowersPHI_flags_V_128_reg_8606.read();
}

void processInputLinks::thread_ap_return_292() {
    ap_return_292 = RCTTowersPHI_flags_V_129_reg_9048.read();
}

void processInputLinks::thread_ap_return_293() {
    ap_return_293 = RCTTowersPHI_flags_V_130_reg_9063.read();
}

void processInputLinks::thread_ap_return_294() {
    ap_return_294 = RCTTowersPHI_flags_V_131_reg_9078.read();
}

void processInputLinks::thread_ap_return_295() {
    ap_return_295 = RCTTowersPHI_flags_V_132_reg_9093.read();
}

void processInputLinks::thread_ap_return_296() {
    ap_return_296 = RCTTowersPHI_flags_V_133_reg_9108.read();
}

void processInputLinks::thread_ap_return_297() {
    ap_return_297 = RCTTowersPHI_flags_V_134_reg_9408.read();
}

void processInputLinks::thread_ap_return_298() {
    ap_return_298 = RCTTowersPHI_flags_V_103_reg_8276.read();
}

void processInputLinks::thread_ap_return_299() {
    ap_return_299 = RCTTowersPHI_flags_V_104_reg_8291.read();
}

void processInputLinks::thread_ap_return_3() {
    ap_return_3 = RCTECALClusters_3_s_reg_6266_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_30() {
    ap_return_30 = RCTECALClusters_3_p_reg_6281_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_300() {
    ap_return_300 = RCTTowersPHI_flags_V_105_reg_8306.read();
}

void processInputLinks::thread_ap_return_301() {
    ap_return_301 = RCTTowersPHI_flags_V_106_reg_8321.read();
}

void processInputLinks::thread_ap_return_302() {
    ap_return_302 = RCTTowersPHI_flags_V_107_reg_8336.read();
}

void processInputLinks::thread_ap_return_303() {
    ap_return_303 = RCTTowersPHI_flags_V_108_reg_8576.read();
}

void processInputLinks::thread_ap_return_304() {
    ap_return_304 = RCTTowersPHI_flags_V_109_reg_8696.read();
}

void processInputLinks::thread_ap_return_305() {
    ap_return_305 = RCTTowersPHI_flags_V_110_reg_8711.read();
}

void processInputLinks::thread_ap_return_306() {
    ap_return_306 = RCTTowersPHI_flags_V_135_reg_8816.read();
}

void processInputLinks::thread_ap_return_307() {
    ap_return_307 = RCTTowersPHI_flags_V_136_reg_8831.read();
}

void processInputLinks::thread_ap_return_308() {
    ap_return_308 = RCTTowersPHI_flags_V_137_reg_9123.read();
}

void processInputLinks::thread_ap_return_309() {
    ap_return_309 = RCTTowersPHI_flags_V_138_reg_9138.read();
}

void processInputLinks::thread_ap_return_31() {
    ap_return_31 = RCTECALClusters_4_p_reg_6481_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_310() {
    ap_return_310 = RCTTowersPHI_flags_V_139_reg_9153.read();
}

void processInputLinks::thread_ap_return_311() {
    ap_return_311 = RCTTowersPHI_flags_V_140_reg_9168.read();
}

void processInputLinks::thread_ap_return_312() {
    ap_return_312 = RCTTowersPHI_flags_V_141_reg_9183.read();
}

void processInputLinks::thread_ap_return_313() {
    ap_return_313 = RCTTowersPHI_flags_V_142_reg_9423.read();
}

void processInputLinks::thread_ap_return_314() {
    ap_return_314 = RCTTowersPHI_flags_V_111_reg_8351.read();
}

void processInputLinks::thread_ap_return_315() {
    ap_return_315 = RCTTowersPHI_flags_V_112_reg_8366.read();
}

void processInputLinks::thread_ap_return_316() {
    ap_return_316 = RCTTowersPHI_flags_V_113_reg_8381.read();
}

void processInputLinks::thread_ap_return_317() {
    ap_return_317 = RCTTowersPHI_flags_V_114_reg_8396.read();
}

void processInputLinks::thread_ap_return_318() {
    ap_return_318 = RCTTowersPHI_flags_V_115_reg_8411.read();
}

void processInputLinks::thread_ap_return_319() {
    ap_return_319 = RCTTowersPHI_flags_V_116_reg_8726.read();
}

void processInputLinks::thread_ap_return_32() {
    ap_return_32 = RCTECALClusters_5_p_reg_6786_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_320() {
    ap_return_320 = RCTTowersPHI_flags_V_117_reg_8741.read();
}

void processInputLinks::thread_ap_return_321() {
    ap_return_321 = RCTTowersPHI_flags_V_118_reg_8756.read();
}

void processInputLinks::thread_ap_return_322() {
    ap_return_322 = RCTTowersPHI_flags_V_143_reg_8846.read();
}

void processInputLinks::thread_ap_return_323() {
    ap_return_323 = RCTTowersPHI_flags_V_144_reg_8872.read();
}

void processInputLinks::thread_ap_return_324() {
    ap_return_324 = RCTTowersPHI_flags_V_145_reg_9198.read();
}

void processInputLinks::thread_ap_return_325() {
    ap_return_325 = RCTTowersPHI_flags_V_146_reg_9243.read();
}

void processInputLinks::thread_ap_return_326() {
    ap_return_326 = RCTTowersPHI_flags_V_147_reg_9258.read();
}

void processInputLinks::thread_ap_return_327() {
    ap_return_327 = RCTTowersPHI_flags_V_148_reg_9273.read();
}

void processInputLinks::thread_ap_return_328() {
    ap_return_328 = RCTTowersPHI_flags_V_149_reg_9288.read();
}

void processInputLinks::thread_ap_return_329() {
    ap_return_329 = RCTTowersPHI_flags_V_150_reg_9438.read();
}

void processInputLinks::thread_ap_return_33() {
    ap_return_33 = RCTECALClusters_6_p_reg_7096_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_330() {
    ap_return_330 = RCTTowersPHI_flags_V_119_reg_8426.read();
}

void processInputLinks::thread_ap_return_331() {
    ap_return_331 = RCTTowersPHI_flags_V_120_reg_8441.read();
}

void processInputLinks::thread_ap_return_332() {
    ap_return_332 = RCTTowersPHI_flags_V_121_reg_8456.read();
}

void processInputLinks::thread_ap_return_333() {
    ap_return_333 = RCTTowersPHI_flags_V_122_reg_8471.read();
}

void processInputLinks::thread_ap_return_334() {
    ap_return_334 = RCTTowersPHI_flags_V_123_reg_8486.read();
}

void processInputLinks::thread_ap_return_335() {
    ap_return_335 = RCTTowersPHI_flags_V_124_reg_8771.read();
}

void processInputLinks::thread_ap_return_336() {
    ap_return_336 = RCTTowersPHI_flags_V_125_reg_8786.read();
}

void processInputLinks::thread_ap_return_337() {
    ap_return_337 = RCTTowersPHI_flags_V_126_reg_8801.read();
}

void processInputLinks::thread_ap_return_338() {
    ap_return_338 = RCTTowersPHI_flags_V_151_reg_8887.read();
}

void processInputLinks::thread_ap_return_339() {
    ap_return_339 = RCTTowersPHI_flags_V_152_reg_8902.read();
}

void processInputLinks::thread_ap_return_34() {
    ap_return_34 = RCTECALClusters_7_p_reg_7206_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_340() {
    ap_return_340 = RCTTowersPHI_flags_V_153_reg_9303.read();
}

void processInputLinks::thread_ap_return_341() {
    ap_return_341 = RCTTowersPHI_flags_V_154_reg_9318.read();
}

void processInputLinks::thread_ap_return_342() {
    ap_return_342 = RCTTowersPHI_flags_V_155_reg_9333.read();
}

void processInputLinks::thread_ap_return_343() {
    ap_return_343 = RCTTowersPHI_flags_V_156_reg_9348.read();
}

void processInputLinks::thread_ap_return_344() {
    ap_return_344 = RCTTowersPHI_flags_V_157_reg_9363.read();
}

void processInputLinks::thread_ap_return_345() {
    ap_return_345 = RCTTowersPHI_flags_V_158_reg_9453.read();
}

void processInputLinks::thread_ap_return_346() {
    ap_return_346 = RCTTowersPHI_flags_V_159_reg_8501.read();
}

void processInputLinks::thread_ap_return_347() {
    ap_return_347 = RCTTowersPHI_flags_V_160_reg_8516.read();
}

void processInputLinks::thread_ap_return_348() {
    ap_return_348 = RCTTowersPHI_flags_V_161_reg_8621.read();
}

void processInputLinks::thread_ap_return_349() {
    ap_return_349 = RCTTowersPHI_flags_V_162_reg_8636.read();
}

void processInputLinks::thread_ap_return_35() {
    ap_return_35 = RCTECALClusters_8_p_reg_7256_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_350() {
    ap_return_350 = RCTTowersPHI_flags_V_163_reg_8651.read();
}

void processInputLinks::thread_ap_return_351() {
    ap_return_351 = RCTTowersPHI_flags_V_164_reg_8917.read();
}

void processInputLinks::thread_ap_return_352() {
    ap_return_352 = RCTTowersPHI_flags_V_165_reg_8932.read();
}

void processInputLinks::thread_ap_return_353() {
    ap_return_353 = RCTTowersPHI_flags_V_166_reg_8947.read();
}

void processInputLinks::thread_ap_return_354() {
    ap_return_354 = RCTTowersPHI_flags_V_175_reg_9393.read();
}

void processInputLinks::thread_ap_return_355() {
    ap_return_355 = RCTTowersPHI_flags_V_176_reg_9468.read();
}

void processInputLinks::thread_ap_return_356() {
    ap_return_356 = RCTTowersPHI_flags_V_177_reg_9483.read();
}

void processInputLinks::thread_ap_return_357() {
    ap_return_357 = RCTTowersPHI_flags_V_178_reg_9498.read();
}

void processInputLinks::thread_ap_return_358() {
    ap_return_358 = RCTTowersPHI_flags_V_179_reg_9513.read();
}

void processInputLinks::thread_ap_return_359() {
    ap_return_359 = RCTTowersPHI_flags_V_180_reg_9528.read();
}

void processInputLinks::thread_ap_return_36() {
    ap_return_36 = RCTECALClusters_0_e_6_reg_5466_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_360() {
    ap_return_360 = RCTTowersPHI_flags_V_181_reg_9543.read();
}

void processInputLinks::thread_ap_return_361() {
    ap_return_361 = RCTTowersPHI_flags_V_182_reg_9558.read();
}

void processInputLinks::thread_ap_return_362() {
    ap_return_362 = RCTTowersPHI_flags_V_167_reg_8666.read();
}

void processInputLinks::thread_ap_return_363() {
    ap_return_363 = RCTTowersPHI_flags_V_168_reg_8681.read();
}

void processInputLinks::thread_ap_return_364() {
    ap_return_364 = RCTTowersPHI_flags_V_169_reg_8962.read();
}

void processInputLinks::thread_ap_return_365() {
    ap_return_365 = RCTTowersPHI_flags_V_170_reg_8977.read();
}

void processInputLinks::thread_ap_return_366() {
    ap_return_366 = RCTTowersPHI_flags_V_171_reg_8992.read();
}

void processInputLinks::thread_ap_return_367() {
    ap_return_367 = RCTTowersPHI_flags_V_172_reg_9007.read();
}

void processInputLinks::thread_ap_return_368() {
    ap_return_368 = RCTTowersPHI_flags_V_173_reg_9022.read();
}

void processInputLinks::thread_ap_return_369() {
    ap_return_369 = RCTTowersPHI_flags_V_174_reg_9378.read();
}

void processInputLinks::thread_ap_return_37() {
    ap_return_37 = RCTECALClusters_1_e_6_reg_5791_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_370() {
    ap_return_370 = grp_uploadHCAL_fu_230_ap_return_2.read();
}

void processInputLinks::thread_ap_return_371() {
    ap_return_371 = grp_uploadHCAL_fu_239_ap_return_2.read();
}

void processInputLinks::thread_ap_return_372() {
    ap_return_372 = grp_uploadHCAL_fu_248_ap_return_2.read();
}

void processInputLinks::thread_ap_return_373() {
    ap_return_373 = grp_uploadHCAL_fu_257_ap_return_2.read();
}

void processInputLinks::thread_ap_return_374() {
    ap_return_374 = grp_uploadHCAL_fu_266_ap_return_2.read();
}

void processInputLinks::thread_ap_return_375() {
    ap_return_375 = grp_uploadHCAL_fu_275_ap_return_2.read();
}

void processInputLinks::thread_ap_return_376() {
    ap_return_376 = grp_uploadHCAL_fu_284_ap_return_2.read();
}

void processInputLinks::thread_ap_return_377() {
    ap_return_377 = grp_uploadHCAL_fu_293_ap_return_2.read();
}

void processInputLinks::thread_ap_return_378() {
    ap_return_378 = RCTTowersPHI_0_16_3_reg_9208.read();
}

void processInputLinks::thread_ap_return_379() {
    ap_return_379 = RCTTowersPHI_1_16_3_reg_9218.read();
}

void processInputLinks::thread_ap_return_38() {
    ap_return_38 = RCTECALClusters_2_e_6_reg_5991_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_380() {
    ap_return_380 = RCTTowersPHI_2_16_3_reg_9228.read();
}

void processInputLinks::thread_ap_return_381() {
    ap_return_381 = reg_1142.read();
}

void processInputLinks::thread_ap_return_382() {
    ap_return_382 = reg_1156.read();
}

void processInputLinks::thread_ap_return_383() {
    ap_return_383 = reg_1170.read();
}

void processInputLinks::thread_ap_return_384() {
    ap_return_384 = RCTTowersPHI_0_16_s_reg_9203.read();
}

void processInputLinks::thread_ap_return_385() {
    ap_return_385 = RCTTowersPHI_1_16_s_reg_9213.read();
}

void processInputLinks::thread_ap_return_386() {
    ap_return_386 = RCTTowersPHI_2_16_s_reg_9223.read();
}

void processInputLinks::thread_ap_return_387() {
    ap_return_387 = reg_1134.read();
}

void processInputLinks::thread_ap_return_388() {
    ap_return_388 = reg_1148.read();
}

void processInputLinks::thread_ap_return_389() {
    ap_return_389 = reg_1162.read();
}

void processInputLinks::thread_ap_return_39() {
    ap_return_39 = RCTECALClusters_3_e_6_reg_6286_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_4() {
    ap_return_4 = RCTECALClusters_4_s_reg_6466_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_40() {
    ap_return_40 = RCTECALClusters_4_e_6_reg_6486_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_41() {
    ap_return_41 = RCTECALClusters_5_e_6_reg_6791_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_42() {
    ap_return_42 = RCTECALClusters_6_e_6_reg_7101_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_43() {
    ap_return_43 = RCTECALClusters_7_e_6_reg_7211_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_44() {
    ap_return_44 = RCTECALClusters_8_e_6_reg_7261_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_45() {
    ap_return_45 = RCTECALClusters_0_w_reg_5471_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_46() {
    ap_return_46 = RCTECALClusters_1_w_reg_5796_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_47() {
    ap_return_47 = RCTECALClusters_2_w_reg_5996_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_48() {
    ap_return_48 = RCTECALClusters_3_w_reg_6291_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_49() {
    ap_return_49 = RCTECALClusters_4_w_reg_6491_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_5() {
    ap_return_5 = RCTECALClusters_5_s_reg_6771_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_50() {
    ap_return_50 = RCTECALClusters_5_w_reg_6796_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_51() {
    ap_return_51 = RCTECALClusters_6_w_reg_7106_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_52() {
    ap_return_52 = RCTECALClusters_7_w_reg_7216_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_53() {
    ap_return_53 = RCTECALClusters_8_w_reg_7266_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_54() {
    ap_return_54 = RCTECALClusters_0_t_reg_5476_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_55() {
    ap_return_55 = RCTECALClusters_1_t_reg_5801_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_56() {
    ap_return_56 = RCTECALClusters_2_t_reg_6001_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_57() {
    ap_return_57 = RCTECALClusters_3_t_reg_6296_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_58() {
    ap_return_58 = RCTECALClusters_4_t_reg_6496_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_59() {
    ap_return_59 = RCTECALClusters_5_t_reg_6801_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_6() {
    ap_return_6 = RCTECALClusters_6_s_reg_7081_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_60() {
    ap_return_60 = RCTECALClusters_6_t_reg_7111_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_61() {
    ap_return_61 = RCTECALClusters_7_t_reg_7221_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_62() {
    ap_return_62 = RCTECALClusters_8_t_reg_7271_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_63() {
    ap_return_63 = RCTECALClusters_0_s_5_reg_5481_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_64() {
    ap_return_64 = RCTECALClusters_1_s_5_reg_5806_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_65() {
    ap_return_65 = RCTECALClusters_2_s_5_reg_6006_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_66() {
    ap_return_66 = RCTECALClusters_3_s_5_reg_6301_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_67() {
    ap_return_67 = RCTECALClusters_4_s_5_reg_6501_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_68() {
    ap_return_68 = RCTECALClusters_5_s_5_reg_6806_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_69() {
    ap_return_69 = RCTECALClusters_6_s_5_reg_7116_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_7() {
    ap_return_7 = RCTECALClusters_7_s_reg_7191_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_70() {
    ap_return_70 = RCTECALClusters_7_s_5_reg_7226_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_71() {
    ap_return_71 = RCTECALClusters_8_s_5_reg_7276_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_72() {
    ap_return_72 = RCTECALClusters_0_s_6_reg_5486_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_73() {
    ap_return_73 = RCTECALClusters_1_s_6_reg_5811_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_74() {
    ap_return_74 = RCTECALClusters_2_s_6_reg_6011_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_75() {
    ap_return_75 = RCTECALClusters_3_s_6_reg_6306_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_76() {
    ap_return_76 = RCTECALClusters_4_s_6_reg_6506_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_77() {
    ap_return_77 = RCTECALClusters_5_s_6_reg_6811_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_78() {
    ap_return_78 = RCTECALClusters_6_s_6_reg_7121_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_79() {
    ap_return_79 = RCTECALClusters_7_s_6_reg_7231_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_8() {
    ap_return_8 = RCTECALClusters_8_s_reg_7241_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_80() {
    ap_return_80 = RCTECALClusters_8_s_6_reg_7281_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_81() {
    ap_return_81 = RCTECALClusters_0_b_reg_5491_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_82() {
    ap_return_82 = RCTECALClusters_1_b_reg_5816_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_83() {
    ap_return_83 = RCTECALClusters_2_b_reg_6016_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_84() {
    ap_return_84 = RCTECALClusters_3_b_reg_6311_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_85() {
    ap_return_85 = RCTECALClusters_4_b_reg_6511_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_86() {
    ap_return_86 = RCTECALClusters_5_b_reg_6816_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_87() {
    ap_return_87 = RCTECALClusters_6_b_reg_7126_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_88() {
    ap_return_88 = RCTECALClusters_7_b_reg_7236_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_89() {
    ap_return_89 = RCTECALClusters_8_b_reg_7286_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_9() {
    ap_return_9 = RCTECALClusters_0_e_reg_5451_pp0_iter1_reg.read();
}

void processInputLinks::thread_ap_return_90() {
    ap_return_90 = RCTTowersPHI_energy_95_reg_8196.read();
}

void processInputLinks::thread_ap_return_91() {
    ap_return_91 = RCTTowersPHI_energy_96_reg_8211.read();
}

void processInputLinks::thread_ap_return_92() {
    ap_return_92 = RCTTowersPHI_energy_97_reg_8226.read();
}

void processInputLinks::thread_ap_return_93() {
    ap_return_93 = RCTTowersPHI_energy_98_reg_8241.read();
}

void processInputLinks::thread_ap_return_94() {
    ap_return_94 = RCTTowersPHI_energy_99_reg_8256.read();
}

void processInputLinks::thread_ap_return_95() {
    ap_return_95 = RCTTowersPHI_energy_100_reg_8526.read();
}

void processInputLinks::thread_ap_return_96() {
    ap_return_96 = RCTTowersPHI_energy_101_reg_8541.read();
}

void processInputLinks::thread_ap_return_97() {
    ap_return_97 = RCTTowersPHI_energy_102_reg_8556.read();
}

void processInputLinks::thread_ap_return_98() {
    ap_return_98 = RCTTowersPHI_energy_127_reg_8586.read();
}

void processInputLinks::thread_ap_return_99() {
    ap_return_99 = RCTTowersPHI_energy_128_reg_8601.read();
}

void processInputLinks::thread_grp_fillhcaltower_fu_406_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_19_17_reg_7011.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_18_18_reg_6701.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_18_2_reg_6576.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_18_20_reg_6716.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_17_27_reg_6246.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_17_12_reg_6171.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_16_29_reg_5761.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = p_Result_16_14_reg_5686.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_406_i_V = trunc_ln647_1_fu_1306_p1.read();
        } else {
            grp_fillhcaltower_fu_406_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_406_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_411_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_19_18_reg_7016.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_18_21_reg_6721.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_18_3_reg_6581.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_18_23_reg_6731.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_17_28_reg_6251.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_17_13_reg_6176.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_16_30_reg_5766.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = p_Result_16_15_reg_5691.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_411_i_V = link_in_5_V_read.read().range(31, 16);
        } else {
            grp_fillhcaltower_fu_411_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_411_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_416_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_19_21_reg_7031.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_18_22_reg_6726.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_18_6_reg_6606.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_18_24_reg_6736.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_17_29_reg_6256.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_17_14_reg_6181.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = trunc_ln647_2_fu_1635_p1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = p_Result_16_16_reg_5696.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_416_i_V = link_in_5_V_read.read().range(47, 32);
        } else {
            grp_fillhcaltower_fu_416_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_416_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_421_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_19_22_reg_7036.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_18_25_reg_6741.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_18_7_reg_6611.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_18_27_reg_6751.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_17_30_reg_6261.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_17_15_reg_6186.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = ap_port_reg_link_in_6_V_read.read().range(31, 16);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = p_Result_16_17_reg_5701.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_421_i_V = link_in_5_V_read.read().range(63, 48);
        } else {
            grp_fillhcaltower_fu_421_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_421_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_426_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_19_25_reg_7051.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_18_26_reg_6746.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_18_s_reg_6636.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_18_28_reg_6756.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = trunc_ln647_3_fu_1962_p1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_17_16_reg_6191.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = ap_port_reg_link_in_6_V_read.read().range(47, 32);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = p_Result_16_18_reg_5706.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_426_i_V = link_in_5_V_read.read().range(79, 64);
        } else {
            grp_fillhcaltower_fu_426_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_426_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_431_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = p_Result_19_26_reg_7056.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = p_Result_18_29_reg_6761.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = p_Result_18_10_reg_6641.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = trunc_ln647_4_fu_2287_p1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = ap_port_reg_link_in_7_V_read.read().range(31, 16);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = p_Result_17_17_reg_6196.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = ap_port_reg_link_in_6_V_read.read().range(63, 48);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = p_Result_16_19_reg_5711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_431_i_V = link_in_5_V_read.read().range(95, 80);
        } else {
            grp_fillhcaltower_fu_431_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_431_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_436_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = p_Result_19_29_reg_7071.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = p_Result_18_30_reg_6766.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = p_Result_18_13_reg_6666.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = ap_port_reg_link_in_8_V_read.read().range(31, 16);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = ap_port_reg_link_in_7_V_read.read().range(79, 64);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = p_Result_17_18_reg_6201.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = ap_port_reg_link_in_6_V_read.read().range(79, 64);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = p_Result_16_20_reg_5716.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_436_i_V = link_in_5_V_read.read().range(111, 96);
        } else {
            grp_fillhcaltower_fu_436_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_436_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_441_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = p_Result_19_30_reg_7076.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = p_Result_19_2_reg_6891.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = p_Result_18_14_reg_6671.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = ap_port_reg_link_in_8_V_read.read().range(79, 64);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = ap_port_reg_link_in_7_V_read.read().range(95, 80);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = p_Result_17_19_reg_6206.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = ap_port_reg_link_in_6_V_read.read().range(95, 80);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = p_Result_16_21_reg_5721.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_441_i_V = link_in_5_V_read.read().range(127, 112);
        } else {
            grp_fillhcaltower_fu_441_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_441_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_446_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = p_Result_19_3_reg_6896.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = p_Result_18_17_reg_6696.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = ap_port_reg_link_in_8_V_read.read().range(95, 80);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = ap_port_reg_link_in_7_V_read.read().range(143, 128);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = p_Result_17_20_reg_6211.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = ap_port_reg_link_in_6_V_read.read().range(111, 96);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = p_Result_16_22_reg_5726.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_446_i_V = link_in_5_V_read.read().range(143, 128);
        } else {
            grp_fillhcaltower_fu_446_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_446_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_451_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = p_Result_19_6_reg_6921.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = p_Result_19_19_reg_7021.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = ap_port_reg_link_in_8_V_read.read().range(143, 128);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = ap_port_reg_link_in_7_V_read.read().range(159, 144);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = p_Result_17_21_reg_6216.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = ap_port_reg_link_in_6_V_read.read().range(127, 112);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = p_Result_16_23_reg_5731.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_451_i_V = link_in_5_V_read.read().range(159, 144);
        } else {
            grp_fillhcaltower_fu_451_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_451_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_456_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = p_Result_19_7_reg_6926.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = p_Result_19_20_reg_7026.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = ap_port_reg_link_in_8_V_read.read().range(159, 144);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = ap_port_reg_link_in_7_V_read.read().range(207, 192);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = p_Result_17_22_reg_6221.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = ap_port_reg_link_in_6_V_read.read().range(143, 128);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = p_Result_16_24_reg_5736.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_456_i_V = link_in_5_V_read.read().range(175, 160);
        } else {
            grp_fillhcaltower_fu_456_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_456_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_461_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = p_Result_19_s_reg_6951.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = p_Result_19_23_reg_7041.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = ap_port_reg_link_in_8_V_read.read().range(207, 192);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = ap_port_reg_link_in_7_V_read.read().range(223, 208);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = p_Result_17_23_reg_6226.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = ap_port_reg_link_in_6_V_read.read().range(159, 144);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = p_Result_16_25_reg_5741.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_461_i_V = link_in_5_V_read.read().range(191, 176);
        } else {
            grp_fillhcaltower_fu_461_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_461_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_466_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = p_Result_19_10_reg_6956.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = p_Result_19_24_reg_7046.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = ap_port_reg_link_in_8_V_read.read().range(223, 208);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = ap_port_reg_link_in_7_V_read.read().range(271, 256);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = p_Result_17_24_reg_6231.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = ap_port_reg_link_in_6_V_read.read().range(175, 160);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = p_Result_16_26_reg_5746.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_466_i_V = link_in_5_V_read.read().range(207, 192);
        } else {
            grp_fillhcaltower_fu_466_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_466_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_471_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = p_Result_19_13_reg_6981.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = p_Result_19_27_reg_7061.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = ap_port_reg_link_in_8_V_read.read().range(271, 256);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = ap_port_reg_link_in_7_V_read.read().range(287, 272);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = p_Result_17_25_reg_6236.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = ap_port_reg_link_in_6_V_read.read().range(191, 176);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = p_Result_16_27_reg_5751.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_471_i_V = link_in_5_V_read.read().range(223, 208);
        } else {
            grp_fillhcaltower_fu_471_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_471_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillhcaltower_fu_476_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = p_Result_19_14_reg_6986.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = p_Result_19_28_reg_7066.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = ap_port_reg_link_in_8_V_read.read().range(287, 272);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = ap_port_reg_link_in_7_V_read.read().range(335, 320);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = p_Result_17_26_reg_6241.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = ap_port_reg_link_in_6_V_read.read().range(207, 192);
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = p_Result_16_28_reg_5756.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillhcaltower_fu_476_i_V = link_in_5_V_read.read().range(239, 224);
        } else {
            grp_fillhcaltower_fu_476_i_V = "XXXXXXXXXXXXXXXX";
        }
    } else {
        grp_fillhcaltower_fu_476_i_V = "XXXXXXXXXXXXXXXX";
    }
}

void processInputLinks::thread_grp_fillrctecalcluster_fu_401_i_V() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_8_reg_5531.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_7_reg_5526.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_6_reg_5521.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_5_reg_5516.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_4_reg_5511.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_3_reg_5506.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_2_reg_5501.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = p_Result_1_reg_5496.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_fillrctecalcluster_fu_401_i_V = trunc_ln647_fu_1221_p1.read();
        } else {
            grp_fillrctecalcluster_fu_401_i_V =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        grp_fillrctecalcluster_fu_401_i_V =  (sc_lv<64>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_getECAL_fu_218_ap_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        grp_getECAL_fu_218_ap_start = ap_const_logic_1;
    } else {
        grp_getECAL_fu_218_ap_start = grp_getECAL_fu_218_ap_start_reg.read();
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_329_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR0_6_en_reg_8101.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR1_28_e_reg_7911.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR1_14_e_reg_7841.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR1_0_en_reg_7771.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR2_21_e_reg_7576.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR2_7_en_reg_7506.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR3_28_e_reg_7371.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = ECALTowersSLR3_14_e_reg_7321.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_0.read();
    } else {
        grp_uploadECAL_fu_329_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_329_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR0_6_ti_reg_8161.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR1_28_t_reg_8061.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR1_14_t_reg_7991.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR1_0_ti_reg_7921.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR2_21_t_reg_7726.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR2_7_ti_reg_7656.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR3_28_t_reg_7461.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = ECALTowersSLR3_14_t_reg_7411.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_30.read();
    } else {
        grp_uploadECAL_fu_329_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_335_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR0_7_en_reg_8106.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR1_5_en_reg_7796.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR1_20_e_reg_7871.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR1_6_en_reg_7801.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR2_27_e_reg_7606.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR2_13_e_reg_7536.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR3_5_en_reg_7301.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = ECALTowersSLR3_20_e_reg_7341.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_6.read();
    } else {
        grp_uploadECAL_fu_335_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_335_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR0_7_ti_reg_8166.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR1_5_ti_reg_7946.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR1_20_t_reg_8021.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR1_6_ti_reg_7951.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR2_27_t_reg_7756.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR2_13_t_reg_7686.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR3_5_ti_reg_7391.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = ECALTowersSLR3_20_t_reg_7431.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_36.read();
    } else {
        grp_uploadECAL_fu_335_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_341_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR0_8_en_reg_8111.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR1_11_e_reg_7826.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR1_26_e_reg_7901.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR1_12_e_reg_7831.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR2_4_en_reg_7491.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR2_19_e_reg_7566.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR3_11_e_reg_7316.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = ECALTowersSLR3_26_e_reg_7361.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_12.read();
    } else {
        grp_uploadECAL_fu_341_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_341_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR0_8_ti_reg_8171.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR1_11_t_reg_7976.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR1_26_t_reg_8051.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR1_12_t_reg_7981.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR2_4_ti_reg_7641.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR2_19_t_reg_7716.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR3_11_t_reg_7406.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = ECALTowersSLR3_26_t_reg_7451.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_42.read();
    } else {
        grp_uploadECAL_fu_341_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_347_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR0_9_en_reg_8116.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR1_17_e_reg_7856.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR1_3_en_reg_7786.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR1_18_e_reg_7861.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR2_10_e_reg_7521.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR2_25_e_reg_7596.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR3_17_e_reg_7336.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = ECALTowersSLR3_3_en_reg_7291.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_18.read();
    } else {
        grp_uploadECAL_fu_347_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_347_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR0_9_ti_reg_8176.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR1_17_t_reg_8006.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR1_3_ti_reg_7936.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR1_18_t_reg_8011.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR2_10_t_reg_7671.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR2_25_t_reg_7746.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR3_17_t_reg_7426.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = ECALTowersSLR3_3_ti_reg_7381.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_48.read();
    } else {
        grp_uploadECAL_fu_347_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_353_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR0_10_e_reg_8121.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR1_23_e_reg_7886.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR1_9_en_reg_7816.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR1_24_e_reg_7891.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR2_16_e_reg_7551.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR2_2_en_reg_7481.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR3_23_e_reg_7356.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = ECALTowersSLR3_9_en_reg_7306.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_24.read();
    } else {
        grp_uploadECAL_fu_353_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_353_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR0_10_t_reg_8181.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR1_23_t_reg_8036.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR1_9_ti_reg_7966.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR1_24_t_reg_8041.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR2_16_t_reg_7701.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR2_2_ti_reg_7631.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR3_23_t_reg_7446.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = ECALTowersSLR3_9_ti_reg_7396.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_54.read();
    } else {
        grp_uploadECAL_fu_353_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_359_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR0_11_e_reg_8126.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR1_29_e_reg_7916.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR1_15_e_reg_7846.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR1_1_en_reg_7776.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR2_22_e_reg_7581.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR2_8_en_reg_7511.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR3_29_e_reg_7376.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = ECALTowersSLR3_15_e_reg_7326.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_1.read();
    } else {
        grp_uploadECAL_fu_359_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_359_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR0_11_t_reg_8186.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR1_29_t_reg_8066.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR1_15_t_reg_7996.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR1_1_ti_reg_7926.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR2_22_t_reg_7731.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR2_8_ti_reg_7661.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR3_29_t_reg_7466.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = ECALTowersSLR3_15_t_reg_7416.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_31.read();
    } else {
        grp_uploadECAL_fu_359_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_365_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR0_0_en_reg_8071.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR1_21_e_reg_7876.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR1_7_en_reg_7806.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR2_28_e_reg_7611.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR2_14_e_reg_7541.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR2_0_en_reg_7471.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = ECALTowersSLR3_21_e_reg_7346.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_7.read();
    } else {
        grp_uploadECAL_fu_365_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_365_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR0_0_ti_reg_8131.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR1_21_t_reg_8026.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR1_7_ti_reg_7956.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR2_28_t_reg_7761.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR2_14_t_reg_7691.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR2_0_ti_reg_7621.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = ECALTowersSLR3_21_t_reg_7436.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_37.read();
    } else {
        grp_uploadECAL_fu_365_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_371_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR0_1_en_reg_8076.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR1_27_e_reg_7906.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR1_13_e_reg_7836.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR2_5_en_reg_7496.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR2_20_e_reg_7571.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR2_6_en_reg_7501.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = ECALTowersSLR3_27_e_reg_7366.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_13.read();
    } else {
        grp_uploadECAL_fu_371_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_371_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR0_1_ti_reg_8136.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR1_27_t_reg_8056.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR1_13_t_reg_7986.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR2_5_ti_reg_7646.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR2_20_t_reg_7721.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR2_6_ti_reg_7651.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = ECALTowersSLR3_27_t_reg_7456.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_43.read();
    } else {
        grp_uploadECAL_fu_371_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_377_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR0_2_en_reg_8081.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR1_4_en_reg_7791.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR1_19_e_reg_7866.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR2_11_e_reg_7526.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR2_26_e_reg_7601.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR2_12_e_reg_7531.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = ECALTowersSLR3_4_en_reg_7296.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_19.read();
    } else {
        grp_uploadECAL_fu_377_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_377_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR0_2_ti_reg_8141.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR1_4_ti_reg_7941.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR1_19_t_reg_8016.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR2_11_t_reg_7676.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR2_26_t_reg_7751.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR2_12_t_reg_7681.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = ECALTowersSLR3_4_ti_reg_7386.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_49.read();
    } else {
        grp_uploadECAL_fu_377_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_383_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR0_3_en_reg_8086.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR1_10_e_reg_7821.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR1_25_e_reg_7896.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR2_17_e_reg_7556.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR2_3_en_reg_7486.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR2_18_e_reg_7561.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = ECALTowersSLR3_10_e_reg_7311.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_25.read();
    } else {
        grp_uploadECAL_fu_383_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_383_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR0_3_ti_reg_8146.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR1_10_t_reg_7971.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR1_25_t_reg_8046.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR2_17_t_reg_7706.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR2_3_ti_reg_7636.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR2_18_t_reg_7711.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = ECALTowersSLR3_10_t_reg_7401.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_55.read();
    } else {
        grp_uploadECAL_fu_383_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_389_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR0_4_en_reg_8091.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR1_16_e_reg_7851.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR1_2_en_reg_7781.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR2_23_e_reg_7586.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR2_9_en_reg_7516.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR2_24_e_reg_7591.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = ECALTowersSLR3_16_e_reg_7331.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_2.read();
    } else {
        grp_uploadECAL_fu_389_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_389_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR0_4_ti_reg_8151.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR1_16_t_reg_8001.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR1_2_ti_reg_7931.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR2_23_t_reg_7736.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR2_9_ti_reg_7666.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR2_24_t_reg_7741.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = ECALTowersSLR3_16_t_reg_7421.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_32.read();
    } else {
        grp_uploadECAL_fu_389_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_395_ecaltower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR0_5_en_reg_8096.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR1_22_e_reg_7881.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR1_8_en_reg_7811.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR2_29_e_reg_7616.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR2_15_e_reg_7546.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR2_1_en_reg_7476.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = ECALTowersSLR3_22_e_reg_7351.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read = grp_getECAL_fu_218_ap_return_8.read();
    } else {
        grp_uploadECAL_fu_395_ecaltower_energy_V_read =  (sc_lv<12>) ("XXXXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadECAL_fu_395_ecaltower_timing_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR0_5_ti_reg_8156.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR1_22_t_reg_8031.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR1_8_ti_reg_7961.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR2_29_t_reg_7766.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR2_15_t_reg_7696.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR2_1_ti_reg_7626.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = ECALTowersSLR3_22_t_reg_7441.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read = grp_getECAL_fu_218_ap_return_38.read();
    } else {
        grp_uploadECAL_fu_395_ecaltower_timing_V_read =  (sc_lv<5>) ("XXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp870.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp917.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1012.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1099.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1190.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1291.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1372.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1447.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1500.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_230_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_230_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR3_energy_1_reg_6881_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR1_energy_27_reg_6516_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR1_energy_13_reg_6326_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR1_energy_8_reg_6121_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR1_energy_6_reg_6101_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR0_energy_24_reg_5921_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR0_energy_19_reg_5871_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR0_energy_6_reg_5596_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read = HCALTowersR0_energy_s_reg_5536.read();
        } else {
            grp_uploadHCAL_fu_230_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_230_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR3_fb_V_1_reg_6886_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR1_fb_V_27_reg_6521_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR1_fb_V_13_reg_6331_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR1_fb_V_8_reg_6126_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR1_fb_V_6_reg_6106_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR0_fb_V_24_reg_5926_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR0_fb_V_19_reg_5876_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR0_fb_V_6_reg_5601_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read = HCALTowersR0_fb_V_reg_5541.read();
        } else {
            grp_uploadHCAL_fu_230_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_230_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_1076.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_1200.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_1111.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_1034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_989.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_1095.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read = reg_881.read();
    } else {
        grp_uploadHCAL_fu_230_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_1066.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_1103.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_1020.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_977.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read = reg_869.read();
    } else {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_230_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_1066.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_1103.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_1020.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_977.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 = reg_869.read();
    } else {
        grp_uploadHCAL_fu_230_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp871.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp921.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1016.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1103.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1194.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1296.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1376.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1451.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1504.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_239_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR3_energy_3_reg_6911_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR1_energy_28_reg_6526_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR1_energy_17_reg_6366_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR1_energy_11_reg_6161_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR1_energy_3_reg_6071_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR0_energy_28_reg_5961_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR0_energy_23_reg_5911_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR0_energy_31_reg_5636_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read = HCALTowersR0_energy_4_reg_5576.read();
        } else {
            grp_uploadHCAL_fu_239_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_239_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR3_fb_V_5_reg_6916_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR1_fb_V_28_reg_6531_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR1_fb_V_17_reg_6371_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR1_fb_V_11_reg_6166_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR1_fb_V_3_reg_6076_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR0_fb_V_28_reg_5966_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR0_fb_V_23_reg_5916_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR0_fb_V_s_reg_5641_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read = HCALTowersR0_fb_V_4_reg_5581.read();
        } else {
            grp_uploadHCAL_fu_239_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_239_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_239_rcttower_energy_V_read = reg_1095.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_energy_V_read = reg_1011.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_energy_V_read = reg_881.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_energy_V_read = reg_899.read();
    } else {
        grp_uploadHCAL_fu_239_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read = reg_997.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read = reg_869.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read = reg_889.read();
    } else {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_239_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read_2 = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read_2 = reg_997.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read_2 = reg_869.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read_2 = reg_889.read();
    } else {
        grp_uploadHCAL_fu_239_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp872.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp925.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1020.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1107.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1198.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1300.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1380.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1455.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1508.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_248_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR3_energy_5_reg_6941_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR1_energy_29_reg_6536_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR1_energy_21_reg_6406_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR1_energy_15_reg_6346_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR1_energy_7_reg_6111_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR0_energy_21_reg_5891_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR0_energy_27_reg_5951_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR0_energy_13_reg_5676_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read = HCALTowersR0_energy_8_reg_5616.read();
        } else {
            grp_uploadHCAL_fu_248_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_248_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR3_fb_V_9_reg_6946_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR1_fb_V_29_reg_6541_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR1_fb_V_21_reg_6411_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR1_fb_V_15_reg_6351_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR1_fb_V_7_reg_6116_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR0_fb_V_21_reg_5896_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR0_fb_V_27_reg_5956_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR0_fb_V_13_reg_5681_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read = HCALTowersR0_fb_V_8_reg_5621.read();
        } else {
            grp_uploadHCAL_fu_248_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_248_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read = reg_1184.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read = reg_1156.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read = reg_1034.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read = reg_899.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read = reg_918.read();
    } else {
        grp_uploadHCAL_fu_248_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read = reg_1176.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read = reg_1148.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read = reg_1020.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read = reg_889.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read = reg_906.read();
    } else {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_248_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 = reg_1176.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 = reg_1148.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 = reg_1020.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 = reg_889.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 = reg_906.read();
    } else {
        grp_uploadHCAL_fu_248_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp873.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp929.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1024.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1111.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1202.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1304.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1384.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1459.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1512.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_257_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR3_energy_7_reg_6971_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR1_energy_30_reg_6546_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR1_energy_25_reg_6446_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR1_energy_19_reg_6386_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR2_energy_15_reg_6706.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR0_energy_25_reg_5931_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR0_energy_20_reg_5881_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR0_energy_17_reg_5851.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read = HCALTowersR0_energy_11_reg_5656.read();
        } else {
            grp_uploadHCAL_fu_257_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_257_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR3_fb_V_2_reg_6976_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR1_fb_V_30_reg_6551_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR1_fb_V_25_reg_6451_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR1_fb_V_19_reg_6391_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR2_fb_V_7_reg_6711.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR0_fb_V_25_reg_5936_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR0_fb_V_20_reg_5886_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR0_fb_V_17_reg_5856.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read = HCALTowersR0_fb_V_11_reg_5661.read();
        } else {
            grp_uploadHCAL_fu_257_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_257_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read = reg_1057.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read = reg_1170.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read = reg_1095.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read = reg_918.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read = reg_936.read();
    } else {
        grp_uploadHCAL_fu_257_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read = reg_1043.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read = reg_1162.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read = reg_906.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read = reg_926.read();
    } else {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_257_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 = reg_1043.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 = reg_1162.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 = reg_906.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 = reg_926.read();
    } else {
        grp_uploadHCAL_fu_257_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp874.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp933.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1028.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1123.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1206.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1308.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1388.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1464.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1516.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_266_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR3_energy_9_reg_7001_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR3_energy_2_reg_6901_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR1_energy_10_reg_6151_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR1_energy_23_reg_6426_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR2_energy_11_reg_6831.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR0_energy_29_reg_6021_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR1_energy_s_reg_6041.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR0_energy_3_reg_5566_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read = HCALTowersR0_energy_15_reg_5831.read();
        } else {
            grp_uploadHCAL_fu_266_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_266_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR3_fb_V_6_reg_7006_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR3_fb_V_4_reg_6906_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR1_fb_V_10_reg_6156_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR1_fb_V_23_reg_6431_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR2_fb_V_11_reg_6836.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR0_fb_V_29_reg_6026_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR1_fb_V_reg_6046.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR0_fb_V_3_reg_5571_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read = HCALTowersR0_fb_V_15_reg_5836.read();
        } else {
            grp_uploadHCAL_fu_266_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_266_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read = reg_1142.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read = reg_989.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read = reg_1057.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read = reg_936.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read = reg_953.read();
    } else {
        grp_uploadHCAL_fu_266_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read = reg_1134.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read = reg_977.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read = reg_1043.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read = reg_926.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read = reg_943.read();
    } else {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_266_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 = reg_1134.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 = reg_977.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 = reg_1043.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 = reg_926.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 = reg_943.read();
    } else {
        grp_uploadHCAL_fu_266_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp875.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp937.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1032.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1127.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1210.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1312.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1392.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1468.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1520.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_275_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR3_energy_10_reg_7141_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR3_energy_4_reg_6931_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR1_energy_14_reg_6336_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR1_energy_9_reg_6131_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR2_energy_13_reg_6851.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR0_energy_22_reg_5901_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR1_energy_4_reg_6081.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR0_energy_7_reg_5606_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read = HCALTowersR0_energy_1_reg_5546.read();
        } else {
            grp_uploadHCAL_fu_275_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_275_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR3_fb_V_10_reg_7146_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR3_fb_V_8_reg_6936_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR1_fb_V_14_reg_6341_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR1_fb_V_9_reg_6136_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR2_fb_V_13_reg_6856.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR0_fb_V_22_reg_5906_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR1_fb_V_4_reg_6086.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR0_fb_V_7_reg_5611_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read = HCALTowersR0_fb_V_1_reg_5551.read();
        } else {
            grp_uploadHCAL_fu_275_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_275_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_1034.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_1156.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_1057.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_1127.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_953.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read = reg_970.read();
    } else {
        grp_uploadHCAL_fu_275_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_1020.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_1148.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_1043.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_1117.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_943.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read = reg_960.read();
    } else {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_275_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_1020.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_1148.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_1043.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_1117.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_943.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 = reg_960.read();
    } else {
        grp_uploadHCAL_fu_275_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp876.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp941.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1036.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1134.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1214.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1316.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1396.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1472.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1524.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_284_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR3_energy_12_reg_7161_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR3_energy_6_reg_6961_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR1_energy_18_reg_6376_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR1_energy_12_reg_6316_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR2_energy_5_reg_6626.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR0_energy_26_reg_5941_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR2_energy_4_reg_6616.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR0_energy_10_reg_5646_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read = HCALTowersR0_energy_5_reg_5586.read();
        } else {
            grp_uploadHCAL_fu_284_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_284_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR3_fb_V_12_reg_7166_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR3_fb_V_s_reg_6966_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR1_fb_V_18_reg_6381_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR1_fb_V_12_reg_6321_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR2_fb_V_9_reg_6631.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR0_fb_V_26_reg_5946_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR2_fb_V_8_reg_6621.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR0_fb_V_10_reg_5651_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read = HCALTowersR0_fb_V_5_reg_5591.read();
        } else {
            grp_uploadHCAL_fu_284_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_284_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_1215.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_1200.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_936.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_1076.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_970.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read = reg_989.read();
    } else {
        grp_uploadHCAL_fu_284_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_1207.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_926.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_1066.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_960.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read = reg_977.read();
    } else {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_284_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_1207.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_926.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_1066.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_960.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 = reg_977.read();
    } else {
        grp_uploadHCAL_fu_284_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp877.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp945.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1040.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1138.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1218.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1320.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1400.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1476.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1528.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_293_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR3_energy_14_reg_7181_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR3_energy_8_reg_6991_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR1_energy_22_reg_6416_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR1_energy_16_reg_6356_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR2_energy_7_reg_6656.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR0_energy_30_reg_6031_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR2_energy_6_reg_6646.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR0_energy_14_reg_5821.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read = HCALTowersR0_energy_9_reg_5626.read();
        } else {
            grp_uploadHCAL_fu_293_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_293_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR3_fb_V_14_reg_7186_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR3_fb_V_3_reg_6996_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR1_fb_V_22_reg_6421_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR1_fb_V_16_reg_6361_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR2_fb_V_2_reg_6661.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR0_fb_V_30_reg_6036_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR2_fb_V_s_reg_6651.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR0_fb_V_14_reg_5826.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read = HCALTowersR0_fb_V_9_reg_5631.read();
        } else {
            grp_uploadHCAL_fu_293_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_293_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_1127.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_1200.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_953.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_1095.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_1111.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_989.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read = reg_1011.read();
    } else {
        grp_uploadHCAL_fu_293_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_1117.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_943.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_1103.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_977.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read = reg_997.read();
    } else {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_293_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_1117.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_1190.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_943.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_1083.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_1103.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_977.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 = reg_997.read();
    } else {
        grp_uploadHCAL_fu_293_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp878.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp949.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1044.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1142.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1222.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1324.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1404.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1480.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1532.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_302_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR3_energy_15_reg_7131_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR1_energy_26_reg_6456_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR1_energy_20_reg_6396_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR2_energy_9_reg_6686.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR1_energy_1_reg_6051_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR2_energy_8_reg_6676.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR0_energy_18_reg_5861.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read = HCALTowersR0_energy_12_reg_5666.read();
        } else {
            grp_uploadHCAL_fu_302_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_302_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR3_fb_V_7_reg_7136_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR1_fb_V_26_reg_6461_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR1_fb_V_20_reg_6401_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR2_fb_V_6_reg_6691.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR1_fb_V_1_reg_6056_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR2_fb_V_3_reg_6681.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR0_fb_V_18_reg_5866.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read = HCALTowersR0_fb_V_12_reg_5671.read();
        } else {
            grp_uploadHCAL_fu_302_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_302_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = RCTTowersPHI_energy_82_reg_8857.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = reg_970.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = reg_918.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = reg_881.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = reg_1011.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read = reg_1034.read();
    } else {
        grp_uploadHCAL_fu_302_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = RCTTowersPHI_flags_V_83_reg_8851.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = reg_960.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = reg_906.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = reg_869.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = reg_997.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read = reg_1020.read();
    } else {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_302_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = RCTTowersPHI_flags_V_83_reg_8851.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = reg_960.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = reg_906.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = reg_869.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0)) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = reg_997.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 = reg_1020.read();
    } else {
        grp_uploadHCAL_fu_302_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp879.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp953.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1050.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1146.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1226.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1328.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1408.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1485.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1536.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_311_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_311_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR3_energy_11_reg_7151_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR2_energy_14_reg_6861_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR1_energy_24_reg_6436_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR2_energy_10_reg_6821.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR1_energy_5_reg_6091_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR2_energy_1_reg_6566.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR2_energy_s_reg_6556.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read = HCALTowersR0_energy_16_reg_5841.read();
        } else {
            grp_uploadHCAL_fu_311_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_311_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR3_fb_V_11_reg_7156_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR2_fb_V_14_reg_6866_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR1_fb_V_24_reg_6441_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR2_fb_V_10_reg_6826.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR1_fb_V_5_reg_6096_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR2_fb_V_1_reg_6571.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR2_fb_V_reg_6561.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read = HCALTowersR0_fb_V_16_reg_5846.read();
        } else {
            grp_uploadHCAL_fu_311_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_311_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_rcttower_energy_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_881.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_1215.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_1011.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_1142.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_899.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_1034.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read = reg_1057.read();
    } else {
        grp_uploadHCAL_fu_311_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_rcttower_flags_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_869.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_1207.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_997.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_1134.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_889.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_1020.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read = reg_1043.read();
    } else {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_311_rcttower_flags_V_read_2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_869.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_1207.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_997.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_1134.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_889.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_1020.read();
    } else if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
                (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                 esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                 esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 = reg_1043.read();
    } else {
        grp_uploadHCAL_fu_311_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_ap_ce() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001_ignoreCallOp880.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001_ignoreCallOp957.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001_ignoreCallOp1054.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001_ignoreCallOp1150.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001_ignoreCallOp1230.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001_ignoreCallOp1332.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001_ignoreCallOp1412.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001_ignoreCallOp1489.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001_ignoreCallOp1540.read(), ap_const_boolean_0)))) {
        grp_uploadHCAL_fu_320_ap_ce = ap_const_logic_1;
    } else {
        grp_uploadHCAL_fu_320_ap_ce = ap_const_logic_0;
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_hcaltower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR3_energy_13_reg_7171_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR3_energy_s_reg_6871_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR1_energy_31_reg_6141_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR2_energy_12_reg_6841.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR1_energy_2_reg_6061_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR2_energy_3_reg_6596.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR2_energy_2_reg_6586.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read = HCALTowersR0_energy_2_reg_5556.read();
        } else {
            grp_uploadHCAL_fu_320_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_320_hcaltower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_hcaltower_fb_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR3_fb_V_13_reg_7176_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR3_fb_V_reg_6876_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR1_fb_V_s_reg_6146_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR2_fb_V_12_reg_6846.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR1_fb_V_2_reg_6066_pp0_iter1_reg.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR2_fb_V_5_reg_6601.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR2_fb_V_4_reg_6591.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read = HCALTowersR0_fb_V_2_reg_5561.read();
        } else {
            grp_uploadHCAL_fu_320_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_320_hcaltower_fb_V_read =  (sc_lv<6>) ("XXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_rcttower_energy_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = RCTTowersPHI_energy_93_reg_9033.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1170.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1127.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1184.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1011.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_918.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1057.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read = reg_1076.read();
        } else {
            grp_uploadHCAL_fu_320_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
        }
    } else {
        grp_uploadHCAL_fu_320_rcttower_energy_V_read =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_rcttower_flags_V_read() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = RCTTowersPHI_flags_V_94_reg_9027.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_1162.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_1117.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_1176.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_997.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_906.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_1043.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read = reg_1066.read();
        } else {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
        }
    } else {
        grp_uploadHCAL_fu_320_rcttower_flags_V_read =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_grp_uploadHCAL_fu_320_rcttower_flags_V_read_2() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = RCTTowersPHI_flags_V_94_reg_9027.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_1162.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_1117.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_1176.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_997.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_906.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_1043.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 = reg_1066.read();
        } else {
            grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
        }
    } else {
        grp_uploadHCAL_fu_320_rcttower_flags_V_read_2 =  (sc_lv<2>) ("XX");
    }
}

void processInputLinks::thread_trunc_ln647_1_fu_1306_p1() {
    trunc_ln647_1_fu_1306_p1 = link_in_5_V_read.read().range(16-1, 0);
}

void processInputLinks::thread_trunc_ln647_2_fu_1635_p1() {
    trunc_ln647_2_fu_1635_p1 = ap_port_reg_link_in_6_V_read.read().range(16-1, 0);
}

void processInputLinks::thread_trunc_ln647_3_fu_1962_p1() {
    trunc_ln647_3_fu_1962_p1 = ap_port_reg_link_in_7_V_read.read().range(16-1, 0);
}

void processInputLinks::thread_trunc_ln647_4_fu_2287_p1() {
    trunc_ln647_4_fu_2287_p1 = ap_port_reg_link_in_8_V_read.read().range(16-1, 0);
}

void processInputLinks::thread_trunc_ln647_fu_1221_p1() {
    trunc_ln647_fu_1221_p1 = link_in_0_V_read.read().range(64-1, 0);
}

}

