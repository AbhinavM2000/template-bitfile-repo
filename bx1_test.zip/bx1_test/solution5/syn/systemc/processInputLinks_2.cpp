#include "processInputLinks.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void processInputLinks::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_pp0_stage0;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter0_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read())) {
            ap_enable_reg_pp0_iter0_reg = ap_start.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8_subdone.read(), ap_const_boolean_0))) {
            ap_enable_reg_pp0_iter1 = ap_enable_reg_pp0_iter0.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter2 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage8_subdone.read(), ap_const_boolean_0))) {
            ap_enable_reg_pp0_iter2 = ap_enable_reg_pp0_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && 
                    esl_seteq<1,1,1>(ap_enable_reg_pp0_iter1.read(), ap_const_logic_0))) {
            ap_enable_reg_pp0_iter2 = ap_const_logic_0;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        grp_getECAL_fu_218_ap_start_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, grp_getECAL_fu_218_ap_ready.read())) {
            grp_getECAL_fu_218_ap_start_reg = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0))) {
        ECALTowersSLR0_0_en_reg_8071 = grp_getECAL_fu_218_ap_return_180.read();
        ECALTowersSLR0_0_ti_reg_8131 = grp_getECAL_fu_218_ap_return_192.read();
        ECALTowersSLR0_10_e_reg_8121 = grp_getECAL_fu_218_ap_return_190.read();
        ECALTowersSLR0_10_t_reg_8181 = grp_getECAL_fu_218_ap_return_202.read();
        ECALTowersSLR0_11_e_reg_8126 = grp_getECAL_fu_218_ap_return_191.read();
        ECALTowersSLR0_11_t_reg_8186 = grp_getECAL_fu_218_ap_return_203.read();
        ECALTowersSLR0_1_en_reg_8076 = grp_getECAL_fu_218_ap_return_181.read();
        ECALTowersSLR0_1_ti_reg_8136 = grp_getECAL_fu_218_ap_return_193.read();
        ECALTowersSLR0_2_en_reg_8081 = grp_getECAL_fu_218_ap_return_182.read();
        ECALTowersSLR0_2_ti_reg_8141 = grp_getECAL_fu_218_ap_return_194.read();
        ECALTowersSLR0_3_en_reg_8086 = grp_getECAL_fu_218_ap_return_183.read();
        ECALTowersSLR0_3_ti_reg_8146 = grp_getECAL_fu_218_ap_return_195.read();
        ECALTowersSLR0_4_en_reg_8091 = grp_getECAL_fu_218_ap_return_184.read();
        ECALTowersSLR0_4_ti_reg_8151 = grp_getECAL_fu_218_ap_return_196.read();
        ECALTowersSLR0_5_en_reg_8096 = grp_getECAL_fu_218_ap_return_185.read();
        ECALTowersSLR0_5_ti_reg_8156 = grp_getECAL_fu_218_ap_return_197.read();
        ECALTowersSLR0_6_en_reg_8101 = grp_getECAL_fu_218_ap_return_186.read();
        ECALTowersSLR0_6_ti_reg_8161 = grp_getECAL_fu_218_ap_return_198.read();
        ECALTowersSLR0_7_en_reg_8106 = grp_getECAL_fu_218_ap_return_187.read();
        ECALTowersSLR0_7_ti_reg_8166 = grp_getECAL_fu_218_ap_return_199.read();
        ECALTowersSLR0_8_en_reg_8111 = grp_getECAL_fu_218_ap_return_188.read();
        ECALTowersSLR0_8_ti_reg_8171 = grp_getECAL_fu_218_ap_return_200.read();
        ECALTowersSLR0_9_en_reg_8116 = grp_getECAL_fu_218_ap_return_189.read();
        ECALTowersSLR0_9_ti_reg_8176 = grp_getECAL_fu_218_ap_return_201.read();
        ECALTowersSLR1_0_en_reg_7771 = grp_getECAL_fu_218_ap_return_120.read();
        ECALTowersSLR1_0_ti_reg_7921 = grp_getECAL_fu_218_ap_return_150.read();
        ECALTowersSLR1_10_e_reg_7821 = grp_getECAL_fu_218_ap_return_130.read();
        ECALTowersSLR1_10_t_reg_7971 = grp_getECAL_fu_218_ap_return_160.read();
        ECALTowersSLR1_11_e_reg_7826 = grp_getECAL_fu_218_ap_return_131.read();
        ECALTowersSLR1_11_t_reg_7976 = grp_getECAL_fu_218_ap_return_161.read();
        ECALTowersSLR1_12_e_reg_7831 = grp_getECAL_fu_218_ap_return_132.read();
        ECALTowersSLR1_12_t_reg_7981 = grp_getECAL_fu_218_ap_return_162.read();
        ECALTowersSLR1_13_e_reg_7836 = grp_getECAL_fu_218_ap_return_133.read();
        ECALTowersSLR1_13_t_reg_7986 = grp_getECAL_fu_218_ap_return_163.read();
        ECALTowersSLR1_14_e_reg_7841 = grp_getECAL_fu_218_ap_return_134.read();
        ECALTowersSLR1_14_t_reg_7991 = grp_getECAL_fu_218_ap_return_164.read();
        ECALTowersSLR1_15_e_reg_7846 = grp_getECAL_fu_218_ap_return_135.read();
        ECALTowersSLR1_15_t_reg_7996 = grp_getECAL_fu_218_ap_return_165.read();
        ECALTowersSLR1_16_e_reg_7851 = grp_getECAL_fu_218_ap_return_136.read();
        ECALTowersSLR1_16_t_reg_8001 = grp_getECAL_fu_218_ap_return_166.read();
        ECALTowersSLR1_17_e_reg_7856 = grp_getECAL_fu_218_ap_return_137.read();
        ECALTowersSLR1_17_t_reg_8006 = grp_getECAL_fu_218_ap_return_167.read();
        ECALTowersSLR1_18_e_reg_7861 = grp_getECAL_fu_218_ap_return_138.read();
        ECALTowersSLR1_18_t_reg_8011 = grp_getECAL_fu_218_ap_return_168.read();
        ECALTowersSLR1_19_e_reg_7866 = grp_getECAL_fu_218_ap_return_139.read();
        ECALTowersSLR1_19_t_reg_8016 = grp_getECAL_fu_218_ap_return_169.read();
        ECALTowersSLR1_1_en_reg_7776 = grp_getECAL_fu_218_ap_return_121.read();
        ECALTowersSLR1_1_ti_reg_7926 = grp_getECAL_fu_218_ap_return_151.read();
        ECALTowersSLR1_20_e_reg_7871 = grp_getECAL_fu_218_ap_return_140.read();
        ECALTowersSLR1_20_t_reg_8021 = grp_getECAL_fu_218_ap_return_170.read();
        ECALTowersSLR1_21_e_reg_7876 = grp_getECAL_fu_218_ap_return_141.read();
        ECALTowersSLR1_21_t_reg_8026 = grp_getECAL_fu_218_ap_return_171.read();
        ECALTowersSLR1_22_e_reg_7881 = grp_getECAL_fu_218_ap_return_142.read();
        ECALTowersSLR1_22_t_reg_8031 = grp_getECAL_fu_218_ap_return_172.read();
        ECALTowersSLR1_23_e_reg_7886 = grp_getECAL_fu_218_ap_return_143.read();
        ECALTowersSLR1_23_t_reg_8036 = grp_getECAL_fu_218_ap_return_173.read();
        ECALTowersSLR1_24_e_reg_7891 = grp_getECAL_fu_218_ap_return_144.read();
        ECALTowersSLR1_24_t_reg_8041 = grp_getECAL_fu_218_ap_return_174.read();
        ECALTowersSLR1_25_e_reg_7896 = grp_getECAL_fu_218_ap_return_145.read();
        ECALTowersSLR1_25_t_reg_8046 = grp_getECAL_fu_218_ap_return_175.read();
        ECALTowersSLR1_26_e_reg_7901 = grp_getECAL_fu_218_ap_return_146.read();
        ECALTowersSLR1_26_t_reg_8051 = grp_getECAL_fu_218_ap_return_176.read();
        ECALTowersSLR1_27_e_reg_7906 = grp_getECAL_fu_218_ap_return_147.read();
        ECALTowersSLR1_27_t_reg_8056 = grp_getECAL_fu_218_ap_return_177.read();
        ECALTowersSLR1_28_e_reg_7911 = grp_getECAL_fu_218_ap_return_148.read();
        ECALTowersSLR1_28_t_reg_8061 = grp_getECAL_fu_218_ap_return_178.read();
        ECALTowersSLR1_29_e_reg_7916 = grp_getECAL_fu_218_ap_return_149.read();
        ECALTowersSLR1_29_t_reg_8066 = grp_getECAL_fu_218_ap_return_179.read();
        ECALTowersSLR1_2_en_reg_7781 = grp_getECAL_fu_218_ap_return_122.read();
        ECALTowersSLR1_2_ti_reg_7931 = grp_getECAL_fu_218_ap_return_152.read();
        ECALTowersSLR1_3_en_reg_7786 = grp_getECAL_fu_218_ap_return_123.read();
        ECALTowersSLR1_3_ti_reg_7936 = grp_getECAL_fu_218_ap_return_153.read();
        ECALTowersSLR1_4_en_reg_7791 = grp_getECAL_fu_218_ap_return_124.read();
        ECALTowersSLR1_4_ti_reg_7941 = grp_getECAL_fu_218_ap_return_154.read();
        ECALTowersSLR1_5_en_reg_7796 = grp_getECAL_fu_218_ap_return_125.read();
        ECALTowersSLR1_5_ti_reg_7946 = grp_getECAL_fu_218_ap_return_155.read();
        ECALTowersSLR1_6_en_reg_7801 = grp_getECAL_fu_218_ap_return_126.read();
        ECALTowersSLR1_6_ti_reg_7951 = grp_getECAL_fu_218_ap_return_156.read();
        ECALTowersSLR1_7_en_reg_7806 = grp_getECAL_fu_218_ap_return_127.read();
        ECALTowersSLR1_7_ti_reg_7956 = grp_getECAL_fu_218_ap_return_157.read();
        ECALTowersSLR1_8_en_reg_7811 = grp_getECAL_fu_218_ap_return_128.read();
        ECALTowersSLR1_8_ti_reg_7961 = grp_getECAL_fu_218_ap_return_158.read();
        ECALTowersSLR1_9_en_reg_7816 = grp_getECAL_fu_218_ap_return_129.read();
        ECALTowersSLR1_9_ti_reg_7966 = grp_getECAL_fu_218_ap_return_159.read();
        ECALTowersSLR2_0_en_reg_7471 = grp_getECAL_fu_218_ap_return_60.read();
        ECALTowersSLR2_0_ti_reg_7621 = grp_getECAL_fu_218_ap_return_90.read();
        ECALTowersSLR2_10_e_reg_7521 = grp_getECAL_fu_218_ap_return_70.read();
        ECALTowersSLR2_10_t_reg_7671 = grp_getECAL_fu_218_ap_return_100.read();
        ECALTowersSLR2_11_e_reg_7526 = grp_getECAL_fu_218_ap_return_71.read();
        ECALTowersSLR2_11_t_reg_7676 = grp_getECAL_fu_218_ap_return_101.read();
        ECALTowersSLR2_12_e_reg_7531 = grp_getECAL_fu_218_ap_return_72.read();
        ECALTowersSLR2_12_t_reg_7681 = grp_getECAL_fu_218_ap_return_102.read();
        ECALTowersSLR2_13_e_reg_7536 = grp_getECAL_fu_218_ap_return_73.read();
        ECALTowersSLR2_13_t_reg_7686 = grp_getECAL_fu_218_ap_return_103.read();
        ECALTowersSLR2_14_e_reg_7541 = grp_getECAL_fu_218_ap_return_74.read();
        ECALTowersSLR2_14_t_reg_7691 = grp_getECAL_fu_218_ap_return_104.read();
        ECALTowersSLR2_15_e_reg_7546 = grp_getECAL_fu_218_ap_return_75.read();
        ECALTowersSLR2_15_t_reg_7696 = grp_getECAL_fu_218_ap_return_105.read();
        ECALTowersSLR2_16_e_reg_7551 = grp_getECAL_fu_218_ap_return_76.read();
        ECALTowersSLR2_16_t_reg_7701 = grp_getECAL_fu_218_ap_return_106.read();
        ECALTowersSLR2_17_e_reg_7556 = grp_getECAL_fu_218_ap_return_77.read();
        ECALTowersSLR2_17_t_reg_7706 = grp_getECAL_fu_218_ap_return_107.read();
        ECALTowersSLR2_18_e_reg_7561 = grp_getECAL_fu_218_ap_return_78.read();
        ECALTowersSLR2_18_t_reg_7711 = grp_getECAL_fu_218_ap_return_108.read();
        ECALTowersSLR2_19_e_reg_7566 = grp_getECAL_fu_218_ap_return_79.read();
        ECALTowersSLR2_19_t_reg_7716 = grp_getECAL_fu_218_ap_return_109.read();
        ECALTowersSLR2_1_en_reg_7476 = grp_getECAL_fu_218_ap_return_61.read();
        ECALTowersSLR2_1_ti_reg_7626 = grp_getECAL_fu_218_ap_return_91.read();
        ECALTowersSLR2_20_e_reg_7571 = grp_getECAL_fu_218_ap_return_80.read();
        ECALTowersSLR2_20_t_reg_7721 = grp_getECAL_fu_218_ap_return_110.read();
        ECALTowersSLR2_21_e_reg_7576 = grp_getECAL_fu_218_ap_return_81.read();
        ECALTowersSLR2_21_t_reg_7726 = grp_getECAL_fu_218_ap_return_111.read();
        ECALTowersSLR2_22_e_reg_7581 = grp_getECAL_fu_218_ap_return_82.read();
        ECALTowersSLR2_22_t_reg_7731 = grp_getECAL_fu_218_ap_return_112.read();
        ECALTowersSLR2_23_e_reg_7586 = grp_getECAL_fu_218_ap_return_83.read();
        ECALTowersSLR2_23_t_reg_7736 = grp_getECAL_fu_218_ap_return_113.read();
        ECALTowersSLR2_24_e_reg_7591 = grp_getECAL_fu_218_ap_return_84.read();
        ECALTowersSLR2_24_t_reg_7741 = grp_getECAL_fu_218_ap_return_114.read();
        ECALTowersSLR2_25_e_reg_7596 = grp_getECAL_fu_218_ap_return_85.read();
        ECALTowersSLR2_25_t_reg_7746 = grp_getECAL_fu_218_ap_return_115.read();
        ECALTowersSLR2_26_e_reg_7601 = grp_getECAL_fu_218_ap_return_86.read();
        ECALTowersSLR2_26_t_reg_7751 = grp_getECAL_fu_218_ap_return_116.read();
        ECALTowersSLR2_27_e_reg_7606 = grp_getECAL_fu_218_ap_return_87.read();
        ECALTowersSLR2_27_t_reg_7756 = grp_getECAL_fu_218_ap_return_117.read();
        ECALTowersSLR2_28_e_reg_7611 = grp_getECAL_fu_218_ap_return_88.read();
        ECALTowersSLR2_28_t_reg_7761 = grp_getECAL_fu_218_ap_return_118.read();
        ECALTowersSLR2_29_e_reg_7616 = grp_getECAL_fu_218_ap_return_89.read();
        ECALTowersSLR2_29_t_reg_7766 = grp_getECAL_fu_218_ap_return_119.read();
        ECALTowersSLR2_2_en_reg_7481 = grp_getECAL_fu_218_ap_return_62.read();
        ECALTowersSLR2_2_ti_reg_7631 = grp_getECAL_fu_218_ap_return_92.read();
        ECALTowersSLR2_3_en_reg_7486 = grp_getECAL_fu_218_ap_return_63.read();
        ECALTowersSLR2_3_ti_reg_7636 = grp_getECAL_fu_218_ap_return_93.read();
        ECALTowersSLR2_4_en_reg_7491 = grp_getECAL_fu_218_ap_return_64.read();
        ECALTowersSLR2_4_ti_reg_7641 = grp_getECAL_fu_218_ap_return_94.read();
        ECALTowersSLR2_5_en_reg_7496 = grp_getECAL_fu_218_ap_return_65.read();
        ECALTowersSLR2_5_ti_reg_7646 = grp_getECAL_fu_218_ap_return_95.read();
        ECALTowersSLR2_6_en_reg_7501 = grp_getECAL_fu_218_ap_return_66.read();
        ECALTowersSLR2_6_ti_reg_7651 = grp_getECAL_fu_218_ap_return_96.read();
        ECALTowersSLR2_7_en_reg_7506 = grp_getECAL_fu_218_ap_return_67.read();
        ECALTowersSLR2_7_ti_reg_7656 = grp_getECAL_fu_218_ap_return_97.read();
        ECALTowersSLR2_8_en_reg_7511 = grp_getECAL_fu_218_ap_return_68.read();
        ECALTowersSLR2_8_ti_reg_7661 = grp_getECAL_fu_218_ap_return_98.read();
        ECALTowersSLR2_9_en_reg_7516 = grp_getECAL_fu_218_ap_return_69.read();
        ECALTowersSLR2_9_ti_reg_7666 = grp_getECAL_fu_218_ap_return_99.read();
        ECALTowersSLR3_10_e_reg_7311 = grp_getECAL_fu_218_ap_return_10.read();
        ECALTowersSLR3_10_t_reg_7401 = grp_getECAL_fu_218_ap_return_40.read();
        ECALTowersSLR3_11_e_reg_7316 = grp_getECAL_fu_218_ap_return_11.read();
        ECALTowersSLR3_11_t_reg_7406 = grp_getECAL_fu_218_ap_return_41.read();
        ECALTowersSLR3_14_e_reg_7321 = grp_getECAL_fu_218_ap_return_14.read();
        ECALTowersSLR3_14_t_reg_7411 = grp_getECAL_fu_218_ap_return_44.read();
        ECALTowersSLR3_15_e_reg_7326 = grp_getECAL_fu_218_ap_return_15.read();
        ECALTowersSLR3_15_t_reg_7416 = grp_getECAL_fu_218_ap_return_45.read();
        ECALTowersSLR3_16_e_reg_7331 = grp_getECAL_fu_218_ap_return_16.read();
        ECALTowersSLR3_16_t_reg_7421 = grp_getECAL_fu_218_ap_return_46.read();
        ECALTowersSLR3_17_e_reg_7336 = grp_getECAL_fu_218_ap_return_17.read();
        ECALTowersSLR3_17_t_reg_7426 = grp_getECAL_fu_218_ap_return_47.read();
        ECALTowersSLR3_20_e_reg_7341 = grp_getECAL_fu_218_ap_return_20.read();
        ECALTowersSLR3_20_t_reg_7431 = grp_getECAL_fu_218_ap_return_50.read();
        ECALTowersSLR3_21_e_reg_7346 = grp_getECAL_fu_218_ap_return_21.read();
        ECALTowersSLR3_21_t_reg_7436 = grp_getECAL_fu_218_ap_return_51.read();
        ECALTowersSLR3_22_e_reg_7351 = grp_getECAL_fu_218_ap_return_22.read();
        ECALTowersSLR3_22_t_reg_7441 = grp_getECAL_fu_218_ap_return_52.read();
        ECALTowersSLR3_23_e_reg_7356 = grp_getECAL_fu_218_ap_return_23.read();
        ECALTowersSLR3_23_t_reg_7446 = grp_getECAL_fu_218_ap_return_53.read();
        ECALTowersSLR3_26_e_reg_7361 = grp_getECAL_fu_218_ap_return_26.read();
        ECALTowersSLR3_26_t_reg_7451 = grp_getECAL_fu_218_ap_return_56.read();
        ECALTowersSLR3_27_e_reg_7366 = grp_getECAL_fu_218_ap_return_27.read();
        ECALTowersSLR3_27_t_reg_7456 = grp_getECAL_fu_218_ap_return_57.read();
        ECALTowersSLR3_28_e_reg_7371 = grp_getECAL_fu_218_ap_return_28.read();
        ECALTowersSLR3_28_t_reg_7461 = grp_getECAL_fu_218_ap_return_58.read();
        ECALTowersSLR3_29_e_reg_7376 = grp_getECAL_fu_218_ap_return_29.read();
        ECALTowersSLR3_29_t_reg_7466 = grp_getECAL_fu_218_ap_return_59.read();
        ECALTowersSLR3_3_en_reg_7291 = grp_getECAL_fu_218_ap_return_3.read();
        ECALTowersSLR3_3_ti_reg_7381 = grp_getECAL_fu_218_ap_return_33.read();
        ECALTowersSLR3_4_en_reg_7296 = grp_getECAL_fu_218_ap_return_4.read();
        ECALTowersSLR3_4_ti_reg_7386 = grp_getECAL_fu_218_ap_return_34.read();
        ECALTowersSLR3_5_en_reg_7301 = grp_getECAL_fu_218_ap_return_5.read();
        ECALTowersSLR3_5_ti_reg_7391 = grp_getECAL_fu_218_ap_return_35.read();
        ECALTowersSLR3_9_en_reg_7306 = grp_getECAL_fu_218_ap_return_9.read();
        ECALTowersSLR3_9_ti_reg_7396 = grp_getECAL_fu_218_ap_return_39.read();
        RCTECALClusters_8_b_reg_7286_pp0_iter1_reg = RCTECALClusters_8_b_reg_7286.read();
        RCTECALClusters_8_e_5_reg_7251_pp0_iter1_reg = RCTECALClusters_8_e_5_reg_7251.read();
        RCTECALClusters_8_e_6_reg_7261_pp0_iter1_reg = RCTECALClusters_8_e_6_reg_7261.read();
        RCTECALClusters_8_e_reg_7246_pp0_iter1_reg = RCTECALClusters_8_e_reg_7246.read();
        RCTECALClusters_8_p_reg_7256_pp0_iter1_reg = RCTECALClusters_8_p_reg_7256.read();
        RCTECALClusters_8_s_5_reg_7276_pp0_iter1_reg = RCTECALClusters_8_s_5_reg_7276.read();
        RCTECALClusters_8_s_6_reg_7281_pp0_iter1_reg = RCTECALClusters_8_s_6_reg_7281.read();
        RCTECALClusters_8_s_reg_7241_pp0_iter1_reg = RCTECALClusters_8_s_reg_7241.read();
        RCTECALClusters_8_t_reg_7271_pp0_iter1_reg = RCTECALClusters_8_t_reg_7271.read();
        RCTECALClusters_8_w_reg_7266_pp0_iter1_reg = RCTECALClusters_8_w_reg_7266.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_10_reg_5646 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR0_energy_11_reg_5656 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR0_energy_12_reg_5666 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR0_energy_13_reg_5676 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR0_energy_1_reg_5546 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR0_energy_2_reg_5556 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR0_energy_31_reg_5636 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR0_energy_3_reg_5566 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR0_energy_4_reg_5576 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR0_energy_5_reg_5586 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR0_energy_6_reg_5596 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR0_energy_7_reg_5606 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR0_energy_8_reg_5616 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR0_energy_9_reg_5626 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR0_energy_s_reg_5536 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR0_fb_V_10_reg_5651 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR0_fb_V_11_reg_5661 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR0_fb_V_12_reg_5671 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR0_fb_V_13_reg_5681 = grp_fillhcaltower_fu_476_ap_return_1.read();
        HCALTowersR0_fb_V_1_reg_5551 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR0_fb_V_2_reg_5561 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR0_fb_V_3_reg_5571 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR0_fb_V_4_reg_5581 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR0_fb_V_5_reg_5591 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR0_fb_V_6_reg_5601 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR0_fb_V_7_reg_5611 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR0_fb_V_8_reg_5621 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR0_fb_V_9_reg_5631 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR0_fb_V_reg_5541 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR0_fb_V_s_reg_5641 = grp_fillhcaltower_fu_456_ap_return_1.read();
        RCTECALClusters_0_b_reg_5491 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_0_e_5_reg_5456 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_0_e_6_reg_5466 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_0_e_reg_5451 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_0_p_reg_5461 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_0_s_5_reg_5481 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_0_s_6_reg_5486 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_0_s_reg_5446 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_0_t_reg_5476 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_0_w_reg_5471 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
        ap_port_reg_link_in_6_V_read = link_in_6_V_read.read();
        ap_port_reg_link_in_7_V_read = link_in_7_V_read.read();
        ap_port_reg_link_in_8_V_read = link_in_8_V_read.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_10_reg_5646_pp0_iter1_reg = HCALTowersR0_energy_10_reg_5646.read();
        HCALTowersR0_energy_13_reg_5676_pp0_iter1_reg = HCALTowersR0_energy_13_reg_5676.read();
        HCALTowersR0_energy_31_reg_5636_pp0_iter1_reg = HCALTowersR0_energy_31_reg_5636.read();
        HCALTowersR0_energy_3_reg_5566_pp0_iter1_reg = HCALTowersR0_energy_3_reg_5566.read();
        HCALTowersR0_energy_6_reg_5596_pp0_iter1_reg = HCALTowersR0_energy_6_reg_5596.read();
        HCALTowersR0_energy_7_reg_5606_pp0_iter1_reg = HCALTowersR0_energy_7_reg_5606.read();
        HCALTowersR0_fb_V_10_reg_5651_pp0_iter1_reg = HCALTowersR0_fb_V_10_reg_5651.read();
        HCALTowersR0_fb_V_13_reg_5681_pp0_iter1_reg = HCALTowersR0_fb_V_13_reg_5681.read();
        HCALTowersR0_fb_V_3_reg_5571_pp0_iter1_reg = HCALTowersR0_fb_V_3_reg_5571.read();
        HCALTowersR0_fb_V_6_reg_5601_pp0_iter1_reg = HCALTowersR0_fb_V_6_reg_5601.read();
        HCALTowersR0_fb_V_7_reg_5611_pp0_iter1_reg = HCALTowersR0_fb_V_7_reg_5611.read();
        HCALTowersR0_fb_V_s_reg_5641_pp0_iter1_reg = HCALTowersR0_fb_V_s_reg_5641.read();
        RCTECALClusters_0_b_reg_5491_pp0_iter1_reg = RCTECALClusters_0_b_reg_5491.read();
        RCTECALClusters_0_e_5_reg_5456_pp0_iter1_reg = RCTECALClusters_0_e_5_reg_5456.read();
        RCTECALClusters_0_e_6_reg_5466_pp0_iter1_reg = RCTECALClusters_0_e_6_reg_5466.read();
        RCTECALClusters_0_e_reg_5451_pp0_iter1_reg = RCTECALClusters_0_e_reg_5451.read();
        RCTECALClusters_0_p_reg_5461_pp0_iter1_reg = RCTECALClusters_0_p_reg_5461.read();
        RCTECALClusters_0_s_5_reg_5481_pp0_iter1_reg = RCTECALClusters_0_s_5_reg_5481.read();
        RCTECALClusters_0_s_6_reg_5486_pp0_iter1_reg = RCTECALClusters_0_s_6_reg_5486.read();
        RCTECALClusters_0_s_reg_5446_pp0_iter1_reg = RCTECALClusters_0_s_reg_5446.read();
        RCTECALClusters_0_t_reg_5476_pp0_iter1_reg = RCTECALClusters_0_t_reg_5476.read();
        RCTECALClusters_0_w_reg_5471_pp0_iter1_reg = RCTECALClusters_0_w_reg_5471.read();
        p_Result_16_14_reg_5686 = link_in_5_V_read.read().range(255, 240);
        p_Result_16_15_reg_5691 = link_in_5_V_read.read().range(271, 256);
        p_Result_16_16_reg_5696 = link_in_5_V_read.read().range(287, 272);
        p_Result_16_17_reg_5701 = link_in_5_V_read.read().range(303, 288);
        p_Result_16_18_reg_5706 = link_in_5_V_read.read().range(319, 304);
        p_Result_16_19_reg_5711 = link_in_5_V_read.read().range(335, 320);
        p_Result_16_20_reg_5716 = link_in_5_V_read.read().range(351, 336);
        p_Result_16_21_reg_5721 = link_in_5_V_read.read().range(367, 352);
        p_Result_16_22_reg_5726 = link_in_5_V_read.read().range(383, 368);
        p_Result_16_23_reg_5731 = link_in_5_V_read.read().range(399, 384);
        p_Result_16_24_reg_5736 = link_in_5_V_read.read().range(415, 400);
        p_Result_16_25_reg_5741 = link_in_5_V_read.read().range(431, 416);
        p_Result_16_26_reg_5746 = link_in_5_V_read.read().range(447, 432);
        p_Result_16_27_reg_5751 = link_in_5_V_read.read().range(463, 448);
        p_Result_16_28_reg_5756 = link_in_5_V_read.read().range(479, 464);
        p_Result_16_29_reg_5761 = link_in_5_V_read.read().range(495, 480);
        p_Result_16_30_reg_5766 = link_in_5_V_read.read().range(511, 496);
        p_Result_1_reg_5496 = link_in_0_V_read.read().range(127, 64);
        p_Result_2_reg_5501 = link_in_0_V_read.read().range(191, 128);
        p_Result_3_reg_5506 = link_in_0_V_read.read().range(255, 192);
        p_Result_4_reg_5511 = link_in_0_V_read.read().range(319, 256);
        p_Result_5_reg_5516 = link_in_0_V_read.read().range(383, 320);
        p_Result_6_reg_5521 = link_in_0_V_read.read().range(447, 384);
        p_Result_7_reg_5526 = link_in_0_V_read.read().range(511, 448);
        p_Result_8_reg_5531 = link_in_0_V_read.read().range(575, 512);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_14_reg_5821 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR0_energy_15_reg_5831 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR0_energy_16_reg_5841 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR0_energy_17_reg_5851 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR0_energy_18_reg_5861 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR0_energy_19_reg_5871 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR0_energy_20_reg_5881 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR0_energy_21_reg_5891 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR0_energy_22_reg_5901 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR0_energy_23_reg_5911 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR0_energy_24_reg_5921 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR0_energy_25_reg_5931 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR0_energy_26_reg_5941 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR0_energy_27_reg_5951 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR0_energy_28_reg_5961 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR0_fb_V_14_reg_5826 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR0_fb_V_15_reg_5836 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR0_fb_V_16_reg_5846 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR0_fb_V_17_reg_5856 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR0_fb_V_18_reg_5866 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR0_fb_V_19_reg_5876 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR0_fb_V_20_reg_5886 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR0_fb_V_21_reg_5896 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR0_fb_V_22_reg_5906 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR0_fb_V_23_reg_5916 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR0_fb_V_24_reg_5926 = grp_fillhcaltower_fu_456_ap_return_1.read();
        HCALTowersR0_fb_V_25_reg_5936 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR0_fb_V_26_reg_5946 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR0_fb_V_27_reg_5956 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR0_fb_V_28_reg_5966 = grp_fillhcaltower_fu_476_ap_return_1.read();
        RCTECALClusters_1_b_reg_5816 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_1_e_5_reg_5781 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_1_e_6_reg_5791 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_1_e_reg_5776 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_1_p_reg_5786 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_1_s_5_reg_5806 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_1_s_6_reg_5811 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_1_s_reg_5771 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_1_t_reg_5801 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_1_w_reg_5796 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_19_reg_5871_pp0_iter1_reg = HCALTowersR0_energy_19_reg_5871.read();
        HCALTowersR0_energy_20_reg_5881_pp0_iter1_reg = HCALTowersR0_energy_20_reg_5881.read();
        HCALTowersR0_energy_21_reg_5891_pp0_iter1_reg = HCALTowersR0_energy_21_reg_5891.read();
        HCALTowersR0_energy_22_reg_5901_pp0_iter1_reg = HCALTowersR0_energy_22_reg_5901.read();
        HCALTowersR0_energy_23_reg_5911_pp0_iter1_reg = HCALTowersR0_energy_23_reg_5911.read();
        HCALTowersR0_energy_24_reg_5921_pp0_iter1_reg = HCALTowersR0_energy_24_reg_5921.read();
        HCALTowersR0_energy_25_reg_5931_pp0_iter1_reg = HCALTowersR0_energy_25_reg_5931.read();
        HCALTowersR0_energy_26_reg_5941_pp0_iter1_reg = HCALTowersR0_energy_26_reg_5941.read();
        HCALTowersR0_energy_27_reg_5951_pp0_iter1_reg = HCALTowersR0_energy_27_reg_5951.read();
        HCALTowersR0_energy_28_reg_5961_pp0_iter1_reg = HCALTowersR0_energy_28_reg_5961.read();
        HCALTowersR0_fb_V_19_reg_5876_pp0_iter1_reg = HCALTowersR0_fb_V_19_reg_5876.read();
        HCALTowersR0_fb_V_20_reg_5886_pp0_iter1_reg = HCALTowersR0_fb_V_20_reg_5886.read();
        HCALTowersR0_fb_V_21_reg_5896_pp0_iter1_reg = HCALTowersR0_fb_V_21_reg_5896.read();
        HCALTowersR0_fb_V_22_reg_5906_pp0_iter1_reg = HCALTowersR0_fb_V_22_reg_5906.read();
        HCALTowersR0_fb_V_23_reg_5916_pp0_iter1_reg = HCALTowersR0_fb_V_23_reg_5916.read();
        HCALTowersR0_fb_V_24_reg_5926_pp0_iter1_reg = HCALTowersR0_fb_V_24_reg_5926.read();
        HCALTowersR0_fb_V_25_reg_5936_pp0_iter1_reg = HCALTowersR0_fb_V_25_reg_5936.read();
        HCALTowersR0_fb_V_26_reg_5946_pp0_iter1_reg = HCALTowersR0_fb_V_26_reg_5946.read();
        HCALTowersR0_fb_V_27_reg_5956_pp0_iter1_reg = HCALTowersR0_fb_V_27_reg_5956.read();
        HCALTowersR0_fb_V_28_reg_5966_pp0_iter1_reg = HCALTowersR0_fb_V_28_reg_5966.read();
        RCTECALClusters_1_b_reg_5816_pp0_iter1_reg = RCTECALClusters_1_b_reg_5816.read();
        RCTECALClusters_1_e_5_reg_5781_pp0_iter1_reg = RCTECALClusters_1_e_5_reg_5781.read();
        RCTECALClusters_1_e_6_reg_5791_pp0_iter1_reg = RCTECALClusters_1_e_6_reg_5791.read();
        RCTECALClusters_1_e_reg_5776_pp0_iter1_reg = RCTECALClusters_1_e_reg_5776.read();
        RCTECALClusters_1_p_reg_5786_pp0_iter1_reg = RCTECALClusters_1_p_reg_5786.read();
        RCTECALClusters_1_s_5_reg_5806_pp0_iter1_reg = RCTECALClusters_1_s_5_reg_5806.read();
        RCTECALClusters_1_s_6_reg_5811_pp0_iter1_reg = RCTECALClusters_1_s_6_reg_5811.read();
        RCTECALClusters_1_s_reg_5771_pp0_iter1_reg = RCTECALClusters_1_s_reg_5771.read();
        RCTECALClusters_1_t_reg_5801_pp0_iter1_reg = RCTECALClusters_1_t_reg_5801.read();
        RCTECALClusters_1_w_reg_5796_pp0_iter1_reg = RCTECALClusters_1_w_reg_5796.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_29_reg_6021 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR0_energy_30_reg_6031 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR0_fb_V_29_reg_6026 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR0_fb_V_30_reg_6036 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR1_energy_10_reg_6151 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR1_energy_11_reg_6161 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR1_energy_1_reg_6051 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR1_energy_2_reg_6061 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR1_energy_31_reg_6141 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR1_energy_3_reg_6071 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR1_energy_4_reg_6081 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR1_energy_5_reg_6091 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR1_energy_6_reg_6101 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR1_energy_7_reg_6111 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR1_energy_8_reg_6121 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR1_energy_9_reg_6131 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR1_energy_s_reg_6041 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR1_fb_V_10_reg_6156 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR1_fb_V_11_reg_6166 = grp_fillhcaltower_fu_476_ap_return_1.read();
        HCALTowersR1_fb_V_1_reg_6056 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR1_fb_V_2_reg_6066 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR1_fb_V_3_reg_6076 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR1_fb_V_4_reg_6086 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR1_fb_V_5_reg_6096 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR1_fb_V_6_reg_6106 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR1_fb_V_7_reg_6116 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR1_fb_V_8_reg_6126 = grp_fillhcaltower_fu_456_ap_return_1.read();
        HCALTowersR1_fb_V_9_reg_6136 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR1_fb_V_reg_6046 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR1_fb_V_s_reg_6146 = grp_fillhcaltower_fu_466_ap_return_1.read();
        RCTECALClusters_2_b_reg_6016 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_2_e_5_reg_5981 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_2_e_6_reg_5991 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_2_e_reg_5976 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_2_p_reg_5986 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_2_s_5_reg_6006 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_2_s_6_reg_6011 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_2_s_reg_5971 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_2_t_reg_6001 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_2_w_reg_5996 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0))) {
        HCALTowersR0_energy_29_reg_6021_pp0_iter1_reg = HCALTowersR0_energy_29_reg_6021.read();
        HCALTowersR0_energy_30_reg_6031_pp0_iter1_reg = HCALTowersR0_energy_30_reg_6031.read();
        HCALTowersR0_fb_V_29_reg_6026_pp0_iter1_reg = HCALTowersR0_fb_V_29_reg_6026.read();
        HCALTowersR0_fb_V_30_reg_6036_pp0_iter1_reg = HCALTowersR0_fb_V_30_reg_6036.read();
        HCALTowersR1_energy_10_reg_6151_pp0_iter1_reg = HCALTowersR1_energy_10_reg_6151.read();
        HCALTowersR1_energy_11_reg_6161_pp0_iter1_reg = HCALTowersR1_energy_11_reg_6161.read();
        HCALTowersR1_energy_1_reg_6051_pp0_iter1_reg = HCALTowersR1_energy_1_reg_6051.read();
        HCALTowersR1_energy_2_reg_6061_pp0_iter1_reg = HCALTowersR1_energy_2_reg_6061.read();
        HCALTowersR1_energy_31_reg_6141_pp0_iter1_reg = HCALTowersR1_energy_31_reg_6141.read();
        HCALTowersR1_energy_3_reg_6071_pp0_iter1_reg = HCALTowersR1_energy_3_reg_6071.read();
        HCALTowersR1_energy_5_reg_6091_pp0_iter1_reg = HCALTowersR1_energy_5_reg_6091.read();
        HCALTowersR1_energy_6_reg_6101_pp0_iter1_reg = HCALTowersR1_energy_6_reg_6101.read();
        HCALTowersR1_energy_7_reg_6111_pp0_iter1_reg = HCALTowersR1_energy_7_reg_6111.read();
        HCALTowersR1_energy_8_reg_6121_pp0_iter1_reg = HCALTowersR1_energy_8_reg_6121.read();
        HCALTowersR1_energy_9_reg_6131_pp0_iter1_reg = HCALTowersR1_energy_9_reg_6131.read();
        HCALTowersR1_fb_V_10_reg_6156_pp0_iter1_reg = HCALTowersR1_fb_V_10_reg_6156.read();
        HCALTowersR1_fb_V_11_reg_6166_pp0_iter1_reg = HCALTowersR1_fb_V_11_reg_6166.read();
        HCALTowersR1_fb_V_1_reg_6056_pp0_iter1_reg = HCALTowersR1_fb_V_1_reg_6056.read();
        HCALTowersR1_fb_V_2_reg_6066_pp0_iter1_reg = HCALTowersR1_fb_V_2_reg_6066.read();
        HCALTowersR1_fb_V_3_reg_6076_pp0_iter1_reg = HCALTowersR1_fb_V_3_reg_6076.read();
        HCALTowersR1_fb_V_5_reg_6096_pp0_iter1_reg = HCALTowersR1_fb_V_5_reg_6096.read();
        HCALTowersR1_fb_V_6_reg_6106_pp0_iter1_reg = HCALTowersR1_fb_V_6_reg_6106.read();
        HCALTowersR1_fb_V_7_reg_6116_pp0_iter1_reg = HCALTowersR1_fb_V_7_reg_6116.read();
        HCALTowersR1_fb_V_8_reg_6126_pp0_iter1_reg = HCALTowersR1_fb_V_8_reg_6126.read();
        HCALTowersR1_fb_V_9_reg_6136_pp0_iter1_reg = HCALTowersR1_fb_V_9_reg_6136.read();
        HCALTowersR1_fb_V_s_reg_6146_pp0_iter1_reg = HCALTowersR1_fb_V_s_reg_6146.read();
        RCTECALClusters_2_b_reg_6016_pp0_iter1_reg = RCTECALClusters_2_b_reg_6016.read();
        RCTECALClusters_2_e_5_reg_5981_pp0_iter1_reg = RCTECALClusters_2_e_5_reg_5981.read();
        RCTECALClusters_2_e_6_reg_5991_pp0_iter1_reg = RCTECALClusters_2_e_6_reg_5991.read();
        RCTECALClusters_2_e_reg_5976_pp0_iter1_reg = RCTECALClusters_2_e_reg_5976.read();
        RCTECALClusters_2_p_reg_5986_pp0_iter1_reg = RCTECALClusters_2_p_reg_5986.read();
        RCTECALClusters_2_s_5_reg_6006_pp0_iter1_reg = RCTECALClusters_2_s_5_reg_6006.read();
        RCTECALClusters_2_s_6_reg_6011_pp0_iter1_reg = RCTECALClusters_2_s_6_reg_6011.read();
        RCTECALClusters_2_s_reg_5971_pp0_iter1_reg = RCTECALClusters_2_s_reg_5971.read();
        RCTECALClusters_2_t_reg_6001_pp0_iter1_reg = RCTECALClusters_2_t_reg_6001.read();
        RCTECALClusters_2_w_reg_5996_pp0_iter1_reg = RCTECALClusters_2_w_reg_5996.read();
        p_Result_17_12_reg_6171 = ap_port_reg_link_in_6_V_read.read().range(223, 208);
        p_Result_17_13_reg_6176 = ap_port_reg_link_in_6_V_read.read().range(239, 224);
        p_Result_17_14_reg_6181 = ap_port_reg_link_in_6_V_read.read().range(255, 240);
        p_Result_17_15_reg_6186 = ap_port_reg_link_in_6_V_read.read().range(271, 256);
        p_Result_17_16_reg_6191 = ap_port_reg_link_in_6_V_read.read().range(287, 272);
        p_Result_17_17_reg_6196 = ap_port_reg_link_in_6_V_read.read().range(303, 288);
        p_Result_17_18_reg_6201 = ap_port_reg_link_in_6_V_read.read().range(319, 304);
        p_Result_17_19_reg_6206 = ap_port_reg_link_in_6_V_read.read().range(335, 320);
        p_Result_17_20_reg_6211 = ap_port_reg_link_in_6_V_read.read().range(351, 336);
        p_Result_17_21_reg_6216 = ap_port_reg_link_in_6_V_read.read().range(367, 352);
        p_Result_17_22_reg_6221 = ap_port_reg_link_in_6_V_read.read().range(383, 368);
        p_Result_17_23_reg_6226 = ap_port_reg_link_in_6_V_read.read().range(399, 384);
        p_Result_17_24_reg_6231 = ap_port_reg_link_in_6_V_read.read().range(415, 400);
        p_Result_17_25_reg_6236 = ap_port_reg_link_in_6_V_read.read().range(431, 416);
        p_Result_17_26_reg_6241 = ap_port_reg_link_in_6_V_read.read().range(447, 432);
        p_Result_17_27_reg_6246 = ap_port_reg_link_in_6_V_read.read().range(463, 448);
        p_Result_17_28_reg_6251 = ap_port_reg_link_in_6_V_read.read().range(479, 464);
        p_Result_17_29_reg_6256 = ap_port_reg_link_in_6_V_read.read().range(495, 480);
        p_Result_17_30_reg_6261 = ap_port_reg_link_in_6_V_read.read().range(511, 496);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
        HCALTowersR1_energy_12_reg_6316 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR1_energy_13_reg_6326 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR1_energy_14_reg_6336 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR1_energy_15_reg_6346 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR1_energy_16_reg_6356 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR1_energy_17_reg_6366 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR1_energy_18_reg_6376 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR1_energy_19_reg_6386 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR1_energy_20_reg_6396 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR1_energy_21_reg_6406 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR1_energy_22_reg_6416 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR1_energy_23_reg_6426 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR1_energy_24_reg_6436 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR1_energy_25_reg_6446 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR1_energy_26_reg_6456 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR1_fb_V_12_reg_6321 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR1_fb_V_13_reg_6331 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR1_fb_V_14_reg_6341 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR1_fb_V_15_reg_6351 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR1_fb_V_16_reg_6361 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR1_fb_V_17_reg_6371 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR1_fb_V_18_reg_6381 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR1_fb_V_19_reg_6391 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR1_fb_V_20_reg_6401 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR1_fb_V_21_reg_6411 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR1_fb_V_22_reg_6421 = grp_fillhcaltower_fu_456_ap_return_1.read();
        HCALTowersR1_fb_V_23_reg_6431 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR1_fb_V_24_reg_6441 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR1_fb_V_25_reg_6451 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR1_fb_V_26_reg_6461 = grp_fillhcaltower_fu_476_ap_return_1.read();
        RCTECALClusters_3_b_reg_6311 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_3_e_5_reg_6276 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_3_e_6_reg_6286 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_3_e_reg_6271 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_3_p_reg_6281 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_3_s_5_reg_6301 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_3_s_6_reg_6306 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_3_s_reg_6266 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_3_t_reg_6296 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_3_w_reg_6291 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
        HCALTowersR1_energy_12_reg_6316_pp0_iter1_reg = HCALTowersR1_energy_12_reg_6316.read();
        HCALTowersR1_energy_13_reg_6326_pp0_iter1_reg = HCALTowersR1_energy_13_reg_6326.read();
        HCALTowersR1_energy_14_reg_6336_pp0_iter1_reg = HCALTowersR1_energy_14_reg_6336.read();
        HCALTowersR1_energy_15_reg_6346_pp0_iter1_reg = HCALTowersR1_energy_15_reg_6346.read();
        HCALTowersR1_energy_16_reg_6356_pp0_iter1_reg = HCALTowersR1_energy_16_reg_6356.read();
        HCALTowersR1_energy_17_reg_6366_pp0_iter1_reg = HCALTowersR1_energy_17_reg_6366.read();
        HCALTowersR1_energy_18_reg_6376_pp0_iter1_reg = HCALTowersR1_energy_18_reg_6376.read();
        HCALTowersR1_energy_19_reg_6386_pp0_iter1_reg = HCALTowersR1_energy_19_reg_6386.read();
        HCALTowersR1_energy_20_reg_6396_pp0_iter1_reg = HCALTowersR1_energy_20_reg_6396.read();
        HCALTowersR1_energy_21_reg_6406_pp0_iter1_reg = HCALTowersR1_energy_21_reg_6406.read();
        HCALTowersR1_energy_22_reg_6416_pp0_iter1_reg = HCALTowersR1_energy_22_reg_6416.read();
        HCALTowersR1_energy_23_reg_6426_pp0_iter1_reg = HCALTowersR1_energy_23_reg_6426.read();
        HCALTowersR1_energy_24_reg_6436_pp0_iter1_reg = HCALTowersR1_energy_24_reg_6436.read();
        HCALTowersR1_energy_25_reg_6446_pp0_iter1_reg = HCALTowersR1_energy_25_reg_6446.read();
        HCALTowersR1_energy_26_reg_6456_pp0_iter1_reg = HCALTowersR1_energy_26_reg_6456.read();
        HCALTowersR1_fb_V_12_reg_6321_pp0_iter1_reg = HCALTowersR1_fb_V_12_reg_6321.read();
        HCALTowersR1_fb_V_13_reg_6331_pp0_iter1_reg = HCALTowersR1_fb_V_13_reg_6331.read();
        HCALTowersR1_fb_V_14_reg_6341_pp0_iter1_reg = HCALTowersR1_fb_V_14_reg_6341.read();
        HCALTowersR1_fb_V_15_reg_6351_pp0_iter1_reg = HCALTowersR1_fb_V_15_reg_6351.read();
        HCALTowersR1_fb_V_16_reg_6361_pp0_iter1_reg = HCALTowersR1_fb_V_16_reg_6361.read();
        HCALTowersR1_fb_V_17_reg_6371_pp0_iter1_reg = HCALTowersR1_fb_V_17_reg_6371.read();
        HCALTowersR1_fb_V_18_reg_6381_pp0_iter1_reg = HCALTowersR1_fb_V_18_reg_6381.read();
        HCALTowersR1_fb_V_19_reg_6391_pp0_iter1_reg = HCALTowersR1_fb_V_19_reg_6391.read();
        HCALTowersR1_fb_V_20_reg_6401_pp0_iter1_reg = HCALTowersR1_fb_V_20_reg_6401.read();
        HCALTowersR1_fb_V_21_reg_6411_pp0_iter1_reg = HCALTowersR1_fb_V_21_reg_6411.read();
        HCALTowersR1_fb_V_22_reg_6421_pp0_iter1_reg = HCALTowersR1_fb_V_22_reg_6421.read();
        HCALTowersR1_fb_V_23_reg_6431_pp0_iter1_reg = HCALTowersR1_fb_V_23_reg_6431.read();
        HCALTowersR1_fb_V_24_reg_6441_pp0_iter1_reg = HCALTowersR1_fb_V_24_reg_6441.read();
        HCALTowersR1_fb_V_25_reg_6451_pp0_iter1_reg = HCALTowersR1_fb_V_25_reg_6451.read();
        HCALTowersR1_fb_V_26_reg_6461_pp0_iter1_reg = HCALTowersR1_fb_V_26_reg_6461.read();
        RCTECALClusters_3_b_reg_6311_pp0_iter1_reg = RCTECALClusters_3_b_reg_6311.read();
        RCTECALClusters_3_e_5_reg_6276_pp0_iter1_reg = RCTECALClusters_3_e_5_reg_6276.read();
        RCTECALClusters_3_e_6_reg_6286_pp0_iter1_reg = RCTECALClusters_3_e_6_reg_6286.read();
        RCTECALClusters_3_e_reg_6271_pp0_iter1_reg = RCTECALClusters_3_e_reg_6271.read();
        RCTECALClusters_3_p_reg_6281_pp0_iter1_reg = RCTECALClusters_3_p_reg_6281.read();
        RCTECALClusters_3_s_5_reg_6301_pp0_iter1_reg = RCTECALClusters_3_s_5_reg_6301.read();
        RCTECALClusters_3_s_6_reg_6306_pp0_iter1_reg = RCTECALClusters_3_s_6_reg_6306.read();
        RCTECALClusters_3_s_reg_6266_pp0_iter1_reg = RCTECALClusters_3_s_reg_6266.read();
        RCTECALClusters_3_t_reg_6296_pp0_iter1_reg = RCTECALClusters_3_t_reg_6296.read();
        RCTECALClusters_3_w_reg_6291_pp0_iter1_reg = RCTECALClusters_3_w_reg_6291.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0))) {
        HCALTowersR1_energy_27_reg_6516 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR1_energy_28_reg_6526 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR1_energy_29_reg_6536 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR1_energy_30_reg_6546 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR1_fb_V_27_reg_6521 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR1_fb_V_28_reg_6531 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR1_fb_V_29_reg_6541 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR1_fb_V_30_reg_6551 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR2_energy_15_reg_6706 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR2_energy_1_reg_6566 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR2_energy_2_reg_6586 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR2_energy_3_reg_6596 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR2_energy_4_reg_6616 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR2_energy_5_reg_6626 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR2_energy_6_reg_6646 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR2_energy_7_reg_6656 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR2_energy_8_reg_6676 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR2_energy_9_reg_6686 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR2_energy_s_reg_6556 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR2_fb_V_1_reg_6571 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR2_fb_V_2_reg_6661 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR2_fb_V_3_reg_6681 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR2_fb_V_4_reg_6591 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR2_fb_V_5_reg_6601 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR2_fb_V_6_reg_6691 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR2_fb_V_7_reg_6711 = grp_fillhcaltower_fu_476_ap_return_1.read();
        HCALTowersR2_fb_V_8_reg_6621 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR2_fb_V_9_reg_6631 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR2_fb_V_reg_6561 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR2_fb_V_s_reg_6651 = grp_fillhcaltower_fu_456_ap_return_1.read();
        RCTECALClusters_4_b_reg_6511 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_4_e_5_reg_6476 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_4_e_6_reg_6486 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_4_e_reg_6471 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_4_p_reg_6481 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_4_s_5_reg_6501 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_4_s_6_reg_6506 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_4_s_reg_6466 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_4_t_reg_6496 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_4_w_reg_6491 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0))) {
        HCALTowersR1_energy_27_reg_6516_pp0_iter1_reg = HCALTowersR1_energy_27_reg_6516.read();
        HCALTowersR1_energy_28_reg_6526_pp0_iter1_reg = HCALTowersR1_energy_28_reg_6526.read();
        HCALTowersR1_energy_29_reg_6536_pp0_iter1_reg = HCALTowersR1_energy_29_reg_6536.read();
        HCALTowersR1_energy_30_reg_6546_pp0_iter1_reg = HCALTowersR1_energy_30_reg_6546.read();
        HCALTowersR1_fb_V_27_reg_6521_pp0_iter1_reg = HCALTowersR1_fb_V_27_reg_6521.read();
        HCALTowersR1_fb_V_28_reg_6531_pp0_iter1_reg = HCALTowersR1_fb_V_28_reg_6531.read();
        HCALTowersR1_fb_V_29_reg_6541_pp0_iter1_reg = HCALTowersR1_fb_V_29_reg_6541.read();
        HCALTowersR1_fb_V_30_reg_6551_pp0_iter1_reg = HCALTowersR1_fb_V_30_reg_6551.read();
        RCTECALClusters_4_b_reg_6511_pp0_iter1_reg = RCTECALClusters_4_b_reg_6511.read();
        RCTECALClusters_4_e_5_reg_6476_pp0_iter1_reg = RCTECALClusters_4_e_5_reg_6476.read();
        RCTECALClusters_4_e_6_reg_6486_pp0_iter1_reg = RCTECALClusters_4_e_6_reg_6486.read();
        RCTECALClusters_4_e_reg_6471_pp0_iter1_reg = RCTECALClusters_4_e_reg_6471.read();
        RCTECALClusters_4_p_reg_6481_pp0_iter1_reg = RCTECALClusters_4_p_reg_6481.read();
        RCTECALClusters_4_s_5_reg_6501_pp0_iter1_reg = RCTECALClusters_4_s_5_reg_6501.read();
        RCTECALClusters_4_s_6_reg_6506_pp0_iter1_reg = RCTECALClusters_4_s_6_reg_6506.read();
        RCTECALClusters_4_s_reg_6466_pp0_iter1_reg = RCTECALClusters_4_s_reg_6466.read();
        RCTECALClusters_4_t_reg_6496_pp0_iter1_reg = RCTECALClusters_4_t_reg_6496.read();
        RCTECALClusters_4_w_reg_6491_pp0_iter1_reg = RCTECALClusters_4_w_reg_6491.read();
        p_Result_18_10_reg_6641 = ap_port_reg_link_in_7_V_read.read().range(191, 176);
        p_Result_18_13_reg_6666 = ap_port_reg_link_in_7_V_read.read().range(239, 224);
        p_Result_18_14_reg_6671 = ap_port_reg_link_in_7_V_read.read().range(255, 240);
        p_Result_18_17_reg_6696 = ap_port_reg_link_in_7_V_read.read().range(303, 288);
        p_Result_18_18_reg_6701 = ap_port_reg_link_in_7_V_read.read().range(319, 304);
        p_Result_18_20_reg_6716 = ap_port_reg_link_in_7_V_read.read().range(351, 336);
        p_Result_18_21_reg_6721 = ap_port_reg_link_in_7_V_read.read().range(367, 352);
        p_Result_18_22_reg_6726 = ap_port_reg_link_in_7_V_read.read().range(383, 368);
        p_Result_18_23_reg_6731 = ap_port_reg_link_in_7_V_read.read().range(399, 384);
        p_Result_18_24_reg_6736 = ap_port_reg_link_in_7_V_read.read().range(415, 400);
        p_Result_18_25_reg_6741 = ap_port_reg_link_in_7_V_read.read().range(431, 416);
        p_Result_18_26_reg_6746 = ap_port_reg_link_in_7_V_read.read().range(447, 432);
        p_Result_18_27_reg_6751 = ap_port_reg_link_in_7_V_read.read().range(463, 448);
        p_Result_18_28_reg_6756 = ap_port_reg_link_in_7_V_read.read().range(479, 464);
        p_Result_18_29_reg_6761 = ap_port_reg_link_in_7_V_read.read().range(495, 480);
        p_Result_18_2_reg_6576 = ap_port_reg_link_in_7_V_read.read().range(47, 32);
        p_Result_18_30_reg_6766 = ap_port_reg_link_in_7_V_read.read().range(511, 496);
        p_Result_18_3_reg_6581 = ap_port_reg_link_in_7_V_read.read().range(63, 48);
        p_Result_18_6_reg_6606 = ap_port_reg_link_in_7_V_read.read().range(111, 96);
        p_Result_18_7_reg_6611 = ap_port_reg_link_in_7_V_read.read().range(127, 112);
        p_Result_18_s_reg_6636 = ap_port_reg_link_in_7_V_read.read().range(175, 160);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0))) {
        HCALTowersR2_energy_10_reg_6821 = grp_fillhcaltower_fu_406_ap_return_0.read();
        HCALTowersR2_energy_11_reg_6831 = grp_fillhcaltower_fu_411_ap_return_0.read();
        HCALTowersR2_energy_12_reg_6841 = grp_fillhcaltower_fu_416_ap_return_0.read();
        HCALTowersR2_energy_13_reg_6851 = grp_fillhcaltower_fu_421_ap_return_0.read();
        HCALTowersR2_energy_14_reg_6861 = grp_fillhcaltower_fu_426_ap_return_0.read();
        HCALTowersR2_fb_V_10_reg_6826 = grp_fillhcaltower_fu_406_ap_return_1.read();
        HCALTowersR2_fb_V_11_reg_6836 = grp_fillhcaltower_fu_411_ap_return_1.read();
        HCALTowersR2_fb_V_12_reg_6846 = grp_fillhcaltower_fu_416_ap_return_1.read();
        HCALTowersR2_fb_V_13_reg_6856 = grp_fillhcaltower_fu_421_ap_return_1.read();
        HCALTowersR2_fb_V_14_reg_6866 = grp_fillhcaltower_fu_426_ap_return_1.read();
        HCALTowersR3_energy_1_reg_6881 = grp_fillhcaltower_fu_436_ap_return_0.read();
        HCALTowersR3_energy_2_reg_6901 = grp_fillhcaltower_fu_441_ap_return_0.read();
        HCALTowersR3_energy_3_reg_6911 = grp_fillhcaltower_fu_446_ap_return_0.read();
        HCALTowersR3_energy_4_reg_6931 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR3_energy_5_reg_6941 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR3_energy_6_reg_6961 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR3_energy_7_reg_6971 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR3_energy_8_reg_6991 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR3_energy_9_reg_7001 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR3_energy_s_reg_6871 = grp_fillhcaltower_fu_431_ap_return_0.read();
        HCALTowersR3_fb_V_1_reg_6886 = grp_fillhcaltower_fu_436_ap_return_1.read();
        HCALTowersR3_fb_V_2_reg_6976 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR3_fb_V_3_reg_6996 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR3_fb_V_4_reg_6906 = grp_fillhcaltower_fu_441_ap_return_1.read();
        HCALTowersR3_fb_V_5_reg_6916 = grp_fillhcaltower_fu_446_ap_return_1.read();
        HCALTowersR3_fb_V_6_reg_7006 = grp_fillhcaltower_fu_476_ap_return_1.read();
        HCALTowersR3_fb_V_8_reg_6936 = grp_fillhcaltower_fu_451_ap_return_1.read();
        HCALTowersR3_fb_V_9_reg_6946 = grp_fillhcaltower_fu_456_ap_return_1.read();
        HCALTowersR3_fb_V_reg_6876 = grp_fillhcaltower_fu_431_ap_return_1.read();
        HCALTowersR3_fb_V_s_reg_6966 = grp_fillhcaltower_fu_461_ap_return_1.read();
        RCTECALClusters_5_b_reg_6816 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_5_e_5_reg_6781 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_5_e_6_reg_6791 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_5_e_reg_6776 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_5_p_reg_6786 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_5_s_5_reg_6806 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_5_s_6_reg_6811 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_5_s_reg_6771 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_5_t_reg_6801 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_5_w_reg_6796 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0))) {
        HCALTowersR2_energy_14_reg_6861_pp0_iter1_reg = HCALTowersR2_energy_14_reg_6861.read();
        HCALTowersR2_fb_V_14_reg_6866_pp0_iter1_reg = HCALTowersR2_fb_V_14_reg_6866.read();
        HCALTowersR3_energy_1_reg_6881_pp0_iter1_reg = HCALTowersR3_energy_1_reg_6881.read();
        HCALTowersR3_energy_2_reg_6901_pp0_iter1_reg = HCALTowersR3_energy_2_reg_6901.read();
        HCALTowersR3_energy_3_reg_6911_pp0_iter1_reg = HCALTowersR3_energy_3_reg_6911.read();
        HCALTowersR3_energy_4_reg_6931_pp0_iter1_reg = HCALTowersR3_energy_4_reg_6931.read();
        HCALTowersR3_energy_5_reg_6941_pp0_iter1_reg = HCALTowersR3_energy_5_reg_6941.read();
        HCALTowersR3_energy_6_reg_6961_pp0_iter1_reg = HCALTowersR3_energy_6_reg_6961.read();
        HCALTowersR3_energy_7_reg_6971_pp0_iter1_reg = HCALTowersR3_energy_7_reg_6971.read();
        HCALTowersR3_energy_8_reg_6991_pp0_iter1_reg = HCALTowersR3_energy_8_reg_6991.read();
        HCALTowersR3_energy_9_reg_7001_pp0_iter1_reg = HCALTowersR3_energy_9_reg_7001.read();
        HCALTowersR3_energy_s_reg_6871_pp0_iter1_reg = HCALTowersR3_energy_s_reg_6871.read();
        HCALTowersR3_fb_V_1_reg_6886_pp0_iter1_reg = HCALTowersR3_fb_V_1_reg_6886.read();
        HCALTowersR3_fb_V_2_reg_6976_pp0_iter1_reg = HCALTowersR3_fb_V_2_reg_6976.read();
        HCALTowersR3_fb_V_3_reg_6996_pp0_iter1_reg = HCALTowersR3_fb_V_3_reg_6996.read();
        HCALTowersR3_fb_V_4_reg_6906_pp0_iter1_reg = HCALTowersR3_fb_V_4_reg_6906.read();
        HCALTowersR3_fb_V_5_reg_6916_pp0_iter1_reg = HCALTowersR3_fb_V_5_reg_6916.read();
        HCALTowersR3_fb_V_6_reg_7006_pp0_iter1_reg = HCALTowersR3_fb_V_6_reg_7006.read();
        HCALTowersR3_fb_V_8_reg_6936_pp0_iter1_reg = HCALTowersR3_fb_V_8_reg_6936.read();
        HCALTowersR3_fb_V_9_reg_6946_pp0_iter1_reg = HCALTowersR3_fb_V_9_reg_6946.read();
        HCALTowersR3_fb_V_reg_6876_pp0_iter1_reg = HCALTowersR3_fb_V_reg_6876.read();
        HCALTowersR3_fb_V_s_reg_6966_pp0_iter1_reg = HCALTowersR3_fb_V_s_reg_6966.read();
        RCTECALClusters_5_b_reg_6816_pp0_iter1_reg = RCTECALClusters_5_b_reg_6816.read();
        RCTECALClusters_5_e_5_reg_6781_pp0_iter1_reg = RCTECALClusters_5_e_5_reg_6781.read();
        RCTECALClusters_5_e_6_reg_6791_pp0_iter1_reg = RCTECALClusters_5_e_6_reg_6791.read();
        RCTECALClusters_5_e_reg_6776_pp0_iter1_reg = RCTECALClusters_5_e_reg_6776.read();
        RCTECALClusters_5_p_reg_6786_pp0_iter1_reg = RCTECALClusters_5_p_reg_6786.read();
        RCTECALClusters_5_s_5_reg_6806_pp0_iter1_reg = RCTECALClusters_5_s_5_reg_6806.read();
        RCTECALClusters_5_s_6_reg_6811_pp0_iter1_reg = RCTECALClusters_5_s_6_reg_6811.read();
        RCTECALClusters_5_s_reg_6771_pp0_iter1_reg = RCTECALClusters_5_s_reg_6771.read();
        RCTECALClusters_5_t_reg_6801_pp0_iter1_reg = RCTECALClusters_5_t_reg_6801.read();
        RCTECALClusters_5_w_reg_6796_pp0_iter1_reg = RCTECALClusters_5_w_reg_6796.read();
        p_Result_19_10_reg_6956 = ap_port_reg_link_in_8_V_read.read().range(191, 176);
        p_Result_19_13_reg_6981 = ap_port_reg_link_in_8_V_read.read().range(239, 224);
        p_Result_19_14_reg_6986 = ap_port_reg_link_in_8_V_read.read().range(255, 240);
        p_Result_19_17_reg_7011 = ap_port_reg_link_in_8_V_read.read().range(303, 288);
        p_Result_19_18_reg_7016 = ap_port_reg_link_in_8_V_read.read().range(319, 304);
        p_Result_19_19_reg_7021 = ap_port_reg_link_in_8_V_read.read().range(335, 320);
        p_Result_19_20_reg_7026 = ap_port_reg_link_in_8_V_read.read().range(351, 336);
        p_Result_19_21_reg_7031 = ap_port_reg_link_in_8_V_read.read().range(367, 352);
        p_Result_19_22_reg_7036 = ap_port_reg_link_in_8_V_read.read().range(383, 368);
        p_Result_19_23_reg_7041 = ap_port_reg_link_in_8_V_read.read().range(399, 384);
        p_Result_19_24_reg_7046 = ap_port_reg_link_in_8_V_read.read().range(415, 400);
        p_Result_19_25_reg_7051 = ap_port_reg_link_in_8_V_read.read().range(431, 416);
        p_Result_19_26_reg_7056 = ap_port_reg_link_in_8_V_read.read().range(447, 432);
        p_Result_19_27_reg_7061 = ap_port_reg_link_in_8_V_read.read().range(463, 448);
        p_Result_19_28_reg_7066 = ap_port_reg_link_in_8_V_read.read().range(479, 464);
        p_Result_19_29_reg_7071 = ap_port_reg_link_in_8_V_read.read().range(495, 480);
        p_Result_19_2_reg_6891 = ap_port_reg_link_in_8_V_read.read().range(47, 32);
        p_Result_19_30_reg_7076 = ap_port_reg_link_in_8_V_read.read().range(511, 496);
        p_Result_19_3_reg_6896 = ap_port_reg_link_in_8_V_read.read().range(63, 48);
        p_Result_19_6_reg_6921 = ap_port_reg_link_in_8_V_read.read().range(111, 96);
        p_Result_19_7_reg_6926 = ap_port_reg_link_in_8_V_read.read().range(127, 112);
        p_Result_19_s_reg_6951 = ap_port_reg_link_in_8_V_read.read().range(175, 160);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0))) {
        HCALTowersR3_energy_10_reg_7141 = grp_fillhcaltower_fu_456_ap_return_0.read();
        HCALTowersR3_energy_11_reg_7151 = grp_fillhcaltower_fu_461_ap_return_0.read();
        HCALTowersR3_energy_12_reg_7161 = grp_fillhcaltower_fu_466_ap_return_0.read();
        HCALTowersR3_energy_13_reg_7171 = grp_fillhcaltower_fu_471_ap_return_0.read();
        HCALTowersR3_energy_14_reg_7181 = grp_fillhcaltower_fu_476_ap_return_0.read();
        HCALTowersR3_energy_15_reg_7131 = grp_fillhcaltower_fu_451_ap_return_0.read();
        HCALTowersR3_fb_V_10_reg_7146 = grp_fillhcaltower_fu_456_ap_return_1.read();
        HCALTowersR3_fb_V_11_reg_7156 = grp_fillhcaltower_fu_461_ap_return_1.read();
        HCALTowersR3_fb_V_12_reg_7166 = grp_fillhcaltower_fu_466_ap_return_1.read();
        HCALTowersR3_fb_V_13_reg_7176 = grp_fillhcaltower_fu_471_ap_return_1.read();
        HCALTowersR3_fb_V_14_reg_7186 = grp_fillhcaltower_fu_476_ap_return_1.read();
        HCALTowersR3_fb_V_7_reg_7136 = grp_fillhcaltower_fu_451_ap_return_1.read();
        RCTECALClusters_6_b_reg_7126 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_6_e_5_reg_7091 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_6_e_6_reg_7101 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_6_e_reg_7086 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_6_p_reg_7096 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_6_s_5_reg_7116 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_6_s_6_reg_7121 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_6_s_reg_7081 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_6_t_reg_7111 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_6_w_reg_7106 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0))) {
        HCALTowersR3_energy_10_reg_7141_pp0_iter1_reg = HCALTowersR3_energy_10_reg_7141.read();
        HCALTowersR3_energy_11_reg_7151_pp0_iter1_reg = HCALTowersR3_energy_11_reg_7151.read();
        HCALTowersR3_energy_12_reg_7161_pp0_iter1_reg = HCALTowersR3_energy_12_reg_7161.read();
        HCALTowersR3_energy_13_reg_7171_pp0_iter1_reg = HCALTowersR3_energy_13_reg_7171.read();
        HCALTowersR3_energy_14_reg_7181_pp0_iter1_reg = HCALTowersR3_energy_14_reg_7181.read();
        HCALTowersR3_energy_15_reg_7131_pp0_iter1_reg = HCALTowersR3_energy_15_reg_7131.read();
        HCALTowersR3_fb_V_10_reg_7146_pp0_iter1_reg = HCALTowersR3_fb_V_10_reg_7146.read();
        HCALTowersR3_fb_V_11_reg_7156_pp0_iter1_reg = HCALTowersR3_fb_V_11_reg_7156.read();
        HCALTowersR3_fb_V_12_reg_7166_pp0_iter1_reg = HCALTowersR3_fb_V_12_reg_7166.read();
        HCALTowersR3_fb_V_13_reg_7176_pp0_iter1_reg = HCALTowersR3_fb_V_13_reg_7176.read();
        HCALTowersR3_fb_V_14_reg_7186_pp0_iter1_reg = HCALTowersR3_fb_V_14_reg_7186.read();
        HCALTowersR3_fb_V_7_reg_7136_pp0_iter1_reg = HCALTowersR3_fb_V_7_reg_7136.read();
        RCTECALClusters_6_b_reg_7126_pp0_iter1_reg = RCTECALClusters_6_b_reg_7126.read();
        RCTECALClusters_6_e_5_reg_7091_pp0_iter1_reg = RCTECALClusters_6_e_5_reg_7091.read();
        RCTECALClusters_6_e_6_reg_7101_pp0_iter1_reg = RCTECALClusters_6_e_6_reg_7101.read();
        RCTECALClusters_6_e_reg_7086_pp0_iter1_reg = RCTECALClusters_6_e_reg_7086.read();
        RCTECALClusters_6_p_reg_7096_pp0_iter1_reg = RCTECALClusters_6_p_reg_7096.read();
        RCTECALClusters_6_s_5_reg_7116_pp0_iter1_reg = RCTECALClusters_6_s_5_reg_7116.read();
        RCTECALClusters_6_s_6_reg_7121_pp0_iter1_reg = RCTECALClusters_6_s_6_reg_7121.read();
        RCTECALClusters_6_s_reg_7081_pp0_iter1_reg = RCTECALClusters_6_s_reg_7081.read();
        RCTECALClusters_6_t_reg_7111_pp0_iter1_reg = RCTECALClusters_6_t_reg_7111.read();
        RCTECALClusters_6_w_reg_7106_pp0_iter1_reg = RCTECALClusters_6_w_reg_7106.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0))) {
        RCTECALClusters_7_b_reg_7236 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_7_e_5_reg_7201 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_7_e_6_reg_7211 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_7_e_reg_7196 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_7_p_reg_7206 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_7_s_5_reg_7226 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_7_s_6_reg_7231 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_7_s_reg_7191 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_7_t_reg_7221 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_7_w_reg_7216 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0))) {
        RCTECALClusters_7_b_reg_7236_pp0_iter1_reg = RCTECALClusters_7_b_reg_7236.read();
        RCTECALClusters_7_e_5_reg_7201_pp0_iter1_reg = RCTECALClusters_7_e_5_reg_7201.read();
        RCTECALClusters_7_e_6_reg_7211_pp0_iter1_reg = RCTECALClusters_7_e_6_reg_7211.read();
        RCTECALClusters_7_e_reg_7196_pp0_iter1_reg = RCTECALClusters_7_e_reg_7196.read();
        RCTECALClusters_7_p_reg_7206_pp0_iter1_reg = RCTECALClusters_7_p_reg_7206.read();
        RCTECALClusters_7_s_5_reg_7226_pp0_iter1_reg = RCTECALClusters_7_s_5_reg_7226.read();
        RCTECALClusters_7_s_6_reg_7231_pp0_iter1_reg = RCTECALClusters_7_s_6_reg_7231.read();
        RCTECALClusters_7_s_reg_7191_pp0_iter1_reg = RCTECALClusters_7_s_reg_7191.read();
        RCTECALClusters_7_t_reg_7221_pp0_iter1_reg = RCTECALClusters_7_t_reg_7221.read();
        RCTECALClusters_7_w_reg_7216_pp0_iter1_reg = RCTECALClusters_7_w_reg_7216.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0))) {
        RCTECALClusters_8_b_reg_7286 = grp_fillrctecalcluster_fu_401_ap_return_9.read();
        RCTECALClusters_8_e_5_reg_7251 = grp_fillrctecalcluster_fu_401_ap_return_2.read();
        RCTECALClusters_8_e_6_reg_7261 = grp_fillrctecalcluster_fu_401_ap_return_4.read();
        RCTECALClusters_8_e_reg_7246 = grp_fillrctecalcluster_fu_401_ap_return_1.read();
        RCTECALClusters_8_p_reg_7256 = grp_fillrctecalcluster_fu_401_ap_return_3.read();
        RCTECALClusters_8_s_5_reg_7276 = grp_fillrctecalcluster_fu_401_ap_return_7.read();
        RCTECALClusters_8_s_6_reg_7281 = grp_fillrctecalcluster_fu_401_ap_return_8.read();
        RCTECALClusters_8_s_reg_7241 = grp_fillrctecalcluster_fu_401_ap_return_0.read();
        RCTECALClusters_8_t_reg_7271 = grp_fillrctecalcluster_fu_401_ap_return_6.read();
        RCTECALClusters_8_w_reg_7266 = grp_fillrctecalcluster_fu_401_ap_return_5.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_0_0_h_reg_8191 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_0_1_h_reg_8206 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_0_2_h_reg_8221 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_0_3_h_reg_8236 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_0_4_h_reg_8251 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_1_0_h_reg_8266 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_1_1_h_reg_8281 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_1_2_h_reg_8296 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_1_3_h_reg_8311 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_1_4_h_reg_8326 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_2_0_h_reg_8341 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_energy_103_reg_8271 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_104_reg_8286 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_105_reg_8301 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_106_reg_8316 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_107_reg_8331 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_111_reg_8346 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_energy_95_reg_8196 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_96_reg_8211 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_97_reg_8226 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_98_reg_8241 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_99_reg_8256 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_flags_V_103_reg_8276 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_104_reg_8291 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_105_reg_8306 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_106_reg_8321 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_107_reg_8336 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_111_reg_8351 = grp_uploadHCAL_fu_320_ap_return_2.read();
        RCTTowersPHI_flags_V_96_reg_8216 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_97_reg_8231 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_98_reg_8246 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_99_reg_8261 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_reg_8201 = grp_uploadHCAL_fu_230_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_0_10_s_reg_9038 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_0_11_s_reg_9053 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_0_12_s_reg_9068 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_0_13_s_reg_9083 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_0_14_s_reg_9098 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_1_10_s_reg_9113 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_1_11_s_reg_9128 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_1_12_s_reg_9143 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_1_13_s_reg_9158 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_1_14_s_reg_9173 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_2_10_s_reg_9188 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_energy_129_reg_9043 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_130_reg_9058 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_131_reg_9073 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_132_reg_9088 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_133_reg_9103 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_137_reg_9118 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_138_reg_9133 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_139_reg_9148 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_140_reg_9163 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_141_reg_9178 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_145_reg_9193 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_energy_93_reg_9033 = grp_uploadECAL_fu_389_ap_return_1.read();
        RCTTowersPHI_flags_V_129_reg_9048 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_130_reg_9063 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_131_reg_9078 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_132_reg_9093 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_133_reg_9108 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_137_reg_9123 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_138_reg_9138 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_139_reg_9153 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_140_reg_9168 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_141_reg_9183 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_145_reg_9198 = grp_uploadHCAL_fu_320_ap_return_2.read();
        RCTTowersPHI_flags_V_94_reg_9027 = grp_uploadECAL_fu_389_ap_return_0.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        RCTTowersPHI_0_15_s_reg_9398 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_1_15_s_reg_9413 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_2_15_s_reg_9428 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_3_15_s_reg_9443 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_4_10_s_reg_9473 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_4_11_s_reg_9488 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_4_12_s_reg_9503 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_4_13_s_reg_9518 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_4_14_s_reg_9533 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_4_15_s_reg_9548 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_4_9_h_reg_9458 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_energy_134_reg_9403 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_142_reg_9418 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_150_reg_9433 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_158_reg_9448 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_176_reg_9463 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_177_reg_9478 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_178_reg_9493 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_179_reg_9508 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_180_reg_9523 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_181_reg_9538 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_182_reg_9553 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_flags_V_134_reg_9408 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_142_reg_9423 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_150_reg_9438 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_158_reg_9453 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_176_reg_9468 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_177_reg_9483 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_178_reg_9498 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_179_reg_9513 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_180_reg_9528 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_181_reg_9543 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_182_reg_9558 = grp_uploadHCAL_fu_320_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_0_16_3_reg_9208 = grp_uploadECAL_fu_329_ap_return_1.read();
        RCTTowersPHI_0_16_s_reg_9203 = grp_uploadECAL_fu_329_ap_return_0.read();
        RCTTowersPHI_1_16_3_reg_9218 = grp_uploadECAL_fu_335_ap_return_1.read();
        RCTTowersPHI_1_16_s_reg_9213 = grp_uploadECAL_fu_335_ap_return_0.read();
        RCTTowersPHI_2_11_s_reg_9233 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_2_12_s_reg_9248 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_2_13_s_reg_9263 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_2_14_s_reg_9278 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_2_16_3_reg_9228 = grp_uploadECAL_fu_341_ap_return_1.read();
        RCTTowersPHI_2_16_s_reg_9223 = grp_uploadECAL_fu_341_ap_return_0.read();
        RCTTowersPHI_3_10_s_reg_9293 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_3_11_s_reg_9308 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_3_12_s_reg_9323 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_3_13_s_reg_9338 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_3_14_s_reg_9353 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_4_8_h_reg_9383 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_5_7_h_reg_9368 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_energy_146_reg_9238 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_147_reg_9253 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_148_reg_9268 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_149_reg_9283 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_153_reg_9298 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_154_reg_9313 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_155_reg_9328 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_156_reg_9343 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_157_reg_9358 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_174_reg_9373 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_175_reg_9388 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_flags_V_146_reg_9243 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_147_reg_9258 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_148_reg_9273 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_149_reg_9288 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_153_reg_9303 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_154_reg_9318 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_155_reg_9333 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_156_reg_9348 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_157_reg_9363 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_174_reg_9378 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_175_reg_9393 = grp_uploadHCAL_fu_320_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_0_5_h_reg_8521 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_0_6_h_reg_8536 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_0_7_h_reg_8551 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_0_8_h_reg_8581 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_0_9_h_reg_8596 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_1_5_h_reg_8566 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_4_2_h_reg_8611 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_4_3_h_reg_8626 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_4_4_h_reg_8641 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_5_0_h_reg_8656 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_5_1_h_reg_8671 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_energy_100_reg_8526 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_101_reg_8541 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_102_reg_8556 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_108_reg_8571 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_127_reg_8586 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_128_reg_8601 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_161_reg_8616 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_162_reg_8631 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_163_reg_8646 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_167_reg_8661 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_168_reg_8676 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_flags_V_100_reg_8531 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_101_reg_8546 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_102_reg_8561 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_108_reg_8576 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_127_reg_8591 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_128_reg_8606 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_161_reg_8621 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_162_reg_8636 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_163_reg_8651 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_167_reg_8666 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_168_reg_8681 = grp_uploadHCAL_fu_320_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_1_6_h_reg_8686 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_1_7_h_reg_8701 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_1_8_h_reg_8806 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_1_9_h_reg_8821 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_2_5_h_reg_8716 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_2_6_h_reg_8731 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_2_7_h_reg_8746 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_2_8_h_reg_8836 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_3_5_h_reg_8761 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_3_6_h_reg_8776 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_3_7_h_reg_8791 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_energy_109_reg_8691 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_110_reg_8706 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_116_reg_8721 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_117_reg_8736 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_118_reg_8751 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_124_reg_8766 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_125_reg_8781 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_126_reg_8796 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_135_reg_8811 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_136_reg_8826 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_143_reg_8841 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_flags_V_109_reg_8696 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_110_reg_8711 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_116_reg_8726 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_117_reg_8741 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_118_reg_8756 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_124_reg_8771 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_125_reg_8786 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_126_reg_8801 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_135_reg_8816 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_136_reg_8831 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_143_reg_8846 = grp_uploadHCAL_fu_320_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_2_1_h_reg_8356 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_2_2_h_reg_8371 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_2_3_h_reg_8386 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_2_4_h_reg_8401 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_3_0_h_reg_8416 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_3_1_h_reg_8431 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_3_2_h_reg_8446 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_3_3_h_reg_8461 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_3_4_h_reg_8476 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_4_0_h_reg_8491 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_4_1_h_reg_8506 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_energy_112_reg_8361 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_113_reg_8376 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_114_reg_8391 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_115_reg_8406 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_119_reg_8421 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_120_reg_8436 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_121_reg_8451 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_122_reg_8466 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_123_reg_8481 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_159_reg_8496 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_160_reg_8511 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_flags_V_112_reg_8366 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_113_reg_8381 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_114_reg_8396 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_115_reg_8411 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_119_reg_8426 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_120_reg_8441 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_121_reg_8456 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_122_reg_8471 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_123_reg_8486 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_159_reg_8501 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_160_reg_8516 = grp_uploadHCAL_fu_320_ap_return_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0))) {
        RCTTowersPHI_2_9_h_reg_8862 = grp_uploadHCAL_fu_230_ap_return_1.read();
        RCTTowersPHI_3_8_h_reg_8877 = grp_uploadHCAL_fu_239_ap_return_1.read();
        RCTTowersPHI_3_9_h_reg_8892 = grp_uploadHCAL_fu_248_ap_return_1.read();
        RCTTowersPHI_4_5_h_reg_8907 = grp_uploadHCAL_fu_257_ap_return_1.read();
        RCTTowersPHI_4_6_h_reg_8922 = grp_uploadHCAL_fu_266_ap_return_1.read();
        RCTTowersPHI_4_7_h_reg_8937 = grp_uploadHCAL_fu_275_ap_return_1.read();
        RCTTowersPHI_5_2_h_reg_8952 = grp_uploadHCAL_fu_284_ap_return_1.read();
        RCTTowersPHI_5_3_h_reg_8967 = grp_uploadHCAL_fu_293_ap_return_1.read();
        RCTTowersPHI_5_4_h_reg_8982 = grp_uploadHCAL_fu_302_ap_return_1.read();
        RCTTowersPHI_5_5_h_reg_8997 = grp_uploadHCAL_fu_311_ap_return_1.read();
        RCTTowersPHI_5_6_h_reg_9012 = grp_uploadHCAL_fu_320_ap_return_1.read();
        RCTTowersPHI_energy_144_reg_8867 = grp_uploadHCAL_fu_230_ap_return_0.read();
        RCTTowersPHI_energy_151_reg_8882 = grp_uploadHCAL_fu_239_ap_return_0.read();
        RCTTowersPHI_energy_152_reg_8897 = grp_uploadHCAL_fu_248_ap_return_0.read();
        RCTTowersPHI_energy_164_reg_8912 = grp_uploadHCAL_fu_257_ap_return_0.read();
        RCTTowersPHI_energy_165_reg_8927 = grp_uploadHCAL_fu_266_ap_return_0.read();
        RCTTowersPHI_energy_166_reg_8942 = grp_uploadHCAL_fu_275_ap_return_0.read();
        RCTTowersPHI_energy_169_reg_8957 = grp_uploadHCAL_fu_284_ap_return_0.read();
        RCTTowersPHI_energy_170_reg_8972 = grp_uploadHCAL_fu_293_ap_return_0.read();
        RCTTowersPHI_energy_171_reg_8987 = grp_uploadHCAL_fu_302_ap_return_0.read();
        RCTTowersPHI_energy_172_reg_9002 = grp_uploadHCAL_fu_311_ap_return_0.read();
        RCTTowersPHI_energy_173_reg_9017 = grp_uploadHCAL_fu_320_ap_return_0.read();
        RCTTowersPHI_energy_82_reg_8857 = grp_uploadECAL_fu_395_ap_return_1.read();
        RCTTowersPHI_flags_V_144_reg_8872 = grp_uploadHCAL_fu_230_ap_return_2.read();
        RCTTowersPHI_flags_V_151_reg_8887 = grp_uploadHCAL_fu_239_ap_return_2.read();
        RCTTowersPHI_flags_V_152_reg_8902 = grp_uploadHCAL_fu_248_ap_return_2.read();
        RCTTowersPHI_flags_V_164_reg_8917 = grp_uploadHCAL_fu_257_ap_return_2.read();
        RCTTowersPHI_flags_V_165_reg_8932 = grp_uploadHCAL_fu_266_ap_return_2.read();
        RCTTowersPHI_flags_V_166_reg_8947 = grp_uploadHCAL_fu_275_ap_return_2.read();
        RCTTowersPHI_flags_V_169_reg_8962 = grp_uploadHCAL_fu_284_ap_return_2.read();
        RCTTowersPHI_flags_V_170_reg_8977 = grp_uploadHCAL_fu_293_ap_return_2.read();
        RCTTowersPHI_flags_V_171_reg_8992 = grp_uploadHCAL_fu_302_ap_return_2.read();
        RCTTowersPHI_flags_V_172_reg_9007 = grp_uploadHCAL_fu_311_ap_return_2.read();
        RCTTowersPHI_flags_V_173_reg_9022 = grp_uploadHCAL_fu_320_ap_return_2.read();
        RCTTowersPHI_flags_V_83_reg_8851 = grp_uploadECAL_fu_395_ap_return_0.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_1011 = grp_uploadECAL_fu_371_ap_return_1.read();
        reg_869 = grp_uploadECAL_fu_329_ap_return_0.read();
        reg_881 = grp_uploadECAL_fu_329_ap_return_1.read();
        reg_889 = grp_uploadECAL_fu_335_ap_return_0.read();
        reg_899 = grp_uploadECAL_fu_335_ap_return_1.read();
        reg_906 = grp_uploadECAL_fu_341_ap_return_0.read();
        reg_918 = grp_uploadECAL_fu_341_ap_return_1.read();
        reg_997 = grp_uploadECAL_fu_371_ap_return_0.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)))) {
        reg_1020 = grp_uploadECAL_fu_377_ap_return_0.read();
        reg_1034 = grp_uploadECAL_fu_377_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_1043 = grp_uploadECAL_fu_383_ap_return_0.read();
        reg_1057 = grp_uploadECAL_fu_383_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)))) {
        reg_1066 = grp_uploadECAL_fu_389_ap_return_0.read();
        reg_1076 = grp_uploadECAL_fu_389_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)))) {
        reg_1083 = grp_uploadECAL_fu_395_ap_return_0.read();
        reg_1095 = grp_uploadECAL_fu_395_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_1103 = grp_uploadECAL_fu_395_ap_return_0.read();
        reg_1111 = grp_uploadECAL_fu_395_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)))) {
        reg_1117 = grp_uploadECAL_fu_389_ap_return_0.read();
        reg_1127 = grp_uploadECAL_fu_389_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)))) {
        reg_1134 = grp_uploadECAL_fu_347_ap_return_0.read();
        reg_1142 = grp_uploadECAL_fu_347_ap_return_1.read();
        reg_1148 = grp_uploadECAL_fu_353_ap_return_0.read();
        reg_1156 = grp_uploadECAL_fu_353_ap_return_1.read();
        reg_1162 = grp_uploadECAL_fu_359_ap_return_0.read();
        reg_1170 = grp_uploadECAL_fu_359_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_1176 = grp_uploadECAL_fu_377_ap_return_0.read();
        reg_1184 = grp_uploadECAL_fu_377_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_1190 = grp_uploadECAL_fu_365_ap_return_0.read();
        reg_1200 = grp_uploadECAL_fu_365_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)))) {
        reg_1207 = grp_uploadECAL_fu_383_ap_return_0.read();
        reg_1215 = grp_uploadECAL_fu_383_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_926 = grp_uploadECAL_fu_347_ap_return_0.read();
        reg_936 = grp_uploadECAL_fu_347_ap_return_1.read();
        reg_943 = grp_uploadECAL_fu_353_ap_return_0.read();
        reg_953 = grp_uploadECAL_fu_353_ap_return_1.read();
        reg_960 = grp_uploadECAL_fu_359_ap_return_0.read();
        reg_970 = grp_uploadECAL_fu_359_ap_return_1.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)))) {
        reg_977 = grp_uploadECAL_fu_365_ap_return_0.read();
        reg_989 = grp_uploadECAL_fu_365_ap_return_1.read();
    }
}

void processInputLinks::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_reset_idle_pp0.read(), ap_const_logic_0) && !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_1to2.read())))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage1;
            } else if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_reset_idle_pp0.read()))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            }
            break;
        case 2 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage1_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage2;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage1;
            }
            break;
        case 4 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage2_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage3;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage2;
            }
            break;
        case 8 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage3_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage4;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage3;
            }
            break;
        case 16 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage4_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage5;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage4;
            }
            break;
        case 32 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage5_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage6;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage5;
            }
            break;
        case 64 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage6_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage7;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage6;
            }
            break;
        case 128 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage7_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage8;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage7;
            }
            break;
        case 256 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage8_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage8;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<9>) ("XXXXXXXXX");
            break;
    }
}

}

