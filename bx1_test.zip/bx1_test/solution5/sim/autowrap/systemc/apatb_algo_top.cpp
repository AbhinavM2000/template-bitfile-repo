// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

#define AP_INT_MAX_W 32678

#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;


// [dump_struct_tree [build_nameSpaceTree] dumpedStructList] ---------->


// [dump_enumeration [get_enumeration_list]] ---------->


// wrapc file define: "link_in_0_V"
#define AUTOTB_TVIN_link_in_0_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_0_V.dat"
// wrapc file define: "link_in_1_V"
#define AUTOTB_TVIN_link_in_1_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_1_V.dat"
// wrapc file define: "link_in_2_V"
#define AUTOTB_TVIN_link_in_2_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_2_V.dat"
// wrapc file define: "link_in_3_V"
#define AUTOTB_TVIN_link_in_3_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_3_V.dat"
// wrapc file define: "link_in_4_V"
#define AUTOTB_TVIN_link_in_4_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_4_V.dat"
// wrapc file define: "link_in_5_V"
#define AUTOTB_TVIN_link_in_5_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_5_V.dat"
// wrapc file define: "link_in_6_V"
#define AUTOTB_TVIN_link_in_6_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_6_V.dat"
// wrapc file define: "link_in_7_V"
#define AUTOTB_TVIN_link_in_7_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_7_V.dat"
// wrapc file define: "link_in_8_V"
#define AUTOTB_TVIN_link_in_8_V  "../tv/cdatafile/c.algo_top.autotvin_link_in_8_V.dat"
// wrapc file define: "link_out_0_V"
#define AUTOTB_TVOUT_link_out_0_V  "../tv/cdatafile/c.algo_top.autotvout_link_out_0_V.dat"
// wrapc file define: "link_out_1_V"
#define AUTOTB_TVOUT_link_out_1_V  "../tv/cdatafile/c.algo_top.autotvout_link_out_1_V.dat"
// wrapc file define: "link_out_2_V"
#define AUTOTB_TVOUT_link_out_2_V  "../tv/cdatafile/c.algo_top.autotvout_link_out_2_V.dat"
// wrapc file define: "link_out_3_V"
#define AUTOTB_TVOUT_link_out_3_V  "../tv/cdatafile/c.algo_top.autotvout_link_out_3_V.dat"

#define INTER_TCL  "../tv/cdatafile/ref.tcl"

// tvout file define: "link_out_0_V"
#define AUTOTB_TVOUT_PC_link_out_0_V  "../tv/rtldatafile/rtl.algo_top.autotvout_link_out_0_V.dat"
// tvout file define: "link_out_1_V"
#define AUTOTB_TVOUT_PC_link_out_1_V  "../tv/rtldatafile/rtl.algo_top.autotvout_link_out_1_V.dat"
// tvout file define: "link_out_2_V"
#define AUTOTB_TVOUT_PC_link_out_2_V  "../tv/rtldatafile/rtl.algo_top.autotvout_link_out_2_V.dat"
// tvout file define: "link_out_3_V"
#define AUTOTB_TVOUT_PC_link_out_3_V  "../tv/rtldatafile/rtl.algo_top.autotvout_link_out_3_V.dat"

class INTER_TCL_FILE {
	public:
		INTER_TCL_FILE(const char* name) {
			mName = name;
			link_in_0_V_depth = 0;
			link_in_1_V_depth = 0;
			link_in_2_V_depth = 0;
			link_in_3_V_depth = 0;
			link_in_4_V_depth = 0;
			link_in_5_V_depth = 0;
			link_in_6_V_depth = 0;
			link_in_7_V_depth = 0;
			link_in_8_V_depth = 0;
			link_out_0_V_depth = 0;
			link_out_1_V_depth = 0;
			link_out_2_V_depth = 0;
			link_out_3_V_depth = 0;
			trans_num =0;
		}

		~INTER_TCL_FILE() {
			mFile.open(mName);
			if (!mFile.good()) {
				cout << "Failed to open file ref.tcl" << endl;
				exit (1);
			}
			string total_list = get_depth_list();
			mFile << "set depth_list {\n";
			mFile << total_list;
			mFile << "}\n";
			mFile << "set trans_num "<<trans_num<<endl;
			mFile.close();
		}

		string get_depth_list () {
			stringstream total_list;
			total_list << "{link_in_0_V " << link_in_0_V_depth << "}\n";
			total_list << "{link_in_1_V " << link_in_1_V_depth << "}\n";
			total_list << "{link_in_2_V " << link_in_2_V_depth << "}\n";
			total_list << "{link_in_3_V " << link_in_3_V_depth << "}\n";
			total_list << "{link_in_4_V " << link_in_4_V_depth << "}\n";
			total_list << "{link_in_5_V " << link_in_5_V_depth << "}\n";
			total_list << "{link_in_6_V " << link_in_6_V_depth << "}\n";
			total_list << "{link_in_7_V " << link_in_7_V_depth << "}\n";
			total_list << "{link_in_8_V " << link_in_8_V_depth << "}\n";
			total_list << "{link_out_0_V " << link_out_0_V_depth << "}\n";
			total_list << "{link_out_1_V " << link_out_1_V_depth << "}\n";
			total_list << "{link_out_2_V " << link_out_2_V_depth << "}\n";
			total_list << "{link_out_3_V " << link_out_3_V_depth << "}\n";
			return total_list.str();
		}

		void set_num (int num , int* class_num) {
			(*class_num) = (*class_num) > num ? (*class_num) : num;
		}
	public:
		int link_in_0_V_depth;
		int link_in_1_V_depth;
		int link_in_2_V_depth;
		int link_in_3_V_depth;
		int link_in_4_V_depth;
		int link_in_5_V_depth;
		int link_in_6_V_depth;
		int link_in_7_V_depth;
		int link_in_8_V_depth;
		int link_out_0_V_depth;
		int link_out_1_V_depth;
		int link_out_2_V_depth;
		int link_out_3_V_depth;
		int trans_num;

	private:
		ofstream mFile;
		const char* mName;
};

extern void algo_top (
ap_uint<576> link_in[9],
ap_uint<576> link_out[4]);

void AESL_WRAP_algo_top (
ap_uint<576> link_in[9],
ap_uint<576> link_out[4])
{
	refine_signal_handler();
	fstream wrapc_switch_file_token;
	wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
	int AESL_i;
	if (wrapc_switch_file_token.good())
	{
		CodeState = ENTER_WRAPC_PC;
		static unsigned AESL_transaction_pc = 0;
		string AESL_token;
		string AESL_num;
		static AESL_FILE_HANDLER aesl_fh;


		// output port post check: "link_out_0_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_0_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_0_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_link_out_0_V, AESL_token); // data

			sc_bv<576> *link_out_0_V_pc_buffer = new sc_bv<576>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_0_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_0_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					link_out_0_V_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_link_out_0_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_link_out_0_V))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: link_out_0_V
				{
					// bitslice(575, 0)
					// {
						// celement: link_out.V(575, 0)
						// {
							sc_lv<576>* link_out_V_lv0_0_0_2 = new sc_lv<576>[1];
						// }
					// }

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (0) => (0) @ (2)
							for (int i_0 = 0; i_0 <= 0; i_0 += 2)
							{
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out_V_lv0_0_0_2[hls_map_index].range(575, 0) = sc_bv<576>(link_out_0_V_pc_buffer[hls_map_index].range(575, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (0) => (0) @ (2)
							for (int i_0 = 0; i_0 <= 0; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : link_out[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : link_out[0]
								// output_left_conversion : link_out[i_0]
								// output_type_conversion : (link_out_V_lv0_0_0_2[hls_map_index]).to_string(SC_BIN).c_str()
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out[i_0] = (link_out_V_lv0_0_0_2[hls_map_index]).to_string(SC_BIN).c_str();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] link_out_0_V_pc_buffer;
		}

		// output port post check: "link_out_1_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_1_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_1_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_link_out_1_V, AESL_token); // data

			sc_bv<576> *link_out_1_V_pc_buffer = new sc_bv<576>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_1_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_1_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					link_out_1_V_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_link_out_1_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_link_out_1_V))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: link_out_1_V
				{
					// bitslice(575, 0)
					// {
						// celement: link_out.V(575, 0)
						// {
							sc_lv<576>* link_out_V_lv0_1_1_2 = new sc_lv<576>[1];
						// }
					// }

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (1) => (1) @ (2)
							for (int i_0 = 1; i_0 <= 1; i_0 += 2)
							{
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out_V_lv0_1_1_2[hls_map_index].range(575, 0) = sc_bv<576>(link_out_1_V_pc_buffer[hls_map_index].range(575, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (1) => (1) @ (2)
							for (int i_0 = 1; i_0 <= 1; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : link_out[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : link_out[0]
								// output_left_conversion : link_out[i_0]
								// output_type_conversion : (link_out_V_lv0_1_1_2[hls_map_index]).to_string(SC_BIN).c_str()
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out[i_0] = (link_out_V_lv0_1_1_2[hls_map_index]).to_string(SC_BIN).c_str();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] link_out_1_V_pc_buffer;
		}

		// output port post check: "link_out_2_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_2_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_2_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_link_out_2_V, AESL_token); // data

			sc_bv<576> *link_out_2_V_pc_buffer = new sc_bv<576>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_2_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_2_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					link_out_2_V_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_link_out_2_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_link_out_2_V))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: link_out_2_V
				{
					// bitslice(575, 0)
					// {
						// celement: link_out.V(575, 0)
						// {
							sc_lv<576>* link_out_V_lv0_2_2_2 = new sc_lv<576>[1];
						// }
					// }

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (2) => (2) @ (2)
							for (int i_0 = 2; i_0 <= 2; i_0 += 2)
							{
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out_V_lv0_2_2_2[hls_map_index].range(575, 0) = sc_bv<576>(link_out_2_V_pc_buffer[hls_map_index].range(575, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (2) => (2) @ (2)
							for (int i_0 = 2; i_0 <= 2; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : link_out[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : link_out[0]
								// output_left_conversion : link_out[i_0]
								// output_type_conversion : (link_out_V_lv0_2_2_2[hls_map_index]).to_string(SC_BIN).c_str()
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out[i_0] = (link_out_V_lv0_2_2_2[hls_map_index]).to_string(SC_BIN).c_str();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] link_out_2_V_pc_buffer;
		}

		// output port post check: "link_out_3_V"
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_3_V, AESL_token); // [[transaction]]
		if (AESL_token != "[[transaction]]")
		{
			exit(1);
		}
		aesl_fh.read(AUTOTB_TVOUT_PC_link_out_3_V, AESL_num); // transaction number

		if (atoi(AESL_num.c_str()) == AESL_transaction_pc)
		{
			aesl_fh.read(AUTOTB_TVOUT_PC_link_out_3_V, AESL_token); // data

			sc_bv<576> *link_out_3_V_pc_buffer = new sc_bv<576>[1];
			int i = 0;

			while (AESL_token != "[[/transaction]]")
			{
				bool no_x = false;
				bool err = false;

				// search and replace 'X' with "0" from the 1st char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('X');
					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_3_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				no_x = false;

				// search and replace 'x' with "0" from the 3rd char of token
				while (!no_x)
				{
					size_t x_found = AESL_token.find('x', 2);

					if (x_found != string::npos)
					{
						if (!err)
						{
							cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port 'link_out_3_V', possible cause: There are uninitialized variables in the C design." << endl;
							err = true;
						}
						AESL_token.replace(x_found, 1, "0");
					}
					else
					{
						no_x = true;
					}
				}

				// push token into output port buffer
				if (AESL_token != "")
				{
					link_out_3_V_pc_buffer[i] = AESL_token.c_str();
					i++;
				}

				aesl_fh.read(AUTOTB_TVOUT_PC_link_out_3_V, AESL_token); // data or [[/transaction]]

				if (AESL_token == "[[[/runtime]]]" || aesl_fh.eof(AUTOTB_TVOUT_PC_link_out_3_V))
				{
					exit(1);
				}
			}

			// ***********************************
			if (i > 0)
			{
				// RTL Name: link_out_3_V
				{
					// bitslice(575, 0)
					// {
						// celement: link_out.V(575, 0)
						// {
							sc_lv<576>* link_out_V_lv0_3_3_2 = new sc_lv<576>[1];
						// }
					// }

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (3) => (3) @ (2)
							for (int i_0 = 3; i_0 <= 3; i_0 += 2)
							{
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out_V_lv0_3_3_2[hls_map_index].range(575, 0) = sc_bv<576>(link_out_3_V_pc_buffer[hls_map_index].range(575, 0));
									hls_map_index++;
								}
							}
						}
					}

					// bitslice(575, 0)
					{
						int hls_map_index = 0;
						// celement: link_out.V(575, 0)
						{
							// carray: (3) => (3) @ (2)
							for (int i_0 = 3; i_0 <= 3; i_0 += 2)
							{
								// sub                    : i_0
								// ori_name               : link_out[i_0]
								// sub_1st_elem           : 0
								// ori_name_1st_elem      : link_out[0]
								// output_left_conversion : link_out[i_0]
								// output_type_conversion : (link_out_V_lv0_3_3_2[hls_map_index]).to_string(SC_BIN).c_str()
								if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
								{
									link_out[i_0] = (link_out_V_lv0_3_3_2[hls_map_index]).to_string(SC_BIN).c_str();
									hls_map_index++;
								}
							}
						}
					}
				}
			}

			// release memory allocation
			delete [] link_out_3_V_pc_buffer;
		}

		AESL_transaction_pc++;
	}
	else
	{
		CodeState = ENTER_WRAPC;
		static unsigned AESL_transaction;

		static AESL_FILE_HANDLER aesl_fh;

		// "link_in_0_V"
		char* tvin_link_in_0_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_0_V);

		// "link_in_1_V"
		char* tvin_link_in_1_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_1_V);

		// "link_in_2_V"
		char* tvin_link_in_2_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_2_V);

		// "link_in_3_V"
		char* tvin_link_in_3_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_3_V);

		// "link_in_4_V"
		char* tvin_link_in_4_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_4_V);

		// "link_in_5_V"
		char* tvin_link_in_5_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_5_V);

		// "link_in_6_V"
		char* tvin_link_in_6_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_6_V);

		// "link_in_7_V"
		char* tvin_link_in_7_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_7_V);

		// "link_in_8_V"
		char* tvin_link_in_8_V = new char[149];
		aesl_fh.touch(AUTOTB_TVIN_link_in_8_V);

		// "link_out_0_V"
		char* tvout_link_out_0_V = new char[149];
		aesl_fh.touch(AUTOTB_TVOUT_link_out_0_V);

		// "link_out_1_V"
		char* tvout_link_out_1_V = new char[149];
		aesl_fh.touch(AUTOTB_TVOUT_link_out_1_V);

		// "link_out_2_V"
		char* tvout_link_out_2_V = new char[149];
		aesl_fh.touch(AUTOTB_TVOUT_link_out_2_V);

		// "link_out_3_V"
		char* tvout_link_out_3_V = new char[149];
		aesl_fh.touch(AUTOTB_TVOUT_link_out_3_V);

		CodeState = DUMP_INPUTS;
		static INTER_TCL_FILE tcl_file(INTER_TCL);
		int leading_zero;

		// [[transaction]]
		sprintf(tvin_link_in_0_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_0_V, tvin_link_in_0_V);

		sc_bv<576>* link_in_0_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_0_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (0) => (0) @ (2)
					for (int i_0 = 0; i_0 <= 0; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_0_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_0_V, "%s\n", (link_in_0_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_0_V, tvin_link_in_0_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_0_V_depth);
		sprintf(tvin_link_in_0_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_0_V, tvin_link_in_0_V);

		// release memory allocation
		delete [] link_in_0_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_1_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_1_V, tvin_link_in_1_V);

		sc_bv<576>* link_in_1_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_1_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (1) => (1) @ (2)
					for (int i_0 = 1; i_0 <= 1; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_1_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_1_V, "%s\n", (link_in_1_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_1_V, tvin_link_in_1_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_1_V_depth);
		sprintf(tvin_link_in_1_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_1_V, tvin_link_in_1_V);

		// release memory allocation
		delete [] link_in_1_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_2_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_2_V, tvin_link_in_2_V);

		sc_bv<576>* link_in_2_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_2_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (2) => (2) @ (2)
					for (int i_0 = 2; i_0 <= 2; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_2_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_2_V, "%s\n", (link_in_2_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_2_V, tvin_link_in_2_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_2_V_depth);
		sprintf(tvin_link_in_2_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_2_V, tvin_link_in_2_V);

		// release memory allocation
		delete [] link_in_2_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_3_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_3_V, tvin_link_in_3_V);

		sc_bv<576>* link_in_3_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_3_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (3) => (3) @ (2)
					for (int i_0 = 3; i_0 <= 3; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_3_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_3_V, "%s\n", (link_in_3_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_3_V, tvin_link_in_3_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_3_V_depth);
		sprintf(tvin_link_in_3_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_3_V, tvin_link_in_3_V);

		// release memory allocation
		delete [] link_in_3_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_4_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_4_V, tvin_link_in_4_V);

		sc_bv<576>* link_in_4_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_4_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (4) => (4) @ (2)
					for (int i_0 = 4; i_0 <= 4; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_4_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_4_V, "%s\n", (link_in_4_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_4_V, tvin_link_in_4_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_4_V_depth);
		sprintf(tvin_link_in_4_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_4_V, tvin_link_in_4_V);

		// release memory allocation
		delete [] link_in_4_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_5_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_5_V, tvin_link_in_5_V);

		sc_bv<576>* link_in_5_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_5_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (5) => (5) @ (2)
					for (int i_0 = 5; i_0 <= 5; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_5_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_5_V, "%s\n", (link_in_5_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_5_V, tvin_link_in_5_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_5_V_depth);
		sprintf(tvin_link_in_5_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_5_V, tvin_link_in_5_V);

		// release memory allocation
		delete [] link_in_5_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_6_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_6_V, tvin_link_in_6_V);

		sc_bv<576>* link_in_6_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_6_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (6) => (6) @ (2)
					for (int i_0 = 6; i_0 <= 6; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_6_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_6_V, "%s\n", (link_in_6_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_6_V, tvin_link_in_6_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_6_V_depth);
		sprintf(tvin_link_in_6_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_6_V, tvin_link_in_6_V);

		// release memory allocation
		delete [] link_in_6_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_7_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_7_V, tvin_link_in_7_V);

		sc_bv<576>* link_in_7_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_7_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (7) => (7) @ (2)
					for (int i_0 = 7; i_0 <= 7; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_7_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_7_V, "%s\n", (link_in_7_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_7_V, tvin_link_in_7_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_7_V_depth);
		sprintf(tvin_link_in_7_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_7_V, tvin_link_in_7_V);

		// release memory allocation
		delete [] link_in_7_V_tvin_wrapc_buffer;

		// [[transaction]]
		sprintf(tvin_link_in_8_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVIN_link_in_8_V, tvin_link_in_8_V);

		sc_bv<576>* link_in_8_V_tvin_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_in_8_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_in.V(575, 0)
				{
					// carray: (8) => (8) @ (2)
					for (int i_0 = 8; i_0 <= 8; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_in[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_in[0]
						// regulate_c_name       : link_in_V
						// input_type_conversion : (link_in[i_0]).to_string(2).c_str()
						if (&(link_in[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_in_V_tmp_mem;
							link_in_V_tmp_mem = (link_in[i_0]).to_string(2).c_str();
							link_in_8_V_tvin_wrapc_buffer[hls_map_index].range(575, 0) = link_in_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvin_link_in_8_V, "%s\n", (link_in_8_V_tvin_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVIN_link_in_8_V, tvin_link_in_8_V);
		}

		tcl_file.set_num(1, &tcl_file.link_in_8_V_depth);
		sprintf(tvin_link_in_8_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVIN_link_in_8_V, tvin_link_in_8_V);

		// release memory allocation
		delete [] link_in_8_V_tvin_wrapc_buffer;

// [call_c_dut] ---------->

		CodeState = CALL_C_DUT;
		algo_top(link_in, link_out);

		CodeState = DUMP_OUTPUTS;

		// [[transaction]]
		sprintf(tvout_link_out_0_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_link_out_0_V, tvout_link_out_0_V);

		sc_bv<576>* link_out_0_V_tvout_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_out_0_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_out.V(575, 0)
				{
					// carray: (0) => (0) @ (2)
					for (int i_0 = 0; i_0 <= 0; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_out[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_out[0]
						// regulate_c_name       : link_out_V
						// input_type_conversion : (link_out[i_0]).to_string(2).c_str()
						if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_out_V_tmp_mem;
							link_out_V_tmp_mem = (link_out[i_0]).to_string(2).c_str();
							link_out_0_V_tvout_wrapc_buffer[hls_map_index].range(575, 0) = link_out_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_link_out_0_V, "%s\n", (link_out_0_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_link_out_0_V, tvout_link_out_0_V);
		}

		tcl_file.set_num(1, &tcl_file.link_out_0_V_depth);
		sprintf(tvout_link_out_0_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_link_out_0_V, tvout_link_out_0_V);

		// release memory allocation
		delete [] link_out_0_V_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_link_out_1_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_link_out_1_V, tvout_link_out_1_V);

		sc_bv<576>* link_out_1_V_tvout_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_out_1_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_out.V(575, 0)
				{
					// carray: (1) => (1) @ (2)
					for (int i_0 = 1; i_0 <= 1; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_out[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_out[0]
						// regulate_c_name       : link_out_V
						// input_type_conversion : (link_out[i_0]).to_string(2).c_str()
						if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_out_V_tmp_mem;
							link_out_V_tmp_mem = (link_out[i_0]).to_string(2).c_str();
							link_out_1_V_tvout_wrapc_buffer[hls_map_index].range(575, 0) = link_out_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_link_out_1_V, "%s\n", (link_out_1_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_link_out_1_V, tvout_link_out_1_V);
		}

		tcl_file.set_num(1, &tcl_file.link_out_1_V_depth);
		sprintf(tvout_link_out_1_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_link_out_1_V, tvout_link_out_1_V);

		// release memory allocation
		delete [] link_out_1_V_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_link_out_2_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_link_out_2_V, tvout_link_out_2_V);

		sc_bv<576>* link_out_2_V_tvout_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_out_2_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_out.V(575, 0)
				{
					// carray: (2) => (2) @ (2)
					for (int i_0 = 2; i_0 <= 2; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_out[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_out[0]
						// regulate_c_name       : link_out_V
						// input_type_conversion : (link_out[i_0]).to_string(2).c_str()
						if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_out_V_tmp_mem;
							link_out_V_tmp_mem = (link_out[i_0]).to_string(2).c_str();
							link_out_2_V_tvout_wrapc_buffer[hls_map_index].range(575, 0) = link_out_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_link_out_2_V, "%s\n", (link_out_2_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_link_out_2_V, tvout_link_out_2_V);
		}

		tcl_file.set_num(1, &tcl_file.link_out_2_V_depth);
		sprintf(tvout_link_out_2_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_link_out_2_V, tvout_link_out_2_V);

		// release memory allocation
		delete [] link_out_2_V_tvout_wrapc_buffer;

		// [[transaction]]
		sprintf(tvout_link_out_3_V, "[[transaction]] %d\n", AESL_transaction);
		aesl_fh.write(AUTOTB_TVOUT_link_out_3_V, tvout_link_out_3_V);

		sc_bv<576>* link_out_3_V_tvout_wrapc_buffer = new sc_bv<576>[1];

		// RTL Name: link_out_3_V
		{
			// bitslice(575, 0)
			{
				int hls_map_index = 0;
				// celement: link_out.V(575, 0)
				{
					// carray: (3) => (3) @ (2)
					for (int i_0 = 3; i_0 <= 3; i_0 += 2)
					{
						// sub                   : i_0
						// ori_name              : link_out[i_0]
						// sub_1st_elem          : 0
						// ori_name_1st_elem     : link_out[0]
						// regulate_c_name       : link_out_V
						// input_type_conversion : (link_out[i_0]).to_string(2).c_str()
						if (&(link_out[0]) != NULL) // check the null address if the c port is array or others
						{
							sc_lv<576> link_out_V_tmp_mem;
							link_out_V_tmp_mem = (link_out[i_0]).to_string(2).c_str();
							link_out_3_V_tvout_wrapc_buffer[hls_map_index].range(575, 0) = link_out_V_tmp_mem.range(575, 0);
                                 	       hls_map_index++;
						}
					}
				}
			}
		}

		// dump tv to file
		for (int i = 0; i < 1; i++)
		{
			sprintf(tvout_link_out_3_V, "%s\n", (link_out_3_V_tvout_wrapc_buffer[i]).to_string(SC_HEX).c_str());
			aesl_fh.write(AUTOTB_TVOUT_link_out_3_V, tvout_link_out_3_V);
		}

		tcl_file.set_num(1, &tcl_file.link_out_3_V_depth);
		sprintf(tvout_link_out_3_V, "[[/transaction]] \n");
		aesl_fh.write(AUTOTB_TVOUT_link_out_3_V, tvout_link_out_3_V);

		// release memory allocation
		delete [] link_out_3_V_tvout_wrapc_buffer;

		CodeState = DELETE_CHAR_BUFFERS;
		// release memory allocation: "link_in_0_V"
		delete [] tvin_link_in_0_V;
		// release memory allocation: "link_in_1_V"
		delete [] tvin_link_in_1_V;
		// release memory allocation: "link_in_2_V"
		delete [] tvin_link_in_2_V;
		// release memory allocation: "link_in_3_V"
		delete [] tvin_link_in_3_V;
		// release memory allocation: "link_in_4_V"
		delete [] tvin_link_in_4_V;
		// release memory allocation: "link_in_5_V"
		delete [] tvin_link_in_5_V;
		// release memory allocation: "link_in_6_V"
		delete [] tvin_link_in_6_V;
		// release memory allocation: "link_in_7_V"
		delete [] tvin_link_in_7_V;
		// release memory allocation: "link_in_8_V"
		delete [] tvin_link_in_8_V;
		// release memory allocation: "link_out_0_V"
		delete [] tvout_link_out_0_V;
		// release memory allocation: "link_out_1_V"
		delete [] tvout_link_out_1_V;
		// release memory allocation: "link_out_2_V"
		delete [] tvout_link_out_2_V;
		// release memory allocation: "link_out_3_V"
		delete [] tvout_link_out_3_V;

		AESL_transaction++;

		tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
	}
}

