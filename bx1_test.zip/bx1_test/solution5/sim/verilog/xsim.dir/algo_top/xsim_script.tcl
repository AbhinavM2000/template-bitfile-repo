xsim {algo_top} -autoloadwcfg -tclbatch {algo_top.tcl}
