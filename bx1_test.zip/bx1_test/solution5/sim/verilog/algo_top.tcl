
log_wave [get_objects -filter {type == in_port || type == out_port || type == inout_port || type == port} /apatb_algo_top_top/AESL_inst_algo_top/*]
set designtopgroup [add_wave_group "Design Top Signals"]
set coutputgroup [add_wave_group "C Outputs" -into $designtopgroup]
set link_out_group [add_wave_group link_out(wire) -into $coutputgroup]
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_3_V_ap_vld -into $link_out_group -color #ffff00 -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_3_V -into $link_out_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_2_V_ap_vld -into $link_out_group -color #ffff00 -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_2_V -into $link_out_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_1_V_ap_vld -into $link_out_group -color #ffff00 -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_1_V -into $link_out_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_0_V_ap_vld -into $link_out_group -color #ffff00 -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_out_0_V -into $link_out_group -radix hex
set cinputgroup [add_wave_group "C Inputs" -into $designtopgroup]
set link_in_group [add_wave_group link_in(wire) -into $cinputgroup]
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_8_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_7_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_6_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_5_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_4_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_3_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_2_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_1_V -into $link_in_group -radix hex
add_wave /apatb_algo_top_top/AESL_inst_algo_top/link_in_0_V -into $link_in_group -radix hex
set blocksiggroup [add_wave_group "Block-level IO Handshake" -into $designtopgroup]
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_start -into $blocksiggroup
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_done -into $blocksiggroup
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_idle -into $blocksiggroup
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_ready -into $blocksiggroup
set resetgroup [add_wave_group "Reset" -into $designtopgroup]
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_rst -into $resetgroup
set clockgroup [add_wave_group "Clock" -into $designtopgroup]
add_wave /apatb_algo_top_top/AESL_inst_algo_top/ap_clk -into $clockgroup
save_wave_config algo_top.wcfg
run all
quit

